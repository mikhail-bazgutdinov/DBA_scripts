ORACLE SOFTWARE PATCHING WITH OPLAN       
Version 12.1.0.1.6

January 2014

This document is accurate at the time of release. For any changes and additional information regarding OPlan, refer to My Oracle Support Note, 1306814.1 -Oracle Software Patching with OPlan (https://support.oracle.com/CSP/main/article?cmd=show&type=NOT&id=1306814.1).

Overview of OPlan

	OPlan is a utility that facilitates the patch installation process by providing you with step-by-step patching instructions specific to your environment. 
	
	In contrast to the traditional patching operation, applying a patch based on the ReadMe requires you to understand the target configuration and manually identify the patching commands relevant to your environment. OPlan eliminates these requirements by automatically collecting the configuration information for the target, then generating instructions specific to the target configuration.
	
	The instructions cover both patch application and patch rollback steps. The instructions also cover multiple patching options across  In place and Out-of-Place methodologies.

Acquiring OPlan

	The OPlan utility can be downloaded from My Oracle Support via a patch number 11846294. 

Supported Configurations

	The table below shows the Product and Patch support available from OPlan:

    ------------------------------------------------------------------------------------------------------------------------
    |  Product Family  |  Product                              |  Patch Type                    |  Release  |   Platform   |
    ------------------------------------------------------------------------------------------------------------------------
    |  Oracle Database |  Oracle Exadata Database Machine**    |  Recommended Bundle Patches *  |  11.2.0.2 |   All        |
    ------------------------------------------------------------------------------------------------------------------------    
    |  Oracle Database |  Oracle Exadata Database Machine**    |  Recommended Bundle Patches *  |  11.2.0.3 |   All        |
    ------------------------------------------------------------------------------------------------------------------------
    |  Oracle Database |  Oracle Exadata Database Machine**    |  Recommended Bundle Patches *  |  11.2.0.4 |   All        |
    ------------------------------------------------------------------------------------------------------------------------
    |  Oracle Database |  Oracle Exadata Database Machine**    |  Recommended Bundle Patches *  |  12.1.0.1 |   All        |
    ------------------------------------------------------------------------------------------------------------------------
    |  Oracle Database |  Oracle Exadata Database Machine**    |  Recommended Bundle Patches *  |  12.1.0.2 |   All        |
    ------------------------------------------------------------------------------------------------------------------------
    |  Oracle Database |  Oralce Grid Infrastructure and Real  |  Recommended Patches *         |  11.2.0.2 |   All        |
    |                  |  Application Cluster Database         |                                |           |              |   
    ------------------------------------------------------------------------------------------------------------------------
    |  Oracle Database |  Oralce Grid Infrastructure and Real  |  Recommended Patches *         |  11.2.0.3 |   All        |
    |                  |  Application Cluster Database         |                                |           |              |
    ------------------------------------------------------------------------------------------------------------------------
    |  Oracle Database |  Oralce Grid Infrastructure and Real  |  Recommended Patches *         |  11.2.0.4 |   All        |
    |                  |  Application Cluster Database         |                                |           |              |
    ------------------------------------------------------------------------------------------------------------------------
    |  Oracle Database |  Oralce Grid Infrastructure and Real  |  Recommended Patches *         |  12.1.0.1 |   All        |
    |                  |  Application Cluster Database         |                                |           |              |   
    ------------------------------------------------------------------------------------------------------------------------
    |  Oracle Database |  Oralce Grid Infrastructure and Real  |  Recommended Patches *         |  12.1.0.2 |   All        |
    |                  |  Application Cluster Database         |                                |           |              |
    ------------------------------------------------------------------------------------------------------------------------

        *Support available for Recommended Bundle Patches (Bundle Patch 2 and onwards) 
        ** No support available for Oracle Dataguard configurations 


Patching with OPlan

	The OPlan utility works directly on the target, similar to OPatch.

        Step 1: Installing/Upgrading OPlan

            a) Download OPlan from My Oracle Support(https://support.oracle.com). Search for patch number 11846294 and download.
            b) Transfer the downloaded patch file to the any of the Oracle Home in the target (For example, for Oracle Exadata, transfer the utility to any One node of the cluster).
            c) As Oracle Home owner, take a backup of $ORACLE_HOME/OPatch folder.
            d) Remove $ORACLE_HOME/OPatch/oplan if already present:
                rm -r $ORACLE_HOME/OPatch/oplan
            e) As Oracle Home owner, unzip the oplan patch in the Oracle Home under 'OPatch' folder:
                unzip p11846294_<version_platform>.zip -d $ORACLE_HOME/OPatch
            f) oplan will be installed under $ORACLE_HOME/OPatch/oplan folder.

        Step 2: Generate the Patch Installation Instructions

            a) Download the patch to a local directory on the target
            b) Set the ORACLE_HOME variable to the Targets Oracle Home (say for Exadata Databases Machine  Grid Infrastructure Oracle Home of the Node)
            c) As Oracle Home owner, run the following command:
                $ORACLE_HOME/OPatch/oplan/oplan generateApplySteps <bundle patch location>
                For example: $ORACLE_HOME/OPatch/oplan/oplan generateApplySteps <bundle patch location>
            d) The patch installation instructions specific to your target will be  available as HTML and text format in these locations:
                $ORACLE_HOME/cfgtoollogs/oplan/<TimeStamp>/ApplyInstructions.html
                $ORACLE_HOME/cfgtoollogs/oplan/<TimeStamp>/ApplyInstructions.txt

        Step 3: Apply the Patch

            a) Choose the patching option that best suits your needs. The patch installation instruction offers multiple options across In Place and Out of Place patching methodologies.
            b) Follow the patching instructions and apply the patch to the target.

        Step 3a: Rollback of the Patch

            a) As Oracle Home owner, run the following command:
                $ORACLE_HOME/OPatch/oplan/oplan generateRollbackSteps <bundle patch location>
            b) Choose the rollback option that best suits your needs.
            c) Follow the instructions and rollback the patch from the target.


Troubleshooting

	In case of errors, the detailed logs are available under the $ORACLE_HOME/cfgtoollog/oplan/<TimeStamp> directory. For any additional support, contact Oracle Support.

Licensing Information

        The OPlan utility is provided under the My Oracle Support Terms of Use, 
        your agreement with Oracle and the terms of Oracle's applicable Technical 
        Support Policies. Any use of OPlan not specifically authorized in the My 
        Oracle Support Terms of Use, your agreement with Oracle and the terms of 
        Oracle's applicable Technical Support Policies is strictly prohibited. For 
        more information on licensing , refer to 
        Oracle Enterprise Manager Licensing Information 12c Release 1 (12.1)




Documentation Accessibility
	Our goal is to make Oracle products, services, and supporting documentation accessible to all users, including users that are disabled. To that end, our documentation includes features that make information available to users of assistive technology. This documentation is available in HTML format, and contains markup to facilitate access by the disabled community. Accessibility standards will continue to evolve over time, and Oracle is actively engaged with other market-leading technology vendors to address technical obstacles so that our documentation can be accessible to all of our customers. For more information, visit the Oracle Accessibility Program Web site at http://www.oracle.com/accessibility/.

Accessibility of Code Examples in Documentation
	Screen readers may not always correctly read the code examples in this document. The conventions for writing code require that closing braces should appear on an otherwise empty line; however, some screen readers may not always read a line of text that consists solely of a bracket or brace.

Accessibility of Links to External Web Sites in Documentation
	This documentation may contain links to Web sites of other companies or organizations that Oracle does not own or control. Oracle neither evaluates nor makes any representations regarding the accessibility of these Web sites.

Access to Oracle Support
	Oracle customers have access to electronic support through My Oracle Support. For information, visit http://www.oracle.com/support/contact.html or visit http://www.oracle.com/accessibility/support.html if you are hearing impaired.


------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Copyright 2014, Oracle and/or its affiliates. All rights reserved.

	This software and related documentation are provided under a license agreement containing restrictions on use and disclosure and are protected by intellectual property laws. Except as expressly permitted in your license agreement or allowed by law, you may not use, copy, reproduce, translate, broadcast, modify, license, transmit, distribute, exhibit, perform, publish, or display any part, in any form, or by any means. Reverse engineering, disassembly, or decompilation of this software, unless required by law for interoperability, is prohibited.
	The information contained herein is subject to change without notice and is not warranted to be error-free. If you find any errors, please report them to us in writing.
	If this software or related documentation is delivered to the U.S. Government or anyone licensing it on behalf of the U.S. Government, the following notice is applicable:
	U.S. GOVERNMENT RIGHTS Programs, software, databases, and related documentation and technical data delivered to U.S. Government customers are "commercial computer software" or "commercial technical data" pursuant to the applicable Federal Acquisition Regulation and agency-specific supplemental regulations. As such, the use, duplication, disclosure, modification, and adaptation shall be subject to the restrictions and license terms set forth in the applicable Government contract, and, to the extent applicable by the terms of the Government contract, the additional rights set forth in FAR 52.227-19, Commercial Computer Software License (December 2007). Oracle USA, Inc., 500 Oracle Parkway, Redwood City, CA 94065.

	This software is developed for general use in a variety of information management applications. It is not developed or intended for use in any inherently dangerous applications, including applications which may create a risk of personal injury. If you use this software in dangerous applications, then you shall be responsible to take all appropriate fail-safe, backup, redundancy, and other measures to ensure the safe use of this software. Oracle Corporation and its affiliates disclaim any liability for any damages caused by use of this software in dangerous applications.

	Oracle is a registered trademark of Oracle Corporation and/or its affiliates. Other names may be trademarks of their respective owners.
	This software and documentation may provide access to or information on content, products, and services from third parties. Oracle Corporation and its affiliates are not responsible for and expressly disclaim all warranties of any kind with respect to third-party content, products, and services. Oracle Corporation and its affiliates will not be responsible for any loss, costs, or damages incurred due to your access to or use of third-party content, products, or services.

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Copyright  2006, 2014, Oracle and/or its affiliates. All rights reserved. 

 

 

 

 

 

 

 
