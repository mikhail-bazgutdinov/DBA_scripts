# 
# $Header: opatch/crs_files/patchTracking.pm /main/1 2017/12/01 03:31:24 srukumar Exp $
#
# patchTracking.pm
# 
# Copyright (c) 2017, Oracle and/or its affiliates. All rights reserved.
#
#    NAME
#      patchTracking.pm - <one-line expansion of the name>
#
#    DESCRIPTION
#      <short description of component this file declares/defines>
#
#    NOTES
#      <other useful comments, qualifications, etc.>
#
#    MODIFIED   (MM/DD/YY)
#    srukumar    10/20/17 - This module provides functionality to create and
#                           maintain history of bundle patches applied or
#                           rolled back by opatch auto
#    srukumar    10/20/17 - Creation
#

package patchTracking;

use strict;
use vars qw(@ISA @EXPORT @EXPORT_OK); 
use English;
use Exporter;
use FileHandle;
use File::Basename;
use File::Spec::Functions;
use File::Copy;
use File::Path;
use File::Find;
use File::Basename;
use Cwd 'abs_path';

BEGIN {
  # Add the directory of this file to the search path
   my $scriptdir = abs_path(dirname($PROGRAM_NAME));
   unshift @INC, $scriptdir;
}

use opatchautoUtil;

@ISA = qw(Exporter);

@EXPORT = qw( preparePatchInfoStore preparePatchInfoStoreForHomes getEligiblePatchListForApply getEligiblePatchListForRollback shortlistPatchesPerHome editPatchInfoStoreforApply editPatchInfoStoreforRollback );

sub preparePatchInfoStoreForHomes
{
  my @homes = @_;
  debug("List of homes where patch info store will be prepared : @_");
  foreach my $home (@homes) {
    preparePatchInfoStore($home);
  }
  trace("Patch Information Storage successfully prepared for all homes.");
}

#Create the patch Info store if it does not already exists
sub preparePatchInfoStore
{
  my $home = shift;
  my $opatchDir = "$home/OPatch";
  my $opatchautoStore = "$home/.opatchauto_storage";
  my $bundlePatches = "$opatchautoStore/bundle_patches";
  my $infoStore = "$bundlePatches/patchInformationStore";
  
  debug("Preparing patch information store for home $home");
  my ($name, $uid, $gid) = getoracleownerInfo($home);  
  if ( ! -f $infoStore)
  {	
	if ( ! -d $bundlePatches){ 
	  eval { mkpath($bundlePatches) };
      if ($@) {
        exitOpatch ("Couldn't create $bundlePatches: $@");
      }
	}	
	open (my $info, "> $infoStore");
    close($info);	
  }

  modifyFileAccess($infoStore, $uid, $gid, "750");
  modifyFileAccess($bundlePatches, $uid, $gid, "750");
  modifyFileAccess($opatchautoStore, $uid, $gid, "750");  
  debug("Patch information store successfully prepared for home $home");
  
  return;
}

# Read the list of active patches
sub runLsPatches
{
  my $home = shift;
  my @activePatches = ();
  debug("Finding active patches on home $home");
  my $owner = getoracleowner($home);
  my $opatch = catfile ($home, "OPatch", "opatch");
  my $cmd = "$opatch lspatches -oh $home";
  my ($output, $status) = execute_cmd( $owner, $cmd );
  
  if($status == 0) {
    # Output format is expected to be like this:
	# 17076717;Grid Infrastructure Patch Set Update : 11.2.0.3.8 (HAS Components)
    my @lines = split(/\n/, $output);
	foreach my $line (@lines){
	  my @line_info = split(/;/, $line);
	  my $patchID = trim ($line_info[0]);
	  if ($patchID =~ /^[0-9]+$/)
	  {
	    push @activePatches, $patchID;
	  }
	}
	if (scalar(@activePatches) > 0 ) {
	  trace("Oracle Home $home contains these active patches already installed : @activePatches.");
	}else{
	  trace("Oracle Home $home contains no active patches.");
	}
  }
  else {
    exitOpatch("Unable to run lspatches on $home");
  }  
  return @activePatches;  
}

#
sub getBundlePatchID
{
  my $patchLocn = shift;
  my $bundleID = basename("$patchLocn");
  debug("Bundle Patch ID is $bundleID.");
  
  return $bundleID;
}

# Read the list of patchIDs registered against a bundle ID in the patch Information Store
# Format is "<Bundle ID> :16902043 17076717: Thu Oct 05 10:32:14"
sub readBundleEntry
{
  my $bundleID = shift;
  my $home = shift;
  my @patchEntries = ();
  my $patchInfoStore = catfile($home, ".opatchauto_storage", "bundle_patches", "patchInformationStore" );
  
  if (-f $patchInfoStore){
    my @lines = read_file( $patchInfoStore);
	foreach my $entry (@lines) {
	  if ($entry =~ /^$bundleID/){
	    my ($list, $date) = (split(/:/, $entry, 3))[1, 2];
		@patchEntries = split (/ /, $list);
		trace("Patches $list had been installed from Bundle Patch $bundleID on $date on home $home");
		return @patchEntries;
	  }
	}
    trace("No entry found in the store $patchInfoStore for bundle patch $bundleID.");	
  }
  else {
    trace("patchInformationStore has not been created.");
  }
  return @patchEntries; 
}

# Evaluate the list of fresh incoming patches
sub getEligiblePatchListForApply
{
  my $home = shift;
  my $incomingPatchIDs = shift;
  my @validPatchIDs = ();
  
  debug("Evaluating home $home for apply list");
  my @existingPatchIDs = runLsPatches($home);
  foreach my $id (@$incomingPatchIDs){
    if ( grep( /^$id$/, @existingPatchIDs ) ) {	  
	  trace("The patch $id already exists on the home $home and hence it will not be re-applied.");
	}
	else {
	  push (@validPatchIDs, $id);
	}
  }  
  debug("Following patches have been selected for patching home $home : @validPatchIDs");
  return @validPatchIDs;
} 

# Evaluate the list of valid patches for rollback, in other words, 
# stick to the list of patches previously installed from this Bundle Patch
sub getEligiblePatchListForRollback
{
  my $home = shift;
  my $bundleID = shift;
  my $rollbackIDs = shift;
  
  debug("Evaluating home $home for rollback list");
  my @installedIDs = readBundleEntry($bundleID, $home);
  #If this array is empty it could mean it was applied using older opatch-auto or it could mean
  # the patch was not installed using opatch-auto. As per the doc, we will take the safer approach
  # of rolling back ALL the patches. If the bundle patch was already rolled back, that case will
  # be internally handled.
  if (scalar (@installedIDs) == 0){
    trace ("No entry found against the bundle ID $bundleID in the patchInformationStore. Therefore, all the selected patches will be rolled back.");
    return @$rollbackIDs;
  }
  else {
    debug("The list of patches to be rolled back from $home is @installedIDs");
    return @installedIDs;
  }  
}

# For each home, build information in a hash with keys as list of valid patchIDs (apply/rollback)
# and values as their respective patch locations. This hash become the value of another hash with 
# home as the key.
# Return the parent hash.
sub shortlistPatchesPerHome
{
  my $bundleID = shift; 
  my $homeToTypeHashRef = shift;
  my $giPatchesHashRef = shift;
  my $haPatchesHashRef = shift;
  my $dbPatchesHashRef = shift;
  my $rollback = shift;
  my $homeToPatchesHashRef = shift;  
  
  # For each home get the incoming/outgoing patch IDs based on its home type.
  my @validPatchIDs;
  my @intialList;
  foreach my $home ( keys %$homeToTypeHashRef) {
    # First get the initial list extracted from bundle.xml
	trace ("Shortlisting patches for home $home");
	my $referenceHashRef;
    if ( $$homeToTypeHashRef{$home} eq "CRS"){
	  $referenceHashRef = $giPatchesHashRef;	  
	}
	elsif ( $$homeToTypeHashRef{$home} eq "HA"){
	  $referenceHashRef = $haPatchesHashRef;
	}
	else {
	  $referenceHashRef = $dbPatchesHashRef;
	}
	@intialList = keys %$referenceHashRef;
	debug ("Initial list of patches for $home is @intialList");
	
	# Now shortlist them per home
	if ($rollback){
	  @validPatchIDs = getEligiblePatchListForRollback($home, $bundleID, \@intialList);
	}
	else{
	  @validPatchIDs = getEligiblePatchListForApply($home, \@intialList);
	}	
	trace ("Final list of patches for $home is @validPatchIDs");
	
	# Build the shortlisted patchID-to-patchPath Hash
	my %shortlistedHash = map { $_ => $$referenceHashRef{$_} } @validPatchIDs;
	
	# Add entry to Hash that maps home to its shortlisted patches
	$$homeToPatchesHashRef{$home} = \%shortlistedHash;
  }  
  return;  
}

# Update the bundle entry when applying a bundle patch. It creates a superset
# of the incoming patches and the already entered list in patch Information Store,
# if it exists
sub editPatchInfoStoreforApply
{
  return editPatchInfoStore(@_, "false");
}

# Remove the bundle entry from patch Information Store when rolling back a bundle patch.
sub editPatchInfoStoreforRollback
{
  return editPatchInfoStore(@_, "true");
}

# Handle apply/rollback scenarios of editing the patch Information Store
sub editPatchInfoStore
{
  my $home = shift;
  my $bundleID = shift;
  my $patchListRef = shift;
  my $rollback = shift;
  
  debug("Patch information store will be edited for home $home");
  # For empty patch list, it is no-op.
  if ( (scalar @$patchListRef) == 0 ) {
    trace ("The patch list for $home is empty, hence, patchInformationStore will not be modified.");
	return;
  }
  
  my $patchInfoStore = catfile($home, ".opatchauto_storage",
						"bundle_patches", "patchInformationStore" );
  my $newInfoStore = catfile($home, ".opatchauto_storage", 
						"bundle_patches", "patchInformationStore.new" );						
  
  if (-f $patchInfoStore){
    my $entry_found;
	open(NEW, "> $newInfoStore");
    my @lines = read_file( $patchInfoStore);
	foreach my $entry (@lines) {
	  if ($entry =~ /^$bundleID/){ 
	    # It matches the current bundle patch, edit/add the entry
	    $entry_found = "true";
		
	    # For rollback, we just bypass this entry for the new file.
		# For apply we might need to add some entries.
		if ($rollback eq "false")
		{		  
	      my $list = (split(/:/, $entry, 3))[1];
		  my @existingEntries = split (/ /, $list);
		  print NEW buildPisEntryForApply($bundleID, $patchListRef, \@existingEntries);
		}		
	  }
	  else{
	    # print this entry as is, it belongs to another bundle patch
	    print NEW $entry;
	  }
	}
    
    if (! $entry_found){ # Make a new entry for apply
	  if ($rollback eq "false"){
	    print NEW buildPisEntryForApply($bundleID, $patchListRef);
	  }
	}
	
	close (NEW);
	# Replace the old Patch Info Store with the new one
	replaceAndDelete ($patchInfoStore, $newInfoStore);
	my ($name, $uid, $gid) = getoracleownerInfo($home);
	modifyFileAccess($patchInfoStore, $uid, $gid, "750");
	trace("Patch information store successfully edited.");
  }
  else {
    trace("patchInformationStore has not been created and hence it won't be edited.");
  }
  return;
}

# Build the entry for storing required data against the bundle patch ID in the patch info store
sub buildPisEntryForApply
{
  my $bundleID = shift;
  my $patchListRef = shift;
  my $existingEntriesRef = shift;
  
  my $newEntry = "$bundleID";
  my $idList;
  if (defined $existingEntriesRef){
    #Some entries have already been entered in the patch info store
	#We create a hash out of all patch IDs, thereby overwriting the duplicate entries
	my @superset = keys %{{map {($_ => 1)} (@$existingEntriesRef, @$patchListRef)}};
	$idList = join ' ', @superset;	
  }
  else{
    $idList = join ' ', @$patchListRef;     
  }
  $newEntry = $newEntry.':'.$idList.':'.localtime;
  debug("New entry in patch information store is : $newEntry"); 
  return $newEntry."\n";
}

1;

