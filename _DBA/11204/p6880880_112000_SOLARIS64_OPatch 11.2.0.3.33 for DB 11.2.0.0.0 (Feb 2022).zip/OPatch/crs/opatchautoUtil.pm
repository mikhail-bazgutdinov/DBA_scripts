# 
# $Header: opatch/crs_files/opatchautoUtil.pm /main/3 2018/08/09 02:22:15 srukumar Exp $
#
# opatchautoUtil.pm
# 
# Copyright (c) 2017, 2018, Oracle and/or its affiliates. All rights reserved.
#
#    NAME
#      opatchautoUtil.pm - <one-line expansion of the name>
#
#    DESCRIPTION
#      <short description of component this file declares/defines>
#
#    NOTES
#      <other useful comments, qualifications, etc.>
#
#    MODIFIED   (MM/DD/YY)
#    srukumar    11/24/17 - Utility module for opatch auto
#    srukumar    11/24/17 - Creation
# 

package opatchautoUtil;

use strict;
use vars qw(@ISA @EXPORT @EXPORT_OK); 
use English;
use Exporter;
use FileHandle;
use File::Basename;
use File::Spec::Functions;
use File::Copy;
use File::Path;
use File::Find;
use Cwd;
use Cwd 'abs_path';


@ISA = qw(Exporter);

@EXPORT = qw( setOALogFile setPTValues setOADebug debug trace execute_cmd exitOpatch error trim read_dir read_file getoracleownerInfo getoracleowner verifyPatchStorage detectPerlInBundlePatch getScriptHome getOrderedPatchIDs getOrderedPatchLocns  copyPerl copyRecursively instantiatePerl replaceStringInFile modifyFileAccess replaceAndDelete getPerlTmpPath);

our $log_file_oauto = undef;
our $OS_local = undef;
our $su_local = undef;
our $debug = undef;

sub setOALogFile
{
  $log_file_oauto = $_[0];  
}

# Set OS sepcific values for the session
sub setPTValues
{
  $OS_local = $_[0];
  $su_local = $_[1];
  
  debug("OS is $OS_local and su is located at $su_local");
}

#Enable debug mode
sub setOADebug
{
  $debug = shift;
}

# Debug messages
sub debug
{
  if ($debug) { trace("FINEST: @_"); }
  return;
}

#Log messages to the main log file
sub trace
{    
	if (! defined $log_file_oauto){
	  print "\n @_ \n";
	  return;
	}

    my ($sec, $min, $hour, $day, $month, $year) =
        (localtime) [0, 1, 2, 3, 4, 5];
    $month = $month + 1;
    $year = $year + 1900;
	
    open (TRCFILE, ">>$log_file_oauto")
          or return 1;
    
    printf TRCFILE  "\n%04d-%02d-%02d %02d:%02d:%02d: @_\n",
        $year, $month, $day, $hour, $min, $sec;
    close (TRCFILE);
	return;
}

# Execute a given command as the specified user and return the output and result
sub execute_cmd
{
    my $user = $_[0];
    my $command = $_[1];
    
    my $final_cmd;

    if ($user eq "root" )
    {
      $final_cmd = $command;
    }
    else
    {
      $final_cmd = "$su_local $user";
      if ( ($OS_local ne "HP-UX") && ($OS_local ne "SunOS" ) )
      {
        $final_cmd = "$final_cmd -m";
      }	
      $final_cmd = "$final_cmd -c \"$command\" ";
    }

    my $output = `$final_cmd 2>&1`;
    my $result = $? >> 8;
    return ($output , $result );
}

sub exitOpatch
{
  my $error_message = $_[0];
  if($error_message)
  {
     error("$error_message");
  }
  print "\nopatch auto failed.\n";
  exit 1;
}

sub error
{
  print "ERROR: @_\n";
  trace(@_);
  return;
}

#Remove trailing white spaces in a string
sub trim($)
{
    my $string = shift;
	if ( defined $string) {
	  $string =~ s/^\s+//;
      $string =~ s/\s+$//;
	}    
    return $string;
}

# List only the contents directly under the slected directory, without searching sub-dirs
sub read_dir
{
  my $dir = shift;
  
  opendir my $handler, $dir or die "Could not open '$dir' for reading '$!'\n";
  my @contents = readdir $handler;
  closedir $handler;
  
  return @contents;
}

# Read all lines of a file into an array of strings
sub read_file
{
    my $file = $_[0];
    open (FILE, "<$file") or die "Can't open $file: $!";
    my @contents = (<FILE>);
    close (FILE);

    return @contents;
}

# return the name of the home owner
sub getoracleownerInfo
{
  my $oh = $_[0];
  my $getoh_ox = "$oh/bin/oracle";
  my ($name, $uid, $gid);
   
  if (  -f $getoh_ox )
  {
     $uid = (stat $getoh_ox )[4];
     ($name, $uid, $gid) = (getpwuid $uid )[0, 2, 3];     
     debug( "Oracle owner of $oh is $name" );
	 debug("For $name UID is $uid and GID is $gid");
  }
  else {
     exitOpatch("unable to get oracle owner for $oh");
  }
  return ($name, $uid, $gid);
}

sub getoracleowner
{
  my @info = getoracleownerInfo($_[0]);
  return $info[0];
}

# Running opatch-core commands on a locked GI home will fail if .patch_storage does not exists
# As root user create this folder at the beginning of the opatch-auto session
sub verifyPatchStorage
{
  my $home = shift;
  my $patchStorage = "$home/.patch_storage";
  my ($name, $uid, $gid) = getoracleownerInfo($home);
  if(! -d $patchStorage)
  {
    mkdir ($patchStorage) or die "Unable to create patch storage directory : $!";	
  }
  modifyFileAccess($patchStorage, $uid, $gid, "750");
  trace("\npatch storage directory verified successfully\n");
  return;
}

# Stick to one home for creation and deletion of tmp files, e.g. perl
sub getScriptHome
{
  my $scriptPath = abs_path(dirname($0));  
  my $home = dirname(dirname($scriptPath));
  
  return $home;
}

# Get the list of patchIDs from a hash in the order in which they appear in bundle.xml
sub getOrderedPatchIDs
{
   my $orderedIDsRef = (getOrderedPatchInfo(@_))[0];
   return @$orderedIDsRef;
}

# Get the list of patch locns from a hash in the order in which they appear in bundle.xml
sub getOrderedPatchLocns
{   
   my $orderedLocnsRef = (getOrderedPatchInfo(@_))[1];
   return @$orderedLocnsRef;
}

# Get the list of patchIDs and their Locns in the order in which they appear in bundle.xml
sub getOrderedPatchInfo
{
   my $home = shift;
   my $bundlePatchesRef = shift;
   my $homeToPatchesHashRef = shift;
   my @orderedIDs;
   my @orderedLocns;
   my $patchID;
   
   my %homeToPatchesHash = %$homeToPatchesHashRef; 
   my $patchIDtoPatchLocnHashRef = $homeToPatchesHash{$home}; 
   my %patchIDtoPatchLocnHash = %$patchIDtoPatchLocnHashRef;
   
   # @bundlePatches contains the correct sequence of patches mentioned in bundle.xml
   foreach $patchID (@$bundlePatchesRef) 
   {
      if (exists ($patchIDtoPatchLocnHash{$patchID}))
	  {
	     push @orderedIDs, $patchID;
		 push @orderedLocns, $patchIDtoPatchLocnHash{$patchID};
	  }
   }
   
   return (\@orderedIDs, \@orderedLocns);
}


# Detect path to perl one-off within a bundle patch, if it exists
sub detectPerlInBundlePatch
{
  my $bundlePatch = shift;
  
  my @contents = read_dir($bundlePatch);
  foreach my $listing (@contents) 
  {
    debug("Detecting $bundlePatch/$listing ...");
    if ($listing eq '.' or $listing eq '..') {
	  debug ("Skipping $listing");
	  next;
	}
	my $path = "$bundlePatch/$listing";
	if (detectPerlOneOff($path)) {	  
	  return $path;
	}
  }
  
  return;  
}

# Detect whether a given one-off is a perl patch.
sub detectPerlOneOff
{
  my $patchPath = shift;
  
  if (! -d $patchPath) { return 0;}  
  my $inventory = catfile($patchPath, "etc", "config", "inventory.xml");
  if ( -f $inventory) {
    debug("Reading $inventory ...");
    my @matches = grep(/content_type value="perl"/, read_file($inventory));
	return (scalar @matches);
  }
  return 0;
}

# Copy perl from one-off to opatchauto storage
sub copyPerl
{
  my $home  = shift;
  my $patch = shift;
  
  my $opatchauto_perl = "$home/.opatchauto_storage/perl";  
  my $patch_perl = "$patch/files/perl";
  debug("Copying from $patch_perl to $opatchauto_perl");
  
  copyRecursively($patch_perl, $opatchauto_perl );
  return $opatchauto_perl;
}

# Copy files recursively from a source to a destination specified
sub copyRecursively
{
  my $sourcedir = shift;
  my $destdir   = shift;
  my $filepath;
  my $filename;
  my @filelist;
  my $destfilepath;
  my $dirpath;
  find(sub { push @filelist, $File::Find::name }, $sourcedir);
  
  debug ("Size of files copy list is ". (scalar @filelist));
  foreach $filepath (@filelist)
  {
    if ( -f $filepath)
    {
      $filename = basename($filepath);
      $dirpath = dirname($filepath);
      $dirpath =~ s/$sourcedir/$destdir/g;
      if( ! -e $dirpath){
        eval { mkpath($dirpath); 1 }
          or die "Can't create directory: $@\n";
      }
      $destfilepath = "$dirpath/$filename";
      copy($filepath, $destfilepath);
    }
  }
  
  return;
}

# Instantiate files in a perl one-off so that the place-holders are replaced by proper values
# E.g. %ORACLE_HOME%  must be replaced by the parent directory of perl, opatchautoStorage.
sub instantiatePerl
{
  my $perlPath = shift;
  my $opatchautoStorage = dirname($perlPath);
  my $home     = dirname($opatchautoStorage);
  
  my ($uid, $gid) = (getoracleownerInfo($home))[1,2];
  modifyFileAccess($perlPath, $uid, $gid, "750");
  modifyFileAccess($opatchautoStorage, $uid, $gid, "750");
  
  find( \&instantiateFile, $perlPath);
  
  sub instantiateFile
  {
    my $file = $File::Find::name;
	if( -f $file) { 
      replaceStringInFile('%ORACLE_HOME%', $opatchautoStorage, $file);
    }
	modifyFileAccess($file, $uid, $gid, "750");
  }  
}

# Replace a given string with a provided value across all lines of a file
sub replaceStringInFile
{
  my $oldString  = shift;
  my $newString  = shift;
  my $file = shift;
  
  my $newFile = "$file.oa.new";
  open(NEW, "> $newFile");
  my @lines = read_file( $file);
  foreach my $line (@lines) {
    $line =~ s/$oldString/$newString/g;
	print NEW $line;
  }
  close (NEW);
  replaceAndDelete($file, $newFile);
  return;
}

# Replace the old file with the new file and delete the new location 
sub replaceAndDelete
{
  my $old = shift;
  my $new = shift;
  my $tmp = "$old.bak";
  
  if (-e $tmp) { unlink $tmp; }
  
  rename($old, $tmp);
  rename($new, $old);
  unlink($new, $tmp);
  
  return;
}

# Set uid, gid and permissions of the file to the specified values
sub modifyFileAccess
{
  my $file = shift;
  my $uid = shift;
  my $gid = shift;
  my $perms = shift;
  
  chown($uid, $gid, $file);
  chmod(oct($perms), $file);
  return;
}

sub getPerlTmpPath
{
  my $home = getScriptHome();
  my $perl  = "$home/.opatchauto_storage/perl";
  return "$perl";
}

1;