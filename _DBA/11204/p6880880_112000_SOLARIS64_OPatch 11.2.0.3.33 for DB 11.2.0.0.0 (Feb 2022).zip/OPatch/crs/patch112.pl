#!/usr/local/bin/perl
#
# patch112.pl
#
# Copyright (c) 2007, 2017, Oracle and/or its affiliates. All rights reserved.
#
#    NAME
#      patch112.pl - Auto patching tool for Oracle Clusterware/RAC home.
#
#    DESCRIPTION
#      patch112.pl -  Auto patching tool for Oracle Clusterware/RAC home.
#
#    MODIFIED   (MM/DD/YY)
#       srukumar   10/20/17  - Fix Bug 26725636
#       ksviswan   03/02/11  - Fix Bugs 11807070, 11824391, 9965477
#       ksviswan   01/25/11  - Fix bug 11670519.
#       ksviswan   01/25/11  - Out of place patching support
#       ksviswan   10/01/10  - XbranchMerge ksviswan_bug-10147375 from main
#       ksviswan   09/27/10  - XbranchMerge ksviswan_opauto_copy_initfiles from
#                              main
#       ksviswan   09/22/10  - XbranchMerge ksviswan_bug-10132822 from main
#       ksviswan   09/20/10  - Fix Bugs 9475556,9869238,9869250
#       ksviswan   08/25/10  - Fix Bug 9863515,9869222,10055092,9869222
#       ksviswan   06/24/10  - Fix Bug 9849173
#       ksviswan   06/07/10  - Fix Bug 9786647
#       ksviswan   05/31/10  - Fix Bug 9755296
#       ksviswan   05/25/10  - Fix Bugs 9719845,9719790,9750704 and 9750739
#       ksviswan   04/21/10  - Support Automation for New PSU patch format.
#       ksviswan   03/06/10  - Fix Bugs 9453069 and 9437772
#       ksviswan   02/25/10  - Fix Bugs 9362121,9358228,9409808
#                              add checkCompoent logic
#       ksviswan   01/08/10  - Fix bug 9209886 and set default log dir.
#       ksviswan   05/08/09  - Implement 11.2 autopatching support 
#
#   NOTES
#
# Documentation: usage output,
#   execute this script with -h option
#
#

################ Documentation ################

# The SYNOPSIS section is printed out as usage when incorrect parameters
# are passed

=head1 NAME

  patch112.pl - Auto patching tool for Oracle Clusterware/RAC home.

=head1 SYNOPSIS

  opatch auto <patch directory>
              [-oh  <oracle home location>]
              [-och <crs home location>]
              [-rollback]
              [-ocmrf <ocm response file location>]
              [-norestart]

  Options:

   patch_directory

             Default is the current directory.
             This is the top level directory path where the patch is 
             unzipped. 

             Example:
            
             Always unzip the gipsu/gi one-off in a empty directory
             where there are no other directory/files existing.  
            
             If the directory under which the patch is unzipped is /tmp/patchdir 

             opatch auto /tmp/patchdir

            


 -rollback  

             The patch will be rolled back, not applied
             This option requires patch_directory to be passed

             Example:
             opatch auto /tmp/patchdir -rollback

 -oh         Database/Clusterware home locations    

             comma_delimited_list_of_oralcehomes_to_patch
             The default is all applicable Oracle Homes including
             the clusterware home .Use this option  to patch RDBMS homes where
             no database is registered or any specific database home or
             clusterware home.

             Example:
             opatch auto /tmp/patchdir -oh <oracle_home1_path,oracle_home2_path>

 -och        Grid infrastructure home location
             absolute path of crs home location. This is only used
             to patch Clusterware home when the clusterware stack is down
         
             Example:
             opatch auto /tmp/patchdir -och <oracle_gridhome_path>

 -ocmrf      OCM response file location

             Absolute path of the OCM response file. This is required for
	     silent mode patching

 -norestart  
	     The clusterware stack and database home resources will not be 
	     started after patching. 


  To patch a shared Clusterware or Database home, 
  Refer to Section "Patching installation to RAC database and/or the GI home" in the 
  Patch Readme document and follow the steps.

                                          
=head1 DESCRIPTION


  This script automates the complete patching process for a Clusterware
  or RAC database home. This script must be run as root user and needs Opatch version
  10.2.0.3.3 or above. 
  Case 1 -  On each node of the CRS cluster in case of Non Shared CRS Home.
  Case 2 -  On any one node of the CRS cluster is case of Shared CRS home.          

=cut

################ End Documentation ################

use strict;
use English;
use Cwd;
use Cwd 'abs_path';
use FileHandle;
use File::Basename;
use File::Spec::Functions;
use File::Copy;
use File::Find;
use Fcntl ':mode';
use Sys::Hostname;        
use Net::Ping;
use Getopt::Long;
use Pod::Usage;

BEGIN {
  # Add the directory of OH/crs/install to search path

  my $scriptdir = abs_path(dirname($PROGRAM_NAME));
  my $incdir = "$scriptdir/../../crs/install";

  unshift @INC, abs_path($incdir);
}

use crsconfig_lib;
use crsdelete;
use crspatch;
use oraacfs;


#Global variables
our $g_help = 0;
our $g_unlock = 0;
our $g_patch = 0;

my $scriptdir_p = abs_path(dirname($PROGRAM_NAME));
my $crs_install_p = abs_path("$scriptdir_p/../../crs/install");


# pull all parameters defined in crsconfig_params and s_crsconfig_defs (if
# it exists) as variables in Perl
my $paramfile_default = catfile ($crs_install_p, "crsconfig_params");

# pull all definitions in s_crsconfig_defs (if it exists) as variables in Perl
# this file might not exist for all platforms
my $defsfile = catfile ($crs_install_p, "s_crsconfig_defs");
my $timestamp = gentimeStamp();

my $scrdir = abs_path($crs_install_p);

my $deflogdir = "$scrdir/../../cfgtoollogs";
my $logfile;

if (-e $deflogdir)
{
   $logfile = catfile($deflogdir,  "opatchauto$timestamp.log");
}
else
{
   $logfile  = catfile ($scrdir, "log", "opatchauto$timestamp.log");
}

print "opatch auto log file location is $logfile\n";


my $PARAM_FILE_PATH = $paramfile_default;
my $NOCRSSTOP_P;
my $unlock_crshome_p;
my $patchdir;
my $patchdbdir;
my $patchfile;
my $patchnum;
my $rollback;
my $ohome;
my $chome;
my $ocmrf;
my $norestart;
my $pwd = $ENV{'PWD'}?$ENV{'PWD'}:getcwd();
my %ohdb = ();
my %dboh = ();
my %ohowner = ();
my $OS = `uname`;
chomp $OS;
my $ORA_CRS_HOME;
my $ORA_CRS_USER;
my $patchType;
my $homeType;
my @dbhomes = ();
my @homestopatch = ();
my @homestostart = ();
my ($name, $passwd, $uid, $gid, $quota, $comment, $gcos, $dir, $shell) = getpwuid( $< );
my $crs_running;
my @gipatches = ();
my @dbpatches = ();
my @patchIds = ();
my $isconflictok;
my $op_silent;
my $sihainst = 0;
my $cfg;
my $dest_crshome;

#TBR
my $overbose;

my $unzip;
my $rsh;
my $ssh;
my $su;
my $sed;
my $echo;
my $mkdir;
my $cat;
my $rcp;
my $kill;
my $olrloc;
my $ocrloc;
my $fuser;

if ( $OS eq "Linux")
{
$unzip = "/usr/bin/unzip";
$rsh = "/usr/bin/rsh";
$ssh = "/usr/bin/ssh";
$su = "/bin/su";
$sed = "/bin/sed";
$echo = "/bin/echo";
$mkdir = "/bin/mkdir";
$cat = "/bin/cat";
$rcp = "/usr/bin/rcp";
$kill = "/bin/kill";
$olrloc = "/etc/oracle/olr.loc";
$ocrloc = "/etc/oracle/ocr.loc"; 
$fuser = "/sbin/fuser";
}
elsif ($OS eq "HP-UX")
{
$unzip = "/usr/local/bin/unzip";
$rsh = "/usr/bin/remsh";
$ssh = "/usr/bin/ssh";
$su =  "/usr/bin/su";
$sed = "/usr/bin/sed";
$echo = "/usr/bin/echo";
$mkdir = "/usr/bin/mkdir";
$cat = "/usr/bin/cat";
$rcp = "/usr/bin/rcp";
$kill = "/usr/bin/kill";
$olrloc = "/var/opt/oracle/olr.loc";
$ocrloc = "/var/opt/oracle/ocr.loc";
$fuser = "/usr/sbin/fuser";
}
elsif ($OS eq "AIX" )
{
$unzip = "/usr/local/bin/unzip";
$rsh = "/usr/bin/rsh";
$ssh = "/usr/bin/ssh";
$su =  "/usr/bin/su";
$sed = "/usr/bin/sed";
$echo = "/usr/bin/echo";
$mkdir = "/usr/bin/mkdir";
$cat = "/usr/bin/cat";
$rcp = "/usr/bin/rcp";
$kill = "/usr/bin/kill";
$olrloc = "/etc/oracle/olr.loc";
$ocrloc = "/etc/oracle/ocr.loc";
$fuser = "/usr/sbin/fuser";
}
elsif ( $OS eq "SunOS" )
{
$unzip = "/usr/bin/unzip";
$rsh = "/usr/bin/rsh";
$ssh = "/usr/local/bin/ssh";
$su =  "/usr/bin/su";
$sed = "/usr/bin/sed";
$echo = "/usr/bin/echo";
$mkdir = "/usr/bin/mkdir";
$cat = "/usr/bin/cat";
$rcp = "/usr/bin/rcp";
$kill = "/usr/bin/kill";
$olrloc = "/var/opt/oracle/olr.loc";
$ocrloc = "/var/opt/oracle/ocr.loc";
$fuser = "/usr/sbin/fuser";
}
else
{
  die "ERROR: $OS is an Unknown Operating System\n";
}

# the return code to give when the incorrect parameters are passed
my $usage_rc = 1;

GetOptions('patchfile=s'    => \$patchfile,
           'patchnum=s'     => \$patchnum,
           'paramfile=s'    => \$PARAM_FILE_PATH,
           'rollback'       => \$rollback,
           'oh=s'           => \$ohome,
           'och=s'          => \$chome,
           'ocmrf=s'        => \$ocmrf,
           'norestart'      => \$norestart,
           'unlock!'        => \$g_unlock,
           'patch!'         => \$g_patch,
           'desthome=s'     => \$dest_crshome,
           'help!'          => \$g_help) or pod2usage($usage_rc);


# Check validity of args
pod2usage(-msg => "Invalid extra options passed: @ARGV",
          -exitval => $usage_rc) if (@ARGV);

if ($g_unlock && $dest_crshome) {
   $PARAM_FILE_PATH = catfile ($dest_crshome, 'crs', 'install', "crsconfig_params");
} elsif ($g_patch && $dest_crshome) {
   $PARAM_FILE_PATH = catfile ($dest_crshome, 'crs', 'install', "crsconfig_params");
}

### Set this host name (lower case and no domain name)
our $HOST = tolower_host();
die "$!" if ($HOST eq "");

# Set the following vars appropriately for cluster env
### check if run as super user
our $SUPERUSER = check_SuperUser ();
if (!$SUPERUSER) {
  error("Insufficient privileges to execute this script");
  exit 1;
}

if ( isSIHA()) {
   print "Detected Oracle Restart install\n";
   $sihainst = 1;
} else {
   print "Detected Oracle Clusterware install\n";
}

if ($sihainst) {
   $cfg =
      crsconfig_lib->new(IS_SIHA             => $sihainst,
                     paramfile           => $PARAM_FILE_PATH,
                     osdfile             => $defsfile,
                     crscfg_trace        => TRUE,
                     crscfg_trace_file   => $logfile,
                     HOST                => $HOST
                     );
} else {
   $cfg =
      crsconfig_lib->new(paramfile           => $PARAM_FILE_PATH,
                     osdfile             => $defsfile,
                     crscfg_trace        => TRUE,
                     crscfg_trace_file   => $logfile,
                     HOST                => $HOST,
                     HAS_USER            => $SUPERUSER,
                     UNLOCK              => $g_unlock
                     );
}


if ($g_unlock && $dest_crshome) { unlockPatchHome($dest_crshome); exit 0 }
elsif  ($g_patch && $dest_crshome)  { CRSPatchhome($dest_crshome); exit 0 }


#Subroutines used by this tool


sub getcrshome
{
  my $crsHome;

  if (! $chome) {
    $crsHome = s_get_olr_file ("crs_home")
  } else {
    $crsHome = $chome;
    if ((-f $olrloc) && ($crsHome ne s_get_olr_file ("crs_home"))) {
       error("Incorrect clusterware home path provided for -och option");
       exit 1;
    } 
  }
  if (! -e $crsHome) {
     error("Clusterware home location $crsHome does not exist");
     exit 1;
  }
  return $crsHome;
}

sub read_file
{
    my $file = $_[0];
    open (FILE, "<$file") or die "Can't open $file: $!";
    my @contents = (<FILE>);
    close (FILE);

    return @contents;
}

sub getoracleowner
{ 
  my $oh = $_[0];
  my $getoh_ox = "$oh/bin/oracle";
  my $getoh_u;
  if (  -f $getoh_ox )
  {
     my ($dev, $ino, $mode, $nlink, $uid, $gid, $rdev, $size, $atime, $mtime, $ctime, $blksize, $blocks) = stat( $getoh_ox );
     ($name, $passwd, $uid, $gid, $quota, $comment, $gcos, $dir, $shell) = getpwuid( $uid );
     $getoh_u = $name;
     trace( "Oracle user for $oh is $getoh_u" );
  }
  else {
     error("unable to get oracle owner for $oh");
     exit 1;
  }
  return $getoh_u;
}
  
sub isSIHA
{
   my $ret= FAILED;
   my $local_only = get_config_key("ocr", "local_only");
   if ($local_only =~ m/true/i) {
      $ret = SUCCESS;
   }
   return $ret;
}

sub get_config_key
{
   my $src = $_[0];
   my $key = $_[1];
   $src    =~ tr/a-z/A-Z/;
   my ($val, $cfgfile);

   if ($src eq 'OCR') {
      $cfgfile = $ocrloc;
   }
   elsif ($src eq 'OLR') {
      $cfgfile = $olrloc;
   }

   open (CFGFL, "<$cfgfile") or return $val;
   while (<CFGFL>) {
      if (/^$key=(\S+)/) {
         $val = $1;
         last;
      }
   }

   close (CFGFL);
   return $val;
}

      
sub gentimeStamp
{
  my ($sec, $min, $hour, $day, $month, $year) =
        (localtime) [0, 1, 2, 3, 4, 5];
  $month = $month + 1;
  $year = $year + 1900;

  my $ts = sprintf("%04d-%02d-%02d_%02d-%02d-%02d",$year, $month, $day, $hour, $min, $sec);
  return $ts;
}

sub unlockPatchHome
{
  my $home = $_[0];
  my $exclfile = catfile($home, 'OPatch', 'crs', 'installPatch.excl');
  modifyparamfile("ORACLE_HOME", $home);
  modifyparamfile("CRFHOME", $home);
  modifyparamfile("JREDIR", "$home/jdk/jre/");
  modifyparamfile("JLIBDIR", "$home/jilb");
  $NOCRSSTOP_P = TRUE;
  $unlock_crshome_p=$home;
  unlockCRSHomefordeinstall( $exclfile);
}

sub modifyparamfile
{

   my $param = $_[0];
   my $paramval = $_[1];

   trace("modify $param $CFG->paramfile");

   my $params_file = $CFG->paramfile;
   my @params_table = read_file ($params_file);
   my $updateParamsFile = FALSE;
   my $ix = 0;

   foreach my $rec (@params_table) {
      chomp($rec);
      if ($rec =~ m/^$param=/) {
         my ($key, $value) = split (/=/, $rec);
         $params_table[$ix] = $param . "=" . "$paramval";
         $updateParamsFile = TRUE;
         last;
      }

      $ix++;
   }

   if ($updateParamsFile) {
      # save original params file
      my $save_file = catfile (dirname($params_file), 'crsconfig_params.saved');
      copy_file ($params_file, $save_file);

      # delete old file and create new file
      if (s_remove_file($params_file)) {
         open (SFILE, ">$params_file")
            || die ("Can't open $params_file to write: $!");

         foreach my $rec (@params_table) {
            chomp($rec);
            print SFILE "$rec\n";
         }

         close SFILE;
      }
   }
}


sub unlockCRSHomefordeinstall
{
   trace ("Unlock crshome...");
   my $exclfile = $_[0];
   my $statusCRS;

   trace("Exclude file used is $exclfile");

   my $unlock_crshome1;

   if (!$CFG->UNLOCK) { $CFG->UNLOCK(TRUE); }

   #Try to get the home path from olr.loc
   $unlock_crshome1 = s_get_olr_file ("crs_home");
   trace ("Home location in olr.loc is $unlock_crshome_p");

   if (! $unlock_crshome1)
   {
      $unlock_crshome1 = $unlock_crshome_p;
   }

   if ($unlock_crshome_p) {
        if ($NOCRSSTOP_P && ($unlock_crshome_p eq $unlock_crshome1)) {
           error("You can't unlock an active CRS home");
        }
        elsif ($NOCRSSTOP_P) {
           $unlock_crshome1 = $unlock_crshome_p;
        }
   }


   # validate if crshome exists
   if (! -e $unlock_crshome1) {
      error  "crshome: $unlock_crshome1 not found\n";
      return FALSE;
   }

   if (! $NOCRSSTOP_P) {
      $statusCRS = stopClusterware($unlock_crshome1, "crs");
   } else { $statusCRS = SUCCESS; }


   if ($statusCRS) {
      s_reset_crshome1($ORACLE_OWNER, $ORA_DBA_GROUP, 755, $unlock_crshome1, $exclfile);
      print "Successfully unlock $unlock_crshome1\n";
   } else {
      print "The Oracle Clusterware stack failed to stop.\n";
      print "You should stop the stack with 'crsctl stop crs' and rerun the command\n";
   }
}

sub stopClusterware
#-------------------------------------------------------------------------------
# Function: Stop crs / cluster 
# Args    : Resource (crs/cluster)
# Returns : TRUE  if success
#           FALSE if failed
#-------------------------------------------------------------------------------
{
   my ($home, $res) = @_;
   my $crsctl;

   if (! defined $home) {
     $crsctl = crs_exec_path('crsctl');
   } else {
     $crsctl = catfile( $home, 'bin', 'crsctl' );
   }
   my $success  = TRUE;

   if (! -x $crsctl) {
      error ("$crsctl does not exist to proceed stop clusterware");
      return FALSE;
   }

   # stop resource
   my @cmd;
   if ($res eq 'crs') {
      @cmd = ($crsctl, 'stop', 'crs', '-f');
   }
   else {
      @cmd = ($crsctl, 'stop', 'resource', '-all', '-init');
   }

   my @out = system_cmd_capture (@cmd);
   my $rc = shift @out;
   trace ("@cmd");

   if (! checkServiceDown("cluster")) {
      print "You must kill crs processes or reboot the system to properly \n";
      print "cleanup the processes started by Oracle clusterware\n";
      return FALSE;
   }

   # check if ohasd & crs are still up
   if ($res eq 'crs') {
      if (! checkServiceDown("ohasd")) {
         error "Unable to stop CRS\n";
         $success = FALSE;
      }
   }

   return $success;
}

####---------------------------------------------------------
#### Function for resetting owner and permissions of CRS home dirs/files
# ARGS : 5
# ARG1 : Oracle owner
# ARG2 : Oracle group
# ARG3 : perms
# ARG4 : directory path
# ARG5 : exclude file path
sub s_reset_crshome1
{
    if (is_dev_env()) {
        return $SUCCESS;
    }

    my ($owner, $group, $perms, $basedir,$exclfile) = @_;

    if (!$owner) {
        error ("Null value passed for Oracle owner");
        return $FAILED;
    }

    if (!$group) {
        error ("Null value passed for group name");
        return $FAILED;
    }

    my $userid   = getpwnam ($owner);
    my $groupid  = getgrnam ($group);

    my @excl_dir = ();

    if (-e $exclfile)
    {
      @excl_dir = read_file ($exclfile);
    }

    # reset owner/group of directory name of basedir
    # and its parent dir to ORACLE_OWNER/DBA
    finddepth (\&reset_perms, $basedir);

    sub reset_perms
    {
      #Just give write permissions to grid owner for all files
      #during reset and exclude links .
      if (! -l $_) {
         my ($dev,$ino,$mode) = lstat($_);
         $perms = S_IMODE($mode);
         my $origperm = sprintf "%04o", $perms;
         $perms = $perms | 128;
         my $newperm = sprintf "%04o", $perms;

         if (SetPerms()) {
           if ($DEBUG) {
              trace("orig perm for $_ is $origperm, setting file perm to $newperm");
           }

         chown ($userid, $groupid, $_);
         chmod (oct ($newperm), $_);
         }
      }
    }

    sub SetPerms
    {
       if (! $CFG->UNLOCK) {
          return TRUE;
       }

       # if UNLOCK, bypass files that are in exclude dir
       my $setperms = TRUE;
       foreach my $dir (@excl_dir) {
          chomp ($dir);
          next if ($dir =~ /^#|^\s*$/);  # skip blanks and comments

          # do not set perms if file is on execluded dir
          if ($File::Find::dir =~ /$dir/) {
              $setperms = FALSE;
          }
       }

       return $setperms;
    }

    return $SUCCESS;
}


sub CRSPatchhome
{
   my $destcrshome = $_[0];
   my $actcrshome  = s_get_olr_file ("crs_home");

   stopClusterware($actcrshome, "crs");


   #update olr
   s_validate_olrconfig($CFG->OLR_LOCATION, $destcrshome);

   CRSPatch ();

}

sub CRSPatch
{

   my $nostrtflg = $_[0];

   trace ("Patching Oracle Clusterware");
   trace ("norestart flag is set to $nostrtflg");

   #Instantiate the patched files.
   Instantiatepatchfiles ();

   installUSMDriver();

   if (! $nostrtflg) {
      StartCRS();
   }
}


sub Instantiatepatchfiles
{
   #TODO - Should we just rely on crsconfig_params or
   #should we derive the critical values.
   instantiate_scripts ();

   $ORA_CRS_HOME = $dest_crshome;

   my @crsconfig_dirs = read_file (catfile ($ORA_CRS_HOME, 'crs', 'utl',
                                            'crsconfig_dirs'));
   create_dirs (\@crsconfig_dirs);

   copy_wrapper_scripts ();

   my @crsconfig_fileperms = read_file (catfile ($ORA_CRS_HOME, 'crs', 'utl',
                                                  "crsconfig_fileperms"));
   set_file_perms (\@crsconfig_fileperms);

   #set the ownership/permission of olr
   if ($CFG->IS_SIHA) {
     s_set_ownergroup ($ORACLE_OWNER, $ORA_DBA_GROUP, $CFG->OLR_LOCATION);
   } else {
     s_set_ownergroup ($CFG->SUPERUSER, $ORA_DBA_GROUP, $CFG->OLR_LOCATION);
   }
   s_set_perms ("0600", $CFG->OLR_LOCATION);

   #copy init.ohad,ohasd to init/rc dirs
   s_register_service("ohasd");
}

####-----------------------------------------------------------------------
#### Function for validating olr.loc file and creating it if does not exist
# ARGS: 2
# ARG1 : Complete path of OLR location
# ARG2 : CRS Home
sub s_validate_olrconfig
{
    my $olrlocation = $_[0];
    my $crshome     = $_[1];

    trace ("Validating " . $OLRCONFIG .
           " file for OLR location " . $olrlocation);

    ## @todo Check existing olr.loc file. If it exists, then check value of
    #  olrconfig_loc property. If it's same as the one passed on the call
    #  then go ahead. Else, throw an error msg and quit the installation.
    if (-f $OLRCONFIG) {
        trace ("$OLRCONFIG already exists. Backing up " . $OLRCONFIG .
               " to " . $OLRCONFIG . ".orig");
        # Need to remove this once the @todo is implemented.
        copy ($OLRCONFIG, $OLRCONFIG . ".orig") or return $FAILED;
    }

    open (OLRCFGFILE, ">$OLRCONFIG") or return $FAILED;
    print OLRCFGFILE "olrconfig_loc=$olrlocation\n";
    print OLRCFGFILE "crs_home=$crshome\n";
    close (OLRCFGFILE);

    #FIXME: This should be moved to add_olr_ocr_vdisks_locs
    if (is_dev_env()) {
       s_set_ownergroup ($ORACLE_OWNER, $ORA_DBA_GROUP, $OLRCONFIG);
    }
    else {
       s_set_ownergroup ($SUPERUSER, $ORA_DBA_GROUP, $OLRCONFIG);
    }

    s_set_perms ("0644", $OLRCONFIG);

    trace("Done setting permissions on file $OLRCONFIG");

    return $SUCCESS;
}

     
0;
