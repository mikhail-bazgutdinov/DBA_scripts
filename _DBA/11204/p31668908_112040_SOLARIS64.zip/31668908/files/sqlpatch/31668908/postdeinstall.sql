rem
rem Name: postinstall.sql
rem
rem Bug: 31668908
rem

VARIABLE rdbmsLogDir        VARCHAR2(500);
VARIABLE sqlLogDir          VARCHAR2(500);
VARIABLE createDirCmd       VARCHAR2(600);
VARIABLE kolfuseslf         VARCHAR2(50);

REM Init the variable to its default value
BEGIN :kolfuseslf := 'FALSE'; END;
/

-- Returns TRUE if the specified directory exists and is writable.
-- If there are any errors encountered while opening the directory and writing
-- a test file (using utl_file) then false is returned.
-- Note that only one session should call this at a time because the directory
-- is not session specific.
-- Added for bug 17343514.
CREATE OR REPLACE FUNCTION dir_exists_and_is_writable(dirname IN VARCHAR2)
  RETURN BOOLEAN
IS
PRAGMA AUTONOMOUS_TRANSACTION;  -- executes DDL 

  fp UTL_FILE.FILE_TYPE;

BEGIN
  -- Try to create directory object
  BEGIN
    EXECUTE IMMEDIATE 
      'CREATE OR REPLACE DIRECTORY dbms_registry_testdir AS ' ||
       dbms_assert.enquote_literal(dirname);
  EXCEPTION
    WHEN OTHERS THEN
      -- We want to just quit here since the directory object can't be created
      RETURN FALSE;
  END;

  -- Attempt to open a file, close it, and then delete it.
  fp := UTL_FILE.FOPEN('DBMS_REGISTRY_TESTDIR',
                       'dbms_registry_testfile.txt', 'a');
  UTL_FILE.FCLOSE(fp);
  UTL_FILE.FREMOVE('DBMS_REGISTRY_TESTDIR', 'dbms_registry_testfile.txt');

  EXECUTE IMMEDIATE 'DROP DIRECTORY dbms_registry_testdir';

  -- If we get here we're good
  RETURN TRUE;
EXCEPTION
  WHEN OTHERS THEN
    -- Try to drop the directory first
    BEGIN
      EXECUTE IMMEDIATE 'DROP DIRECTORY dbms_registry_testdir';
    EXCEPTION
      WHEN OTHERS THEN null;
    END;

    -- And return FALSE.  We don't care what the error was.
    RETURN FALSE;
END dir_exists_and_is_writable;
/

REM Determine the names of interesting directories and create them if
REM necessary.

DECLARE
  platform v$database.platform_name%TYPE;
  homeDir  VARCHAR2(500);
  baseDir  VARCHAR2(500);
  useDir   VARCHAR2(500);

BEGIN
  -- Determine ORACLE_HOME value and admin dir
  SELECT NLS_UPPER(platform_name)
    INTO platform
    FROM v$database;

  DBMS_SYSTEM.GET_ENV('ORACLE_BASE', baseDir);
  DBMS_SYSTEM.GET_ENV('ORACLE_HOME', homeDir);

  IF baseDir IS NOT NULL THEN
    useDir := baseDir;
  ELSE
    useDir := homeDir;
  END IF;

  IF INSTR(platform, 'WINDOWS') != 0 THEN
    -- Windows, use '\'
    useDir := RTRIM(useDir, '\');  -- Remove any trailing slashes
    :sqlLogDir := useDir || '\cfgtoollogs\postinstall\';
    :createDirCmd := 'mkdir ' || :sqlLogDir;
    :rdbmsLogDir := homeDir || '\rdbms\log\';
  ELSIF INSTR(platform, 'VMS') != 0 THEN
    -- VMS, use [] and .
    :sqlLogDir := REPLACE(useDir || '[cfgtoollogs.postinstall]', '][', '.');
    :createDirCmd := 'CREATE/DIR ' || :sqlLogDir;
    :rdbmsLogDir := REPLACE(homeDir || '[rdbms.log]', '][', '.');
  ELSE 
    -- Unix and z/OS, '/'
    useDir := RTRIM(useDir, '/');  -- Remove any trailing slashes
    :sqlLogDir := useDir || '/cfgtoollogs/postinstall/';
    :createDirCmd := 'mkdir -p ' || :sqlLogDir;
    :rdbmsLogDir := homeDir || '/rdbms/log/';
  END IF;

  IF dir_exists_and_is_writable(:sqlLogDir) THEN
    -- Log directory already exists, we don't need to create it
    :createDirCmd := 'exit';
  END IF;

  EXCEPTION
    WHEN OTHERS THEN
      null;
END;
/
set verify off
set feedback off

COLUMN create_cmd NEW_VALUE create_cmd NOPRINT
SELECT :createDirCmd AS create_cmd FROM dual;
HOST &create_cmd

REM Turn spooling on 
COLUMN postinstall_logfile NEW_VALUE postinstall_logfile NOPRINT
SELECT NULL AS postinstall_logfile FROM DUAL WHERE 1 = 0;
SELECT NVL( q'{&postinstall_logfile}',
                 :sqlLogDir || 'postinstall_' || name ||
                 TO_CHAR(SYSDATE, 'YYYYMonDD_hh24_mi_ss',
                                  'NLS_DATE_LANGUAGE=''AMERICAN''') ||
                 '.log' )
  AS postinstall_logfile
FROM v$database;

set verify on
set feedback on

SPOOL &postinstall_logfile APPEND
PROMPT Check &postinstall_logfile for errors

rem Create registry$history

ALTER SESSION SET CURRENT_SCHEMA = SYS;

declare
  lv_create_stmt varchar2(1000) := 'create table registry$history (action_time timestamp(6), action varchar2(30), namespace varchar2(30), version varchar2(30), id number, comments varchar2(255), bundle_series varchar2(30))';
begin
  execute immediate lv_create_stmt;
  exception
    when others then
      null;
end;
/



SET PAGESIZE 0
SELECT 'Calling javavm/install/jvmpsupdi.sql on ' || SYSTIMESTAMP FROM dual;
SET PAGESIZE 10

@?/javavm/install/jvmpsupdi.sql


rem Update registry$history

ALTER SESSION SET CURRENT_SCHEMA = SYS;
declare
  lv_insert_stmt varchar2(1000) := 'insert into registry$history (action_time, action, id, comments) values (systimestamp, ''ROLLBACK'', 31668908, ''Patch 31668908 rolled back'')'; 
begin
  execute immediate lv_insert_stmt;
  exception
    when others then
      null;
end;
/
commit;
set head off
select * from registry$history order by id;

