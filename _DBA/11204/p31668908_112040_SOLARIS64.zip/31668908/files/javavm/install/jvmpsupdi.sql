Rem
Rem $Header: javavm/install/jvmpsupdi.sql /st_javavm_11.2.0.4.0dbpsu/1 2014/11/02 20:19:06 nneeluru Exp $
Rem
Rem jvmpsupdi.sql
Rem
Rem Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.
Rem
Rem    NAME
Rem      jvmpsupdi.sql - OJVM PSU post-deinstall 
Rem
Rem    DESCRIPTION
Rem
Rem    NOTES
Rem      This script will be the single script exposed as the post-deinstall
Rem      script for OJVM PSU.
Rem
Rem    BEGIN SQL_FILE_METADATA 
Rem    SQL_SOURCE_FILE: javavm/install/jvmpsupdi.sql 
Rem    SQL_SHIPPED_FILE: 
Rem    SQL_PHASE: 
Rem    SQL_STARTUP_MODE: NORMAL 
Rem    SQL_IGNORABLE_ERRORS: NONE 
Rem    SQL_CALLING_FILE: 
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    nneeluru    10/29/14 - OJVM PSU post-deinstall
Rem    nneeluru    10/29/14 - Created
Rem

SET ECHO ON
SET FEEDBACK 1
SET NUMWIDTH 10
SET LINESIZE 80
SET TRIMSPOOL ON
SET TAB OFF
SET PAGESIZE 100

variable jvmscript varchar2(50);
column :jvmscript new_value jvm_script noprint;

declare
  stat varchar2(30);
begin
  :jvmscript := '?/javavm/install/jvmempty.sql';
  select status into stat from dba_registry where comp_id = 'JAVAVM';
  if stat != 'REMOVED' then
    :jvmscript := '?/javavm/install/jvmpsupdii.sql';
  end if;
exception when no_data_found then null;
end;
/

select :jvmscript from dual;

@@&jvm_script

