Rem
Rem $Header: javavm/install/jvmpsu.sql /st_javavm_11.2.0.4.0dbpsu/5 2019/03/26 03:54:33 mohshanm Exp $
Rem
Rem jvmpsu.sql
Rem
Rem Copyright (c) 2013, 2019, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      jvmpsu.sql - JAVAVM Patch Set Update script
Rem
Rem    DESCRIPTION
Rem      Script to be run during post-install and post-deinstall in a PSU.
Rem
Rem    NOTES
Rem      To be run as SYS
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    mohshanm    03/25/19 - Backport mohshanm_pilpsu from
Rem                           st_javavm_11.2.0.4.0dbpsu
Rem    nneeluru    10/29/14 - Move all the stuff to jvmpsui.sql
Rem    nneeluru    10/07/14 - Re-open to fix insert statement
Rem    nneeluru    10/04/14 - Backport nneeluru_bug-19699946 from main
Rem    nneeluru    08/16/13 - JAVAVM post-install script for PSU
Rem    nneeluru    08/16/13 - Created
Rem
Rem    BEGIN SQL_FILE_METADATA 
Rem    SQL_SOURCE_FILE: javavm/install/jvmpsu.sql 
Rem    SQL_SHIPPED_FILE: javavm/install/jvmpsu.sql 
Rem    SQL_PHASE: post-install for a PSU
Rem    SQL_STARTUP_MODE: NORMAL 
Rem    SQL_IGNORABLE_ERRORS: NONE 
Rem    SQL_CALLING_FILE: catbundle.sql
Rem    END SQL_FILE_METADATA

SET ECHO ON
SET FEEDBACK 1
SET NUMWIDTH 10
SET LINESIZE 80
SET TRIMSPOOL ON
SET TAB OFF
SET PAGESIZE 100


variable jvmaction varchar2(10)
execute :jvmaction := 'NONE';
variable jvmscript varchar2(50);
column :jvmscript new_value jvm_script noprint;

declare
  stat varchar2(30);
begin
  :jvmscript := '?/javavm/install/jvmempty.sql';
  select status into stat from dba_registry where comp_id = 'JAVAVM';
  if stat != 'REMOVED' then
    :jvmscript := '?/javavm/install/jvmpsui.sql';
  end if;
exception when no_data_found then null;
end;
/

select :jvmscript from dual;

@@&jvm_script

