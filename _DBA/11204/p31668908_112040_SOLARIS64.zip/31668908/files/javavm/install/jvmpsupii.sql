Rem
Rem $Header: javavm/install/jvmpsupii.sql /st_javavm_11.2.0.4.0dbpsu/28 2020/08/18 21:51:20 sbusa Exp $
Rem
Rem jvmpsupii.sql
Rem
Rem Copyright (c) 2014, 2020, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      jvmpsupii.sql - OJVM PSU post-install internal 
Rem
Rem    DESCRIPTION
Rem
Rem    NOTES
Rem      This script is run by jvmpsupi.sql if JAVAVM is installed in the
Rem      database.  It needs to contain all the post-install actions for 
Rem      the OJVM PSU.
Rem
Rem    BEGIN SQL_FILE_METADATA 
Rem    SQL_SOURCE_FILE: javavm/install/jvmpsupii.sql 
Rem    SQL_SHIPPED_FILE: 
Rem    SQL_PHASE: 
Rem    SQL_STARTUP_MODE: NORMAL 
Rem    SQL_IGNORABLE_ERRORS: NONE 
Rem    SQL_CALLING_FILE: 
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    sbusa       08/18/20 - Backport sbusa_oct20_11.2.0.4_jdk7 from
Rem                           st_javavm_11.2.0.4.0dbpsu
Rem    sbusa       05/22/20 - Backport sbusa_july20_11.2.0.4_jdk7_2 from
Rem                           st_javavm_11.2.0.4.0dbpsu
Rem    sbusa       02/13/20 - Backport sbusa_apr20_11.2.0.4_jdk7 from
Rem                           st_javavm_11.2.0.4.0dbpsu
Rem    sbusa       11/26/19 - Backport sbusa_jan20_psu_11.2.0.4_jdk7 from
Rem                           st_javavm_11.2.0.4.0dbpsu
Rem    mohshanm    08/31/19 - Backport mohshanm_octmpsu from
Rem                           st_javavm_11.2.0.4.0dbpsu
Rem    mohshanm    05/30/19 - Backport mohshanm_psujly from
Rem                           st_javavm_11.2.0.4.0dbpsu
Rem    mohshanm    03/25/19 - Backport mohshanm_pilpsu from
Rem                           st_javavm_11.2.0.4.0dbpsu
Rem    sbusa       08/28/17 - Backport sbusa_oct_17_11.2.0.4_jdk6 from
Rem                           st_javavm_11.2.0.4.0dbpsu
Rem    sbusa       05/29/17 - Backport sbusa_l_july17_11.2.0.4_jdk6 from
Rem                           st_javavm_11.2.0.4.0dbpsu
Rem    sbusa       02/18/17 - Backport sbusa_apr17_11.2.0.4_jdk6 from
Rem                           st_javavm_11.2.0.4.0dbpsu
Rem    sbusa       11/17/16 - Backport sbusa_j17_l_11.2.0.4_jdk6 from
Rem                           st_javavm_11.2.0.4.0dbpsu
Rem    sbusa       09/01/16 - Backport sbusa_o_l_11.2.0.4_jdk6_2 from
Rem                           st_javavm_11.2.0.4.0dbpsu
Rem    sbusa       05/31/16 - Backport sbusa_j5_l_11.2.0.4_jdk6 from
Rem                           st_javavm_11.2.0.4.0dbpsu
Rem    sbusa       02/23/16 - Backport sbusa_javavm_11.2.0.4_java6_april16 from
Rem                           st_javavm_11.2.0.4.0dbpsu
Rem    mohshanm    11/11/15 - Backport mohshanm_psujan_11204 from
Rem                           st_javavm_11.2.0.4.0dbpsu
Rem    mohshanm    09/11/15 - Backport mohshanm_bug-21811517 from
Rem                           st_javavm_11.2.0.4.0dbpsu
Rem    nneeluru    12/03/14 - Add commit after insert
Rem    nneeluru    10/29/14 - OJVM PSU post-install internal
Rem    nneeluru    10/29/14 - Created
Rem

SET ECHO ON
SET FEEDBACK 1
SET NUMWIDTH 10
SET LINESIZE 80
SET TRIMSPOOL ON
SET TAB OFF
SET PAGESIZE 100

variable jvmaction varchar2(10)
execute :jvmaction := 'APPLY';

begin
  execute immediate 'revoke execute on sys.dbms_java_misc from public';
exception when others
then null;
end;
/

begin
  initjvmaux.drp('drop user ojvmsys cascade');
  exception when others then
  if sqlcode not in (-1435, -1918) then raise; end if;
end;
/

@@?/javavm/install/initsqlj.sql
@@?/javavm/install/initdbj.sql
@@?/javavm/install/jvmpsu1.sql

begin
  execute immediate 'drop package SYS.sqljutl2';
exception when others
then null;
end;
/

insert into
 registry$history (action_time, action, namespace, version, id, comments)
 values (SYSTIMESTAMP, 'APPLY', 'SERVER', '11.2.0.4.201020OJVMPSU',
         0, 'OJVM PSU post-install');

commit;

