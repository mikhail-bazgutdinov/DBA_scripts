#!/usr/local/bin/perl -w

use strict;

use File::Copy qw(move);
use File::Basename;
use File::Path;
use File::Temp;

sub generate_client_tool;


$ENV{JAVAVMINST} = "$ENV{ORACLE_HOME}/javavm/install" unless (defined $ENV{JAVAVMINST});
$ENV{JAVAVMUTL} = "$ENV{ORACLE_HOME}/javavm/utl" unless (defined $ENV{JAVAVMUTL});
$ENV{FAMILY} = 'unix' unless (defined $ENV{FAMILY});


&generate_client_tool ('loadjava');
&generate_client_tool ('dropjava');
&generate_client_tool ('ojvmjava');
&generate_client_tool ('ojvmtc');

sub generate_client_tool {

  my $arg = shift;

  unlink "$ENV{ORACLE_HOME}/bin/$arg";

  my $input_file = "$ENV{JAVAVMINST}/sbs/$arg\.sbs";
  my $output_file = "$ENV{ORACLE_HOME}/bin/$arg";
  my $OH = $ENV{ORACLE_HOME};

  open (INF, $input_file) || die "Cannot open file $input_file for read";
  my @lines = <INF>;
  close INF;
  
    
  open (OUTF, '>', $output_file) || die "Cannot open $output_file file for write";
  
  foreach my $line (@lines) {
    $line =~ s/%s_jreLocation%/$OH\/jdk\/jre/g;
    $line =~ s/%s_jreRunCmd%/java/g;
    $line =~ s/%s_jreJREclassfile%/$OH\/jdk\/jre\/lib\/rt.jar\:$OH\/jdk\/jre\/lib\/i18n.jar/g;
    $line =~ s/jdk15/jdk/g;
    print OUTF "$line";
  }

  close OUTF;
  chmod 0755, $output_file;
}

