
create or replace package sqljutl2 AUTHID CURRENT_USER as
   -- The following APIs are used for native invocation of
   -- server-side Java code
   FUNCTION evaluate(args LONG RAW) RETURN LONG RAW;
   FUNCTION invoke(handle NUMBER, class VARCHAR2, name VARCHAR2, sig VARCHAR2, args LONG RAW) RETURN LONG RAW;
   FUNCTION invoke(class VARCHAR2, name VARCHAR2, sig VARCHAR2, args LONG RAW) RETURN LONG RAW;
   FUNCTION reflect(class_Or_Package VARCHAR2, only_Declared NUMBER) RETURN LONG;
   FUNCTION reflect2(class_Or_Package VARCHAR2, only_Declared NUMBER) RETURN CLOB;
end sqljutl2;
/

create or replace package body sqljutl2 as

   FUNCTION evaluate(args LONG RAW) RETURN LONG RAW
   AS LANGUAGE JAVA
   NAME 'oracle.jpub.reflect.Server.evaluate(byte[]) return byte[]';

   FUNCTION invoke(class VARCHAR2, name VARCHAR2, sig VARCHAR2, args LONG RAW) RETURN LONG RAW
   AS LANGUAGE JAVA
   NAME 'oracle.jpub.reflect.Server.invoke(java.lang.String,java.lang.String,java.lang.String,byte[]) return byte[]';

   FUNCTION invoke(handle NUMBER, class VARCHAR2, name VARCHAR2, sig VARCHAR2, args LONG RAW) RETURN LONG RAW
   AS LANGUAGE JAVA
   NAME 'oracle.jpub.reflect.Server.invoke(java.lang.Long,java.lang.String,java.lang.String,java.lang.String,byte[]) return byte[]';

   FUNCTION reflect(class_Or_Package VARCHAR2, only_Declared NUMBER) RETURN LONG
   AS LANGUAGE JAVA
   NAME 'oracle.jpub.reflect.Server.reflect(java.lang.String,int) return java.lang.String';

   FUNCTION reflect2(class_Or_Package VARCHAR2, only_Declared NUMBER) RETURN CLOB 
   AS LANGUAGE JAVA
   NAME 'oracle.jpub.reflect.Server.reflect2(java.lang.String,int) return oracle.sql.CLOB';

end sqljutl2;
/

