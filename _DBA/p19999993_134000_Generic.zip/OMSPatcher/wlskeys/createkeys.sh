#!/bin/sh
#
# $Header: opatchauto/oms/wlskeys/createkeys.sh /st_opatchauto_pt-em13.4mos/2 2020/11/25 21:13:32 sallam Exp $
#
# createkeys.sh
#
# Copyright (c) 2013, 2020, Oracle and/or its affiliates. 
#
#    NAME
#      createkeys.sh - <one-line expansion of the name>
#
#    DESCRIPTION
#      <short description of component this file declares/defines>
#
#    NOTES
#      <other useful comments, qualifications, etc.>
#
#    MODIFIED   (MM/DD/YY)
#    sallam      07/15/19 - adding wlst.sh to create the key
#    skkurapa    11/04/14 - MW_HOME willbe OMS Home in nexgen
#			    WLST_HOME will be OH/oracle_comon/common/wlst
#			    SCRIPTPATH will be OH/oracle_common/common/bin
#    vganesan    06/10/14 - Change echo to printf
#    skkurapa    03/06/14 - XbranchMerge skkurapa_bug-18350825 from
#                           st_opatchauto_pt-em12.1
#    vganesan    11/28/13 - Add friendly wait remainders for weblogic processing
#                           time
#    vganesan    09/15/13 - Creation, move away from OPatch core
#

### main ###
binname=`basename $0`
dirpath=`dirname $0`
dirpath=`cd ${dirpath}; pwd`

### parse ###
oh=${ORACLE_HOME}
location=
getoh=0
getloc=0
gethelp=0

for arg in $@
do
    if [ $getoh = 1 ]; then
        oh=$arg
        getoh=2
    fi
    if [ $getloc = 1 ]; then
        location=$arg
        getloc=2
    fi

    if [ "$arg" = "-oh" ]; then
        getoh=1
    fi
    if [ "$arg" = "-location" ]; then
        getloc=1
    fi
    if [ "$arg" = "-help" ]; then
        gethelp=1
    fi
done

### help ###
if [ $gethelp = 1 ] || [ -z "${oh}" -o -z "${location}" ]; then
    echo "Usage:"
    echo "      ${binname} [-help]"
    echo "      ${binname} -oh <OMS Platform home> -location <location to store the config and key files>"
    echo ""
    echo "                 -oh       OMS Platform home path"
    echo "                 -location Location to store the configuration and key files"
    exit 1
fi

### check ###
if [ ! -d "$oh" ]; then
    echo "ERROR: Invalid home. Please check and pass OMS platform home through -oh option."
    exit 1;
else
    oh=`cd "$oh"; pwd`
fi
if [ ! -d "$location" ]; then
    echo "ERROR: Invalid location. Please check location input and try again."
    exit 1
else
    location=`cd "$location"; pwd`
fi

MW_HOME=`cd "${oh}"; pwd`
if [ -f "${MW_HOME}/domain-registry.xml" -a -f "${oh}/bin/emcli" ]; then
    echo "The oraclehome passed is valid."
else
    echo "ERROR: Invalid home. Please check and pass OMS platform home through -oh option."
    exit 1;
fi

printf "Please enter weblogic admin server username: "
read username
printf "Please enter weblogic admin server password: "
stty -echo
read password
stty echo
echo ""

#delete config and key files if exists in the location provided
if [ -f "$location/key" ] ; then
         rm "$location/key"
fi

if [ -f "$location/config" ] ; then
        rm "$location/config"
fi

value=`cat $oh/sysman/config/emInstanceMapping.properties  | grep EMGC_OMS | cut -d "=" -f2`
#echo "$value"

as_host=`cat $value | grep AS_HOST | cut -d "=" -f2`
#echo "$as_host"

as_port=`cat $value | grep AS_HTTPS_PORT | cut -d "=" -f2`
#echo "$as_port"

wls_url="t3s://$as_host:$as_port"
#echo "$wls_url"

export WLST_PROPERTIES="-Dweblogic.security.TrustKeyStore=DemoTrust $WLST_PROPERTIES"

echo "Trying to get configuration and key files for the given inputs..."
echo "This operation will take some time. Please wait for updates..."

cmd_output=`$oh/oracle_common/common/bin/wlst.sh << !
connect('$username','$password','$wls_url')
storeUserConfig('$location/config','$location/key')
!`

#echo "$cmd_output"

flag=`echo $cmd_output|awk '{print match($0,"WebLogic Server connection")}'`;

if [ $flag -gt 0 ];then
    echo "'createkeys' succeeded.";
else
    echo "'createkeys' failed.";
fi

