#!/usr/bin/python    
import ConfigParser
import sys
import os
import java.util.Date as Date

def logMsg(msg):
    d = Date()
    print d
    print msg

def logFatalError(msg):
     sys.stderr.write(msg + "\n")
     logMsg(msg)

try:
    logMsg("Storing WLS User configuration")
    
    if len(sys.argv) != 4:
        print "Incorrect number of arguments specified"
        sys.exit(1)

    admin_server_url = sys.argv[1];
    print "Admin url: " + admin_server_url

    config_prop_file = sys.argv[2];
    print "Admin Config File: " + config_prop_file

    key_file = sys.argv[3];
    print "Key File : " + key_file
    
    print "Please enter weblogic admin server username :";
    admin_user = os.environ.get('username')
    print "Enter Admin user's password: ";
    admin_pwd = os.environ.get('password')
#    print "admin user : "+admin_user 
#    print "admin password : "+admin_pwd 
    logMsg("Connecting to AdminServer")
    connect(admin_user, admin_pwd, admin_server_url)
    storeUserConfig(config_prop_file, key_file)
    disconnect()
except:
    dumpStack()
    (c, i, tb) =  sys.exc_info()
    print 'Name of Exception: ' + str(c)
    print 'Code of Exception: ' + str(i)
    logFatalError("SEVERE: Exception occurred while creating admin key file")
    sys.exit(-1)
