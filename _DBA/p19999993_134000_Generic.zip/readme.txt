Summary
-------
This is README file for OMSPatching tool, which is used for patching Enterprise Manager Release 13.4.0.0.0

This patch installs the "OMSPatcher" utility. OMSPatcher is used for patching Enterprise Manager.
 
If you have an older version of OMSPatcher it is strongly recommended to back it up before upgrading to the new OMSPatcher.



How to install the utility:
---------------------------

To install this patch, Please extract the file "zipped file" using unzip or winzip,
depending upon the platform. You should extract the zip file directly under the
ORACLE_HOME. Please follow the following steps for extracting the zip file of OMSPatcher.

(1)  Please take a backup of ORACLE_HOME/OMSPatcher into a dedicated backup
location.
(2) Please make sure no directory ORACLE_HOME/OMSPatcher exist.
(3) Please unzip the OMSPatcher downloaded zip into ORACLE_HOME directory.



============================================================================

