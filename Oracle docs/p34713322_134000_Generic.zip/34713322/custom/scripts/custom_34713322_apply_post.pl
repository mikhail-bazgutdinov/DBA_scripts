#!/usr/bin/perl
# 
# $Header: emagent/notes/custom_34713322_rollback_post.pl vaudinar_blr_backport_34713322_13.4.0.0.0/1 2022/10/29 08:56:13 vaudinar Exp $
#
# custom_34713322_rollback_post.pl
# 
# Copyright (c) 2022, Oracle and/or its affiliates. 
#
#    NAME
#      custom_34713322_rollback_post.pl - <one-line expansion of the name>
#
#    DESCRIPTION
#      <short description of component this file declares/defines>
#
#    NOTES
#      <other useful comments, qualifications, etc.>
#
#    MODIFIED   (MM/DD/YY)
#    vaudinar    10/29/22 - Creation
# 
 use File::Copy;
 use File::Find;
 use File::Path;
 
 if ("$ENV{ORACLE_HOME}" eq "")
 {
   print "ORACLE_HOME env variable not set. Exiting...\n";
   exit 1;
 }
 
 my $AGENT_JLIB = File::Spec->catfile(
     $ENV{ORACLE_HOME}, 
     "jlib");
 
 
 if (-e $AGENT_JLIB && -d $AGENT_JLIB) {
 
    my $file_to_delete = "$AGENT_JLIB/commons-text-1.8.jar";

	# If we are dealing with Windows, the ORACLE_HOME will have backslashes.
    ## We need to replace the backslashes with forward slashes
    $file_to_delete =~ s/\\/\//g;
    print "Removing file $file_to_delete \n";
    my $remove_status = unlink($file_to_delete);

    print "Removed file status $remove_status \n";
 
 } else {
 
    print "AGENT_JLIB path $AGENT_JLIB does not exists. Exiting...\n";
    exit 1;
 
 }

