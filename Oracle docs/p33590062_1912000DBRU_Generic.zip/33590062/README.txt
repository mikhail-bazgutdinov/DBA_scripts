Oracle Database 19 Release 19.12.0.0.210720DBRU

ORACLE DATABASE Patch for Bug# 33590062 for Generic Platforms

This patch is non-RAC Rolling Installable.

This patch is non-Data Guard Standby-First Installable - Please read My Oracle Support Note 1265700.1 https://support.us.oracle.com/oip/faces/secure/km/DocumentDisplay.jspx?id=1265700.1
Oracle Patch Assurance - Data Guard Standby-First Patch Apply for details on how to remove risk and reduce downtime when applying this patch. 

Released: Tue Apr 12 11:51:00 2022
  
This document describes how you can install the ORACLE DATABASE overlay patch for bug#  33590062 on your Oracle Database 19 Release 19.12.0.0.210720DBRU
 

 
(I) Prerequisites
--------------------
Before you install or deinstall the patch, ensure that you meet the following requirements:

Note: In case of an Oracle RAC environment, meet these prerequisites on each of the nodes.

1.	Ensure that the Oracle home on which you are installing the patch or from which you are rolling back the patch is Oracle Database 19 Release 19.12.0.0.210720DBRU.
 
2.	Ensure that 19 Release 19.12.0.0.210720DBRU Patch Set Update (PSU) 32904851 is already applied on the Oracle Database.

3.      Ensure that you have OPatch 19 Release 12.2.0.1.25 or higher. Oracle recommends that you use the latest version available for  19 Release 12.2.0.1.25. 
	
	Note:
	If you do not have OPatch 19 Release 12.2.0.1.25 or the latest version available for 19 Release 12.2.0.1.25, then download it from patch# 6880880 for  12.2.0.1.25.

	For information about OPatch documentation, including any known issues, see My Oracle Support Document 293369.1 OPatch documentation list:
	https://support.oracle.com/CSP/main/article?cmd=show&type=NOT&id=224346.1

4.	Ensure that you set (as the home user) the ORACLE_HOME environment variable to the Oracle home.

5.	Ensure that the $PATH definition has the following executables: make, ar, ld and nm. The location of these executables depends on your operating system. On many operating systems, they are located in /usr/ccs/bin.	

6.	Ensure that you verify the Oracle Inventory because OPatch accesses it to install the patches. To verify the inventory, run the following command.
       $ opatch lsinventory 
	Note:
	-	If this command succeeds, it will list the Top-Level Oracle Products and one-off patches if any that are installed in the Oralce Home.
			- Save the output so you have the status prior to the patch apply.
	-	If the command displays some errors, then contact Oracle Support and resolve the issue first before proceeding further.

7.	(Only for Installation) Maintain a location for storing the contents of the patch ZIP file. In the rest of the document, this location (absolute path) is referred to as <PATCH_TOP_DIR>. Extract the contents of the patch ZIP file to the location (PATCH_TOP_DIR) you have created above. To do so, run the following command:
	$ unzip -d <PATCH_TOP_DIR>  p33590062_1912000DBRU_Generic.zip 


8.	(Only for Installation) Determine whether any currently installed interim patches conflict with this patch 33590062 as shown below:
	$ cd <PATCH_TOP_DIR>/33590062
	$ opatch prereq CheckConflictAgainstOHWithDetail -ph ./
	
	The report will indicate the patches that conflict with this patch and the patches for which the current 33590062 is a superset.
	
	Note:
	When OPatch starts, it validates the patch and ensures that there are no conflicts with the software already installed in the ORACLE_HOME. OPatch categorizes conflicts into the following types: 
	-	Conflicts with a patch already applied to the ORACLE_HOME that is a subset of the patch you are trying to apply  - In this case, continue with the patch installation because the new patch contains all the fixes from the existing patch in the ORACLE_HOME. The subset patch will automatically be rolled back prior to the installation of the new patch.
	-	Conflicts with a patch already applied to the ORACLE_HOME - In this case, stop the patch installation and contact Oracle Support Services.

9.	Ensure that you shut down all the services running from the Oracle home.
	Note:
		-	For a Non-RAC environment, shut down all the services running from the Oracle home. 
		-	For a RAC environment, shut down all the services (database, ASM, listeners, nodeapps, and CRS daemons) running from the Oracle home of the node you want to patch. After you patch this node, start the services on this node.Repeat this process for each of the other nodes of the Oracle RAC system. OPatch is used on only one node at a time.
                -       Please use -local option to apply the patch to the particular node. e.g., opatch apply -local



(II) Installation  
-----------------
To install the patch, follow these steps:

1.	Set your current directory to the directory where the patch is located and then run the OPatch utility by entering the following commands:

	$ cd <PATCH_TOP_DIR>/33590062

	$ opatch apply

2.	Verify whether the patch has been successfully installed by running the following command:

	$ opatch lsinventory

3.	Start the services from the Oracle home.

 

(III) Postinstallation
---------------------
1.    Navigate to the <ORACLE_HOME>/OPatch directory:
      $ cd <ORACLE_HOME>/OPatch

2.    Install the SQL portion of the patch by running the following command:
      $ datapatch

3.    Start sqlplus and run the utlrp.sql to clear the invalids only if dpload.sql is a part of the patch
      SQL> ?/rdbms/admin/utlrp.sql

Note: For a RAC environment, perform these steps on only one node.





(IV) Deinstallation
----------------------
Ensure to follow the Prerequsites (Section I). To deinstall the patch, follow these steps:


1.	Deinstall the patch by running the following command:

	$ opatch rollback -id 33590062
  
2.	Start the services from the Oracle home.

3.	Ensure that you verify the Oracle Inventory and compare the output with the one run before the patch installation and re-apply any patches that were rolled back as part of this patch apply. To verify the inventory, run the following command:

	$ opatch lsinventory



(V) Postdeinstallation
-----------------------

1.    Navigate to the <ORACLE_HOME>/OPatch directory:
      $ cd <ORACLE_HOME>/OPatch


2.    Deinstall the SQL portion of the patch by running the following command:
      $ datapatch

3.    Start sqlplus and run the utlrp.sql to clear the invalids only if dpload.sql is a part of the patch
      SQL> ?/rdbms/admin/utlrp.sql

Note: For a RAC environment, perform these steps on only one node.






(VI) Bugs Fixed by This Patch
---------------------------------
The following are the bugs fixed by this patch:
  28318139: ORA-31003 ERROR WHEN IMPORTING FULL DATABASE IN PARALLEL
  28555193: DBMS_METADATA.GET_DDL CAPTURE INCORRECT STORAGE OPTIONS OF THE XML COLUMN ON GTT
  28771564: DATAPUMP EXPORT INVOKED BY A PRIVILEGE USER EXECUTES A QUERY FOR V$OPEN_CURSOR
  29276889: ATP-D: DATA PUMP IMPORT FROM ATP-D INSTANCE TO A LOCAL DB INSTANCE FAILS
  29543605: 18.4 ADWC - ORA-39242: UNABLE TO EXPORT/IMPORT "LONG RAW" DATA TYPE
  29613245: ORA-31684 ORA-39112 WITH FIX 28539085 AND VERSION=11.2
  29959025: EXPDP RUNNING LONG TIME QUERYING KU$_SUBPARTITION_EST_VIEW WHEN PROCESSING TABLE_DATA
  30155338: ORA-54 RUNNING IMPDP AFTER UPGRADE FROM 12.2 TO 18.7
  30662417: IMPDP WORKER TERMINATED WITH ORA-39029 AFTER MULTIPLE ORA-01775
  30822078: IMPDP VERY SLOW DUE TO PROCESS REORDERING
  30858671: 18C DBMS_METADATA.GET_DDL FAILED WITH ORA-16000 IN READ ONLY MODE
  30978304: ORA-20000 DURING IMPDP WITH STATS AND THE UNIQUE INDEX FOR THE PK IS NOT CREATED
  31200854: ADB-D: IMPORT PERFORMANCE OF PACKAGE_BODY
  31402031: DBMS_METADATA_UTIL THROWS AN INVALID CURSOR EXCEPTION.
  31412130: ADBD:: COMPLETE FIX FOR 29543605 WHICH INCLUDES ALL THE MISSING FILES
  31711479: ADB-S: ORA39126 AND ORA01031 WHILE IMPORT USING FA FULL DUMP INTO ADB-S
  31830685: ZDM :  IMPORT ADW-S DB LINK MIGRATION THROWS INTERNAL ERROR
  32512780: PROCOBJ PLSQL SCRIPTS ARE NOT EXCLUDED ON IMPORT WITH EXCLUDE=TAG
  32647307: ADB-D:: PACKAGE BODIES IMPORT SLOWER AFTER AUTONOMOUS REFRESH TO 19.10DBRU
  32919937: CONSOLIDATED BUG OF IMPROVEMENTS TO DATA PUMP / MDAPI PATCHING PROCEDURES
  33163877: ATPD MIGRATION:IMPDP HITS TABLE OR VIEW DOES NOT EXIST ON SOME DATAPUMP RELATED TABLES


--------------------------------------------------------------------------
Copyright 2022, Oracle and/or its affiliates. All rights reserved.
--------------------------------------------------------------------------
