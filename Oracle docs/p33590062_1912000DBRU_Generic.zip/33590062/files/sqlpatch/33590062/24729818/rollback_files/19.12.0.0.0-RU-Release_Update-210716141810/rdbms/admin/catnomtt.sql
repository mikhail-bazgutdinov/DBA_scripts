Rem
Rem $Header: rdbms/admin/catnomtt.sql /main/110 2018/06/25 10:38:20 mjangir Exp $
Rem
Rem catnomtt.sql
Rem
Rem Copyright (c) 2018, Oracle and/or its affiliates. All rights reserved.
Rem
Rem    NAME
Rem      catnomtt.sql - This file is unused in Oracle 18.x and later 
Rem
Rem    DESCRIPTION
Rem      Prior to Oracle 18.x, this file dropped type used by the metadata
Rem      API, to allow patch/upgrade/downgrade to provide updated view 
Rem      definitions. Beginning in 18.x, 'CREATE OR REPLACE TYPE <name> FORCE'
Rem      is used instead. Obsolete types must be dropped in catnomta.sql 
Rem      This file is used by savetrans/endtrans in patch transactions
Rem      for Oracle releases prior to 18.x.
Rem
Rem    NOTES
Rem      While this file is accessed by savetrans/endtrans, that is only 
Rem      seeking SQL_FILE_METADATA. There is no actual content in this file.
Rem      Earlier versions of Oracle include this file, with content used fori
Rem      patching. 
Rem
Rem BEGIN SQL_FILE_METADATA
Rem SQL_SOURCE_FILE: rdbms/admin/catnomtt.sql
Rem SQL_SHIPPED_FILE: rdbms/admin/catnomtt.sql
Rem SQL_PHASE: DOWNGRADE 
Rem SQL_STARTUP_MODE: UPGRADE 
Rem SQL_IGNORABLE_ERRORS: NONE
Rem SQL_CALLING_FILE: rdbms/admin/catnodpt.sql
Rem END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    mjangir     06/22/18 - Added this file to avoid savetrans and endtrans 
Rem                         - error 'catnomtt.sql does not contain 
Rem                         - SQL_FILE_METADATA tag' during backport 
Rem    mjangir     06/22/18 - Created
 
