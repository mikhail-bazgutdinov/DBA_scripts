Rem $Header: rdbms/admin/catnodp_hcs.sql sdavidso_blr_backport_32919937_19.12.0.0.210720dbru/1 2021/05/28 09:25:23 sdavidso Exp $
Rem
Rem catnodp_hcs.sql
Rem
Rem Copyright (c) 2021, Oracle and/or its affiliates.
Rem
Rem    NAME
Rem      catnodp_hcs.sql - drop HCS objects for datapump
Rem
Rem    DESCRIPTION
Rem      Drop HCS types and views for datapump.
Rem      
Rem      Note the types and views should be dropped in the reverse order of 
Rem      their creation in catmettypes_hcs.sql and catmetviews_hcs.sql, because
Rem      dependents should be removed before their parent objects.
Rem
Rem      This script is only called by catdwgrd.sql during downgrade.  
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem    BEGIN SQL_FILE_METADATA
Rem    SQL_SOURCE_FILE: rdbms/admin/catnodp_hcs.sql
Rem    SQL_SHIPPED_FILE: rdbms/admin/catnodp_hcs.sql
Rem    SQL_PHASE: DOWNGRADE
Rem    SQL_STARTUP_MODE: DOWNGRADE
Rem    SQL_IGNORABLE_ERRORS: NONE
Rem    SQL_CALLING_FILE: rdbms/admin/catdwgrd.sql
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    bwright     02/25/21 - Bug 32551008: Backport split of HCS objects 
Rem                           out from MDAPI files
Rem    beiyu       07/25/19 - Created
Rem

@@?/rdbms/admin/sqlsessstart.sql

drop type ku$_analytic_view_t;
drop type ku$_hierarchy_t;
drop type ku$_attribute_dimension_t;
drop type ku$_hcs_av_cache_mlst_list_t;
drop type ku$_hcs_av_cache_mlst_t;
drop type ku$_hcs_av_cache_lvgp_list_t;
drop type ku$_hcs_av_cache_lvgp_t;
drop type ku$_hcs_av_cache_lvl_list_t;
drop type ku$_hcs_av_cache_lvl_t;
drop type ku$_hcs_av_cache_meas_list_t;
drop type ku$_hcs_av_cache_meas_t;
drop type ku$_analytic_view_meas_list_t;
drop type ku$_analytic_view_meas_t;
drop type ku$_analytic_view_dim_list_t;
drop type ku$_analytic_view_dim_t;
drop type ku$_analytic_view_hiers_list_t;
drop type ku$_analytic_view_hiers_t;
drop type ku$_analytic_view_keys_list_t;
drop type ku$_analytic_view_keys_t;
drop type ku$_hier_hier_attr_list_t;
drop type ku$_hier_hier_attr_t;
drop type ku$_hier_lvl_list_t;
drop type ku$_hier_lvl_t;
drop type ku$_attr_dim_lvl_list_t;
drop type ku$_attr_dim_lvl_t;
drop type ku$_attr_dim_lvl_ordby_list_t;
drop type ku$_attr_dim_lvl_ordby_t;
drop type ku$_attr_dim_lvl_key_list_t;
drop type ku$_attr_dim_lvl_key_t;
drop type ku$_attr_dim_attr_list_t;
drop type ku$_attr_dim_attr_t;
drop type ku$_hier_join_path_list_t;
drop type ku$_hier_join_path_t;
drop type ku$_attr_dim_join_path_list_t;
drop type ku$_attr_dim_join_path_t;
drop type ku$_hcs_clsfctn_list_t;
drop type ku$_hcs_clsfctn_t;
drop type ku$_hcs_src_col_list_t;
drop type ku$_hcs_src_col_t;
drop type ku$_hcs_src_list_t;
drop type ku$_hcs_src_t;

drop view ku$_analytic_view;
drop view ku$_hierarchy_view;
drop view ku$_attribute_dimension_view;
drop view ku$_hcs_av_cache_mlst_view;
drop view ku$_hcs_av_cache_lvgp_view;
drop view ku$_hcs_av_cache_lvl_view;
drop view ku$_hcs_av_cache_meas_view;
drop view ku$_hcs_av_cache_dst_mslst;
drop view ku$_analytic_view_meas_view;
drop view ku$_analytic_view_dim_view;
drop view ku$_analytic_view_hiers_view;
drop view ku$_analytic_view_keys_view;
drop view ku$_hier_hier_attr_view;
drop view ku$_hier_lvl_view;
drop view ku$_attr_dim_lvl_view;
drop view ku$_attr_dim_lvl_ordby_view;
drop view ku$_attr_dim_lvl_key_view;
drop view ku$_attr_dim_attr_view;
drop view ku$_hier_join_path_view;
drop view ku$_attr_dim_join_path_view;
drop view ku$_hcs_clsfctn_view;
drop view ku$_hcs_src_col_view;
drop view ku$_hcs_src_view;

@?/rdbms/admin/sqlsessend.sql
 
