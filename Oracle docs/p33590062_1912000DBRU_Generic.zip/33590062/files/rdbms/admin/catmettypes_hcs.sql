Rem
Rem $Header: rdbms/admin/catmettypes_hcs.sql sdavidso_blr_backport_32919937_19.12.0.0.210720dbru/1 2021/05/28 09:25:22 sdavidso Exp $
Rem
Rem catmettypes_hcs.sql
Rem
Rem Copyright (c) 2021, Oracle and/or its affiliates.
Rem
Rem    NAME
Rem      catmettypes_hcs.sql - HCS object types for DataPump Metadata API
Rem
Rem    DESCRIPTION
Rem      Creates HCS object types for use by the
Rem      DataPump Metadata API.
Rem
Rem    NOTES
Rem     All types must have EXECUTE granted to PUBLIC.
Rem     All top-level views used by the mdAPI to actually fetch full object
Rem     metadata (eg, KU$_ANALYTIC_VIEW) must have SELECT granted to PUBLIC, but
Rem     must have CURRENT_USERID checking security clause.
Rem     All views subordinate to the top level views (eg, KU$_HCS_SRC_VIEW)
Rem     must have SELECT granted to SELECT_CATALOG_ROLE.
Rem
Rem     Note that new types added to this file should be dropped in catnomta_hcs.sql.
Rem
Rem    BEGIN SQL_FILE_METADATA
Rem    SQL_SOURCE_FILE: rdbms/admin/catmettypes_hcs.sql
Rem    SQL_SHIPPED_FILE: rdbms/admin/catmettypes_hcs.sql
Rem    SQL_PHASE: CATMETTYPES_HCS
Rem    SQL_STARTUP_MODE: NORMAL
Rem    SQL_IGNORABLE_ERRORS: NONE
Rem    SQL_CALLING_FILE: rdbms/admin/catpspec.sql
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    bwright     02/25/21 - Bug 32551008: Backport 30051876: split HCS 
Rem                           objects out from MDAPI files
Rem    beiyu       07/11/19 - Created
Rem

@@?/rdbms/admin/sqlsessstart.sql

-------------------------------------------------------------------------------
--           ATTRIBUTE DIMENSION / HIERARCHY / ANALYTIC VIEW types
-------------------------------------------------------------------------------

-- source for hier dim or analytic view
create or replace type ku$_hcs_src_t force as object
(
  hcs_obj#       number,            /* obj# of the hier dim or analytic view */
  src_id         number,    /* id of the source in hier dim or analytic view */
  owner          varchar2(128),      /* owner of the source (hcs_src$.owner) */
  owner_in_ddl   number(1),                      /* whether owner was in DDL */
  name           varchar2(128),        /* name of the source (hcs_src$.name) */
  alias          varchar2(128),      /* alias of the source (hcs_src$.alias) */
  order_num      number                        /* order number of the soruce */
)
not persistable
/ 

create or replace type ku$_hcs_src_list_t force as table of (ku$_hcs_src_t)
not persistable
/



-- source column for attribute dim or analytic view 
create or replace type ku$_hcs_src_col_t force as object
(
  obj#           number,          /* top lvl object id containing the srcCol */
  src_col#       number,                          /* id of the source column */
  obj_type       number,                /* object type containing the srcCol */
  table_alias    varchar2(128),/* owner of column (hcs_src_col$.table_alias) */
  src_col_name   varchar2(128) /* name of column (hcs_src_col$.src_col_name) */
)
not persistable
/

-- Appears not be be used.  Not referenced by any catmetviews*.sql views and
-- has no privs granted on it in catmetgrant*.sql.  Only other reference is
-- catnodp*.sql.
create or replace type ku$_hcs_src_col_list_t force
as table of (ku$_hcs_src_col_t)
not persistable
/

-- classification
create or replace type ku$_hcs_clsfctn_t force as object
(
  obj#            number, /* top lvl object id containing the classification */
  sub_obj#        number,    /*  sub object id containing the classification */
  obj_type        number,                                  /* type of object */
  clsfction_name  varchar2(128),  /* classification name (from hcs_clsfctn$) */
  clsfction_lang  varchar2(64),          /* optional classification language */
  clsfction_value clob,                              /* classification value */
  order_num       number                   /* order number of classification */
)
not persistable
/

create or replace type ku$_hcs_clsfctn_list_t force
as table of (ku$_hcs_clsfctn_t)
not persistable
/

-- hier dim join path
create or replace type ku$_attr_dim_join_path_t force as object
(
  dim_obj#       number,                             /* obj# of the hier dim */
  join_path_id   number,                     /* join path id in the hier dim */
  name           varchar2(128),  /* name (hcs_dim_join_path$.join_path_name) */
  on_condition   varchar2(4000),      /* condition of the hier dim join path */
  order_num      number                        /* order number of attributes */
)
not persistable
/

create or replace type ku$_attr_dim_join_path_list_t 
 force as table of (ku$_attr_dim_join_path_t)
not persistable
/

-- hier join path
create or replace type ku$_hier_join_path_t force as object
(
  hier_obj#      number,                                 /* obj# of the hier */
  name           varchar2(128), /* name (hcs_hier_join_path$.join_path_name) */
  order_num      number                        /* order number of attributes */
)
not persistable
/

create or replace type ku$_hier_join_path_list_t 
 force as table of (ku$_hier_join_path_t)
not persistable
/

-- attribute dimension attr
create or replace type ku$_attr_dim_attr_t force as object
(
  dim_obj#       number,                             /* obj# of the hier dim */
  attr_id        number,                          /* attr id in the hier dim */
  name           varchar2(128),       /* attr name (hcs_dim_attr$.attr_name) */
  table_alias    varchar2(128),/* owner of column (hcs_src_col$.table_alias) */
  src_col_name   varchar2(128),/* name of column (hcs_src_col$.src_col_name) */
  clsfctn_list   ku$_hcs_clsfctn_list_t,                  /* classifications */
  order_num      number                        /* order number of attributes */
)
not persistable
/

create or replace type ku$_attr_dim_attr_list_t 
 force as table of (ku$_attr_dim_attr_t)
not persistable
/

-- attribute dim level key
create or replace type ku$_attr_dim_lvl_key_t force as object
(
  dim_obj#       number,                             /* obj# of the hier dim */
  lvl_id         number,               /* level number within this dimension */
  key_id         number,                       /* lvl key id in the hier dim */
  attr_list      ku$_attr_dim_attr_list_t,                  /* list of attrs */
  order_num      number                       /* order number of the lvl key */
)
not persistable
/

create or replace type ku$_attr_dim_lvl_key_list_t 
 force as table of (ku$_attr_dim_lvl_key_t)
not persistable
/

-- attribute dim level order by
create or replace type ku$_attr_dim_lvl_ordby_t force as object
(
  dim_obj#       number,                             /* obj# of the attr dim */
  lvl_id         number,                         /* level id in the attr dim */
  agg_func       varchar2(3),             /* aggregation function MIN or MAX */
  attribute_name varchar2(128),                            /* attribute name */
  order_num      number,                                     /* order number */
  criteria       varchar2(4),                       /* criteria: ASC or DESC */
  nulls_position varchar2(5)                          /* NULLS FIRST or LAST */
)
not persistable
/  

create or replace type ku$_attr_dim_lvl_ordby_list_t 
 force as table of (ku$_attr_dim_lvl_ordby_t)
not persistable
/

-- attribute dim level
create or replace type ku$_attr_dim_lvl_t force as object
(
  dim_obj#       number,                             /* obj# of the attr dim */
  lvl_id         number,                         /* level id in the attr dim */
  name           varchar2(128),        /* level name (hcs_dim_lvl$.lvl_name) */
  member_name    clob,              /* member name (hcs_dim_lvl$.member_name */
  member_caption clob,        /* member caption (hcs_dim_lvl$.member_caption */
  member_desc    clob,/* member description (hcs_dim_lvl$.member_description */
  skip_when_null varchar2(1),                              /* skip when null */
  level_type     varchar2(16),                                 /* level type */
  clsfctn_list   ku$_hcs_clsfctn_list_t,                  /* classifications */
  key_list       ku$_attr_dim_lvl_key_list_t,          /* list of level keys */
  ordby_list     ku$_attr_dim_lvl_ordby_list_t,                 /* order bys */
  dtm_attr_list  ku$_attr_dim_attr_list_t,       /* list of determined attrs */
  order_num      number                         /* order number of the level */
)
not persistable
/  

create or replace type ku$_attr_dim_lvl_list_t 
 force as table of (ku$_attr_dim_lvl_t)
not persistable
/

-- hier level
create or replace type ku$_hier_lvl_t force as object
(
  hier_obj#      number,                                 /* obj# of the hier */
  name           varchar2(128),         /* level name (hcs_hr_lvl$.lvl_name) */
  order_num      number                         /* order number of the level */
)
not persistable
/

create or replace type ku$_hier_lvl_list_t 
 force as table of (ku$_hier_lvl_t)
not persistable
/

-- hier attr
create or replace type ku$_hier_hier_attr_t force as object
(
  hier_obj#      number,                                 /* obj# of the hier */
  name           varchar2(128), /* attr name (hcs_hier_attr$.hier_attr_name) */
  expr           clob,             /* expression (NULL for system-generated) */
  clsfctn_list   ku$_hcs_clsfctn_list_t,                  /* classifications */
  order_num      number                          /* order number of the attr */
)
not persistable
/

create or replace type ku$_hier_hier_attr_list_t 
 force as table of (ku$_hier_hier_attr_t)
not persistable
/

-- analytic view keys
create or replace type ku$_analytic_view_keys_t force as object
(
  av_obj#         number,                       /* obj# of the analytic view */
  dim_obj#        number,                            /* obj# of the hier dim */
  key_col_name    varchar2(128),/* key column name(hcs_src_col$.src_col_name)*/
  ref_attr_name   varchar2(128),/* ref attr name (hcs_av_key$.ref_attr_name) */
  order_num       number                   /* order number of the key column */
)
not persistable
/

create or replace type ku$_analytic_view_keys_list_t 
 force as table of (ku$_analytic_view_keys_t)
not persistable
/

-- analytic view hiers
create or replace type ku$_analytic_view_hiers_t force as object
(
  av_obj#         number,                       /* obj# of the analytic view */
  dim_obj#        number,                            /* obj# of the hier dim */
  hier_owner      varchar2(128),     /* hier owner (hcs_av_hier$.hier_owner) */
  owner_in_ddl    number(1),                     /* whether owner was in DDL */
  hier_name       varchar2(128),       /* hier name (hcs_av_hier$.hier_name) */
  hier_alias      varchar2(128),    /* hier alias  (hcs_av_hier$.hier_alias) */
  is_default      varchar2(1),                                 /* is default */
  order_num       number                         /* order number of the hier */
)
not persistable
/

create or replace type ku$_analytic_view_hiers_list_t 
 force as table of (ku$_analytic_view_hiers_t)
not persistable
/

-- analytic view dim
create or replace type ku$_analytic_view_dim_t force as object
(
  av_obj#         number,                       /* obj# of the analytic view */
  dim_obj#        number,                            /* obj# of the hier dim */
  dim_owner       varchar2(128),         /* dim owner (hcs_av_dim$.dim_owner */
  owner_in_ddl    number(1),                     /* whether owner was in DDL */
  name            varchar2(128),          /* dim name (hcs_av_dim$.dim_name) */
  dim_alias       varchar2(128),            /* alias name (hcs_av_dim$.alias */
  ref_distinct    number(1),                      /* is references distinct? */
  key_list        ku$_analytic_view_keys_list_t,       /* analytic view keys */
  hier_list       ku$_analytic_view_hiers_list_t,                   /* hiers */
  clsfctn_list    ku$_hcs_clsfctn_list_t,                 /* classifications */
  order_num       number                          /* order number of the dim */
)
not persistable
/  

create or replace type ku$_analytic_view_dim_list_t 
 force as table of (ku$_analytic_view_dim_t)
not persistable
/

-- analytic view measures
create or replace type ku$_analytic_view_meas_t force as object
(
  av_obj#         number,                       /* obj# of the analytic view */
  meas_id         number,                               /* id of the measure */
  meas_type       number,                                    /* base or calc */
  name            varchar2(128),    /* measure name (hcs_av_meas$.meas_name) */
  src_col_name    varchar2(128),  /* column name (hcs_src_col$.src_col_name) */
  expr            clob,                     /* calculated measure expression */
  aggr            varchar2(128),        /* aggr_function (hcs_av_meas$.aggr) */
  clsfctn_list    ku$_hcs_clsfctn_list_t,                 /* classifications */
  order_num       number                      /* order number of the measure */
)
not persistable
/  

create or replace type ku$_analytic_view_meas_list_t 
 force as table of (ku$_analytic_view_meas_t)
not persistable
/

-- analytic view cache

-- measures in measure lists
create or replace type ku$_hcs_av_cache_meas_t force as object
(
  av_obj#         number,                       /* obj# of the analytic view */
  measlst#        number,                                   /* id of measlst */
  meas_name       varchar2(128),                      /* name of the measure */
  order_num       number                      /* order number of the measure */
)
not persistable
/

create or replace type ku$_hcs_av_cache_meas_list_t 
 force as table of (ku$_hcs_av_cache_meas_t)
not persistable
/

-- levels in level groups
create or replace type ku$_hcs_av_cache_lvl_t force as object
(
  av_obj#         number,                       /* obj# of the analytic view */
  lvlgrp#         number,                                    /* id of lvlgrp */
  dim_alias       varchar2(128),                    /* name of the dim alias */
  hier_alias      varchar2(128),                   /* name of the hier alias */
  level_name      varchar2(128),                        /* name of the level */
  order_num       number                        /* order number of the level */
)
not persistable
/

create or replace type ku$_hcs_av_cache_lvl_list_t 
 force as table of (ku$_hcs_av_cache_lvl_t)
not persistable
/

-- level groups
create or replace type ku$_hcs_av_cache_lvgp_t force as object
(
  av_obj#         number,                       /* obj# of the analytic view */
  measlst#        number,                                   /* id of measlst */
  lvlgrp#         number,                                /* id of the lvlgrp */
  cache_type      varchar2(128),                               /* cache type */
  lvl_list        ku$_hcs_av_cache_lvl_list_t,                     /* levels */
  order_num       number                              /* order of the lvlgrp */
)
not persistable
/

create or replace type ku$_hcs_av_cache_lvgp_list_t 
 force as table of (ku$_hcs_av_cache_lvgp_t)
not persistable
/

-- measure lists
create or replace type ku$_hcs_av_cache_mlst_t force as object
(
  av_obj#         number,                       /* obj# of the analytic view */
  measlst#        number,                                   /* id of measlst */
  meas_list       ku$_hcs_av_cache_meas_list_t,                  /* measures */
  lvlgrp_list     ku$_hcs_av_cache_lvgp_list_t               /* level groups */
)
not persistable
/

create or replace type ku$_hcs_av_cache_mlst_list_t 
 force as table of (ku$_hcs_av_cache_mlst_t)
not persistable
/

-- end analytic view cache

-- hier dim
create or replace type ku$_attribute_dimension_t force as object
(
  obj_num            number,           /* object number of the attribute dim */
  schema_obj         ku$_schemaobj_t,                       /* schema object */
  dimension_type     varchar2(8),                          /* dimension type */
  all_member_name    clob,                                /* all member name */
  all_member_caption clob,                             /* all member caption */
  all_member_desc    clob,                         /* all member description */
  src_list           ku$_hcs_src_list_t,                  /* list of sources */
  attr_list          ku$_attr_dim_attr_list_t,        /* dimension attr list */
  lvl_list           ku$_attr_dim_lvl_list_t,        /* dimension level list */
  clsfctn_list       ku$_hcs_clsfctn_list_t,              /* classifications */
  join_path_list     ku$_attr_dim_join_path_list_t             /* join paths */
)
not persistable
/

-- hierarchy
create or replace type ku$_hierarchy_t force as object
(
  obj_num         number,                       /* object number of the hier */
  schema_obj      ku$_schemaobj_t,                          /* schema object */
  dim_owner       varchar2(128),                          /* dimension owner */
  owner_in_ddl    number(1),                     /* whether owner was in DDL */
  dim_name        varchar2(128),                           /* dimension name */
  lvl_list        ku$_hier_lvl_list_t,           /* list of hierarchy levels */
  clsfctn_list    ku$_hcs_clsfctn_list_t,                 /* classifications */
  join_path_list  ku$_hier_join_path_list_t,                   /* join paths */
  hr_attr_list    ku$_hier_hier_attr_list_t   /* hier attr w/classifications */
)
not persistable
/

-- analytic view
create or replace type ku$_analytic_view_t force as object
(
  obj_num         number,              /* object number of the analytic view */
  schema_obj      ku$_schemaobj_t,                          /* schema object */
  def_meas        varchar2(128),                          /* default measure */
  def_aggr        varchar2(128),                      /* default aggregation */
  src_list        ku$_hcs_src_list_t,                     /* list of sources */
  dim_list        ku$_analytic_view_dim_list_t,                /* dimensions */
  meas_list       ku$_analytic_view_meas_list_t,                 /* measures */
  clsfctn_list    ku$_hcs_clsfctn_list_t,                 /* classifications */
  cache_meas_list ku$_hcs_av_cache_mlst_list_t,           /* cache meas list */
  dyn_all_cache   number(1)                     /* dynamic all cache enabled */
)
not persistable
/

@?/rdbms/admin/sqlsessend.sql
 
