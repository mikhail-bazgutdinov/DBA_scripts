Rem Copyright (c) 1987, 2021, Oracle and/or its affiliates.
Rem All rights reserved.
Rem NAME
Rem    CATMETGRANT2.SQL - Grants of the Oracle dictionary for
Rem                       Metadata API.
Rem  FUNCTION
Rem     Grants privileges on views, objects and types of
Rem     the Oracle dictionary for use by the DataPump Metadata API.
Rem  NOTES
Rem     Must be run when connected to SYS or INTERNAL.
Rem     IMPORTANT! Keep the file catnomta.sql in synch with this file.
Rem     This is invoked by catnodp.sql during downgrade.
Rem
Rem     All types must have EXECUTE granted to PUBLIC.
Rem     All top-level views used by the mdAPI to actually fetch full object
Rem     metadata (eg, KU$_TABLE_VIEW) must have SELECT granted to PUBLIC, but
Rem     must have CURRENT_USERID checking security clause.
Rem     All views subordinate to the top level views (eg, KU$_SCHEMAOBJ_VIEW)
Rem     must have SELECT granted to SELECT_CATALOG_ROLE.
Rem
Rem     This entire script is ran in a temporary, anonymous PLSQL block.
Rem     Nothing is left around in the rare event this script is
Rem     interrupted in the middle.  Since we are dealing with granting
Rem     privileges, we don't want anything left around that even looks
Rem     like it could possibly be mis-used.
Rem
Rem BEGIN SQL_FILE_METADATA
Rem SQL_SOURCE_FILE: rdbms/admin/catmetgrant2.sql
Rem SQL_SHIPPED_FILE: rdbms/admin/catmetgrant2.sql
Rem SQL_PHASE: CATMETGRANT2
Rem SQL_STARTUP_MODE: NORMAL
Rem SQL_IGNORABLE_ERRORS: NONE
Rem SQL_CALLING_FILE: rdbms/admin/catpexec.sql
Rem END SQL_FILE_METADATA
Rem
Rem  MODIFIED
Rem     apfwkr     04/02/21 - Backport
Rem                           bwright_blr_backport_32551008_19.10.0.0.210119dbru
Rem                           from st_rdbms_19.10.0.0.0dbru
Rem     bwright    03/23/21 - Backport bwright_bug-32551008 from
Rem                           st_rdbms_19.10.0.0.0dbru
Rem     bwright    03/02/21 - Bug 32551008: backport 31054943: perf improvement
Rem                           of catmetgrant1/2; 31207242: remove SQL SET 
Rem                           commands 
Rem     bwright    03/01/21 - Bug 32551008: backport 31054943, perf improvement
Rem                           of catmetgrant1/2
Rem     mjangir    03/27/17 - 23181020: adding ku$_xsolap_policy_list_t
Rem     sdavidso   01/19/17 - bug25225293 make procact_instance work with CBO
Rem     jjanosik   10/07/16 - Bug 24661809: Add grants for new types and views
Rem                           for procedural actions and objects
Rem     jjanosik   05/03/16 - bug 18083463 - change audit_view get rid of old
Rem                           versioned audit_views
Rem     mjangir    04/25/16 - Bug 22763372: adding ku$_rls_policy_list_t
Rem     jjanosik   02/02/16 - bug 20317926 - add grant for new trigger view
Rem     jjanosik   11/23/15 - rti 18756088 - add exp_full_database to audit
Rem                           views
Rem     jjanosik   09/23/15 - bug 13611733: Change some grants
Rem     sdavidso   03/06/15 - Parallel metadata export
Rem     rapayne    10/20/14 - bug 20164836: support for RAS schema level priv
Rem                           grants.
Rem     skayoor    11/30/14 - Proj 58196: Change Select priv to Read Priv
Rem     bwright    11/17/14 - Support 'audit policy by granted roles'
Rem     sdavidso   09/10/14 - bug14821907: find tablespaces: table
Rem     rapayne    04/26/14 - proj 46816: support for new sysrac priv.
Rem     surman     12/29/13 - 13922626: Update SQL metadata
Rem     rapayne    11/24/13 - Bug 15916457: add grant for new objgrant_list_t
Rem     sdavidso   10/15/13 - proj-47829 don't export READ/READ ALL TABLES to
Rem                           pre 12.1
Rem     lbarton    10/02/13 - Project 48787: views to document mdapi transforms
Rem     rapayne    04/15/13 - bug 16310682: reduce memory for procact_schema
Rem     rapayne    11/06/12 - bug 15832675: create 11_2_view_view to exclude
Rem                           views with bequeath current_user.
Rem     traney     08/02/12 - 14407652: edition enhancements
Rem     rapayne    08/10/12 - lrg 7071802: new mviews to support secondary
Rem                           materialized views.
Rem     lbarton    07/26/12 - bug 13454387: long varchar
Rem     ssonawan   07/19/12 - bug 13843068: add ku$_11_2_psw_hist_view
Rem     surman     03/27/12 - 13615447: Add SQL patching tags
Rem     sdavidso   01/31/12 - bug 11840083: reduce memory for procact_system
Rem     rapayne    01/02/12 - add credential objects
Rem     ebatbout   01/31/12 - Proj. 36950: Give select and execute privileges
Rem                           on code_base_grant type and view to public.
Rem     sdavidso   12/14/11 - add audit policy objects
Rem     lbarton    11/30/11 - 36954_dpump_tabcluster_zonemap
Rem     ebatbout   11/09/11 - Proj. 36951: Give select privilege to view,
Rem                           ku$_on_user_grant_view
Rem     sdavidso   11/03/11 - lrg 6000876: no export 12.1 privs to pre-12
Rem     dgagne     09/20/11 - add new stat grants
Rem     jerrede    09/07/11 - Created for Parallel Upgrade Project #23496
Rem

@@?/rdbms/admin/sqlsessstart.sql

VARIABLE catmetgrant2_summary VARCHAR2(1024)
COLUMN   catmetgrant2_summary format a79
--
-- ----------------------------------------------------------------------------
-- The following functions/procedures/variables in this anonymous PLSQL block 
-- should remain identical to the ones in catmetgrant1.sql except for the 
-- references to the above summary variable which should be 
-- '<filename>_summary'. 
--
-- Also, note these functions/procedures are only visible within this
-- anonymous PLSQL block; they are never visible externally nor do they
-- persist after this script has been run.
-- ----------------------------------------------------------------------------
--
DECLARE
  v_last_err      VARCHAR2(500);
  v_skip_cnt      NUMBER := 0;
  v_grant_cnt     NUMBER := 0;
  v_error_cnt     NUMBER := 0;
  v_query_stmt    VARCHAR2(1000) :=
    'select 1 from dual where exists 
     (select 1
       from sys.objauth$ oa 
         inner join sys.obj$ o on (oa.obj# = o.obj#)
         inner join sys.user$ ue on (oa.grantee# = ue.user#)
         inner join table_privilege_map tpm
           on (oa.privilege# = tpm.privilege)
       where oa.grantor# = 0 and o.owner# = 0
         and oa.col# is null
         and (o.type# <> 13 or
             (o.type# = 13 and o.subname is null))
         and o.name = :1
         and ue.name = :2
         and tpm.name = :3)';

  FUNCTION final_summary
  RETURN VARCHAR2
  IS
    l_sum       VARCHAR2(1024);
  BEGIN
    l_sum := 'grants ' || 
             'skipped('   || v_skip_cnt  || '), ' || 
             'succeeded(' || v_grant_cnt || '), ' || 
             'failed('    || v_error_cnt || ')';
 
    IF v_last_err IS NOT NULL THEN                        -- display last error
      l_sum := l_sum || CHR(10) || v_last_err; 
    END IF;

    RETURN l_sum;
  END;

  --
  -- See if priv already exists on this object for this grantee.
  --
  FUNCTION is_granted (
    priv      IN VARCHAR2,  -- privilege to grant
    objnam    IN VARCHAR2,  -- on what object
    grantee   IN VARCHAR2)  -- to whom (the grantee)
  RETURN BOOLEAN IS
    l_exists     NUMBER := 0;
  BEGIN
    EXECUTE IMMEDIATE v_query_stmt 
                 INTO l_exists 
                USING UPPER(objnam), UPPER(grantee), UPPER(priv);
    IF l_exists = 1 THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END;
 
  --
  -- Try to grant the privilege
  --
  FUNCTION grant_priv (
    priv      IN VARCHAR2,  -- privilege to grant
    objnam    IN VARCHAR2,  -- on what object
    grantee   IN VARCHAR2)  -- to whom (the grantee)
  RETURN BOOLEAN IS
  BEGIN
    EXECUTE IMMEDIATE 'grant ' || priv    || 
                      ' on '   || objnam  || 
                      ' to '   || grantee;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN                       -- Don't expect any error on GRANT
      v_last_err := 'last error, granting ' || 
                     priv || ' on ' || objnam || ' to ' || grantee || ':' ||
                     CHR(10) || SUBSTR(SQLERRM, 1, 200);
      RETURN FALSE;
  END;

  --
  -- Check if the privilege is already granted before granting it.  This
  -- is a significant performance improvement over attempting to grant 
  -- a privilege that is already granted (not a cheap no-op).
  --
  PROCEDURE cmgrant(
    priv      IN VARCHAR2,  -- privilege to grant
    objnam    IN VARCHAR2,  -- on what object
    grantee   IN VARCHAR2)  -- to whom (the grantee)
  IS
  BEGIN
    IF is_granted(priv, objnam, grantee) THEN
      v_skip_cnt := v_skip_cnt + 1;                     -- Grant exists so skip
    ELSIF grant_priv(priv, objnam, grantee) THEN 
      v_grant_cnt := v_grant_cnt + 1;                   -- Grant was successful
    ELSE 
      v_error_cnt := v_error_cnt + 1;                         -- Error occurred
 
    END IF;
  END; 

BEGIN
  cmgrant('execute', 'ku$_opbinding_list_t',          'public');
  cmgrant('execute', 'ku$_operator_t',                'public');
  cmgrant('read'   , 'ku$_operator_view',             'public');
  cmgrant('execute', 'ku$_indexop_t',                 'public');
  cmgrant('execute', 'ku$_indexop_list_t',            'public');
  cmgrant('select' , 'ku$_indexop_view',              'select_catalog_role');
  cmgrant('execute', 'ku$_indarraytype_t',            'public');
  cmgrant('execute', 'ku$_indarraytype_list_t',       'public');
  cmgrant('select' , 'ku$_indarraytype_view',         'select_catalog_role');
  cmgrant('select' , 'ku$_opbinding_view',            'select_catalog_role');
  cmgrant('execute', 'ku$_indextype_t',               'public');
  cmgrant('read'   , 'ku$_indextype_view',            'public');
  cmgrant('execute', 'ku$_objgrant_t',                'public');
  cmgrant('execute', 'ku$_objgrant_list_t',           'public');
  cmgrant('read'   , 'ku$_objgrant_view',             'public');
  cmgrant('read'   , 'ku$_10_1_objgrant_view',        'public');
  cmgrant('execute', 'ku$_sysgrant_t',                'public');
  cmgrant('read'   , 'ku$_sysgrant_view',             'public');
  cmgrant('read'   , 'ku$_10_1_sysgrant_view',        'public');
  cmgrant('read'   , 'ku$_11_2_sysgrant_view',        'public');
  cmgrant('read'   , 'ku$_12_1_sysgrant_view',        'public');
  cmgrant('execute', 'ku$_triggercol_t',              'public');
  cmgrant('execute', 'ku$_triggercol_list_t',         'public');
  cmgrant('select' , 'ku$_triggercol_view',           'select_catalog_role');
  cmgrant('execute', 'ku$_triggerdep_t',              'public');
  cmgrant('execute', 'ku$_triggerdep_list_t',         'public');
  cmgrant('select' , 'ku$_triggerdep_view',           'select_catalog_role');
  cmgrant('execute', 'ku$_trigger_t',                 'public');
  cmgrant('read'   , 'ku$_trigger_view',              'public');
  cmgrant('read'   , 'ku$_12_1_trigger_view',         'public');
  cmgrant('read'   , 'ku$_11_2_trigger_view',         'public');
  cmgrant('read'   , 'ku$_10_2_trigger_view',         'public');
  cmgrant('execute', 'ku$_view_t',                    'public');
  cmgrant('read'   , 'ku$_11_2_view_view',            'public');
  cmgrant('read'   , 'ku$_view_view',                 'public');
  cmgrant('read'   , 'ku$_view_objnum_view',          'public');
  cmgrant('select' , 'ku$_depviews_base_view',        'select_catalog_role');
  cmgrant('read'   , 'ku$_depviews_view',             'public');
  cmgrant('execute', 'ku$_outline_hint_t',            'public');
  cmgrant('execute', 'ku$_outline_hint_list_t',       'public');
  cmgrant('execute', 'ku$_outline_node_t',            'public');
  cmgrant('execute', 'ku$_outline_node_list_t',       'public');
  cmgrant('execute', 'ku$_outline_t',                 'public');
  cmgrant('read'   , 'ku$_outline_view',              'public');
  cmgrant('execute', 'ku$_synonym_t',                 'public');
  cmgrant('read'   , 'ku$_synonym_view',              'public');
  cmgrant('execute', 'ku$_directory_t',               'public');
  cmgrant('read'   , 'ku$_directory_view',            'public');
  cmgrant('execute', 'ku$_rollback_t',                'public');
  cmgrant('read'   , 'ku$_rollback_view',             'public');
  cmgrant('execute', 'ku$_dblink_t',                  'public');
  cmgrant('read'   , 'ku$_dblink_view',               'public');
  cmgrant('read'   , 'ku$_10_1_dblink_view',          'public');
  cmgrant('execute', 'ku$_trlink_t',                  'public');
  cmgrant('read'   , 'ku$_trlink_view',               'public');
  cmgrant('execute', 'ku$_fga_rel_col_t',             'public');
  cmgrant('execute', 'ku$_fga_rel_col_list_t',        'public');
  cmgrant('execute', 'ku$_fga_policy_t',              'public');
  cmgrant('read'   , 'ku$_fga_policy_view',           'public');
  cmgrant('execute', 'ku$_rls_sec_rel_col_t',         'public');
  cmgrant('execute', 'ku$_rls_sec_rel_col_list_t',    'public');
  cmgrant('execute', 'ku$_rls_associations_t',        'public');
  cmgrant('execute', 'ku$_rls_assoc_list_t',          'public');
  cmgrant('execute', 'ku$_rls_policy_objnum_t',       'public');
  cmgrant('read'   , 'ku$_rls_policy_objnum_view',    'public');
  cmgrant('execute', 'ku$_rls_policy_t',              'public');
  cmgrant('execute', 'ku$_rls_policy_list_t',         'public');
  cmgrant('read'   , 'ku$_rls_policy_view',           'public');
  cmgrant('execute', 'ku$_rls_group_t',               'public');
  cmgrant('read'   , 'ku$_rls_group_view',            'public');
  cmgrant('execute', 'ku$_rls_context_t',             'public');
  cmgrant('read'   , 'ku$_rls_context_view',          'public');
  cmgrant('execute', 'ku$_m_view_scm_t',              'public');
  cmgrant('execute', 'ku$_m_view_scm_list_t',         'public');
  cmgrant('execute', 'ku$_m_view_srt_t',              'public');
  cmgrant('execute', 'ku$_m_view_srt_list_t',         'public');
  cmgrant('execute', 'ku$_m_view_t',                  'public');
  cmgrant('execute', 'ku$_m_view_h_t',                'public');
  cmgrant('execute', 'ku$_m_view_ph_t',               'public');
  cmgrant('execute', 'ku$_m_view_fh_t',               'public');
  cmgrant('execute', 'ku$_m_view_pfh_t',              'public');
  cmgrant('execute', 'ku$_m_view_iot_t',              'public');
  cmgrant('execute', 'ku$_m_view_piot_t',             'public');
  cmgrant('read'   , 'ku$_m_view_view',               'public');
  cmgrant('read'   , 'ku$_zm_view_view',              'public');
  cmgrant('read'   , 'ku$_m_view_view_base',          'public');
  cmgrant('read'   , 'ku$_m_view_h_view',             'public');
  cmgrant('read'   , 'ku$_zm_view_h_view',            'public');
  cmgrant('read'   , 'ku$_m_view_ph_view',            'public');
  cmgrant('read'   , 'ku$_zm_view_ph_view',           'public');
  cmgrant('read'   , 'ku$_m_view_fh_view',            'public');
  cmgrant('read'   , 'ku$_zm_view_fh_view',           'public');
  cmgrant('read'   , 'ku$_m_view_pfh_view',           'public');
  cmgrant('read'   , 'ku$_zm_view_pfh_view',          'public');
  cmgrant('read'   , 'ku$_m_view_iot_view',           'public');
  cmgrant('read'   , 'ku$_zm_view_iot_view',          'public');
  cmgrant('read'   , 'ku$_m_view_piot_view',          'public');
  cmgrant('read'   , 'ku$_zm_view_piot_view',         'public');
  cmgrant('read'   , 'ku$_m_zonemap_view',            'public');
  cmgrant('read'   , 'ku$_m_zonemap_h_view',          'public');
  cmgrant('read'   , 'ku$_m_zonemap_ph_view',         'public');
  cmgrant('read'   , 'ku$_m_zonemap_fh_view',         'public');
  cmgrant('read'   , 'ku$_m_zonemap_pfh_view',        'public');
  cmgrant('read'   , 'ku$_m_zonemap_iot_view',        'public');
  cmgrant('read'   , 'ku$_m_zonemap_piot_view',       'public');
  cmgrant('execute', 'ku$_refcol_t',                  'public');
  cmgrant('execute', 'ku$_refcol_list_t',             'public');
  cmgrant('execute', 'ku$_slog_t',                    'public');
  cmgrant('execute', 'ku$_slog_list_t',               'public');
  cmgrant('execute', 'ku$_m_view_log_t',              'public');
  cmgrant('execute', 'ku$_m_view_log_h_t',            'public');
  cmgrant('execute', 'ku$_m_view_log_ph_t',           'public');
  cmgrant('execute', 'ku$_m_view_log_fh_t',           'public');
  cmgrant('execute', 'ku$_m_view_log_pfh_t',          'public');
  cmgrant('select' , 'ku$_m_view_log_view',           'select_catalog_role');
  cmgrant('read'   , 'ku$_m_view_log_h_view',         'public');
  cmgrant('read'   , 'ku$_m_view_log_ph_view',        'public');
  cmgrant('read'   , 'ku$_m_view_log_fh_view',        'public');
  cmgrant('read'   , 'ku$_m_view_log_pfh_view',       'public');
  cmgrant('execute', 'ku$_library_t',                 'public');
  cmgrant('read'   , 'ku$_library_view',              'public');
  cmgrant('execute', 'ku$_xsprin_t',                  'public');
  cmgrant('read'   , 'ku$_xsprin_view',               'public');
  cmgrant('execute', 'ku$_xsobj_t',                   'public');
  cmgrant('execute', 'ku$_xsobj_list_t',              'public');
  cmgrant('read'   , 'ku$_xsobj_view',                'public');
  cmgrant('execute', 'ku$_xsuser_t',                  'public');
  cmgrant('read'   , 'ku$_xsuser_view',               'public');
  cmgrant('execute', 'ku$_xsgrant_t',                 'public');
  cmgrant('read'   , 'ku$_xsgrant_view',              'public');
  cmgrant('execute', 'ku$_xsrole_grant_t',            'public');
  cmgrant('read'   , 'ku$_xsrole_grant_view',         'public');
  cmgrant('execute', 'ku$_xsrgrant_list_t',           'public');
  cmgrant('execute', 'ku$_xsrole_t',                  'public');
  cmgrant('read'   , 'ku$_xsrole_view',               'public');
  cmgrant('execute', 'ku$_xsroleset_t',               'public');
  cmgrant('read'   , 'ku$_xsroleset_view',            'public');
  cmgrant('execute', 'ku$_xsaggpriv_t',               'public');
  cmgrant('read'   , 'ku$_xsaggpriv_view',            'public');
  cmgrant('execute', 'ku$_xsaggpriv_list_t',          'public');
  cmgrant('execute', 'ku$_xspriv_t',                  'public');
  cmgrant('read'   , 'ku$_xspriv_view',               'public');
  cmgrant('execute', 'ku$_xspriv_list_t',             'public');
  cmgrant('execute', 'ku$_xsacepriv_t',               'public');
  cmgrant('read'   , 'ku$_xsacepriv_view',            'public');
  cmgrant('execute', 'ku$_xsacepriv_list_t',          'public');
  cmgrant('execute', 'ku$_xssecclsh_t',               'public');
  cmgrant('execute', 'ku$_xssecclsh_list_t',          'public');
  cmgrant('read'   , 'ku$_xssecclsh_view',            'public');
  cmgrant('execute', 'ku$_xssclass_t',                'public');
  cmgrant('read'   , 'ku$_xssclass_view',             'public');
  cmgrant('execute', 'ku$_xsace_t',                   'public');
  cmgrant('execute', 'ku$_xsace_list_t',              'public');
  cmgrant('read'   , 'ku$_xsace_view',                'public');
  cmgrant('execute', 'ku$_xsaclparam_t',              'public');
  cmgrant('read'   , 'ku$_xsaclparam_view',           'public');
  cmgrant('execute', 'ku$_xsaclparam_list_t',         'public');
  cmgrant('execute', 'ku$_xsacl_t',                   'public');
  cmgrant('read'   , 'ku$_xsacl_view',                'public');
  cmgrant('execute', 'ku$_xspolicy_param_t',          'public');
  cmgrant('read'   , 'ku$_xspolicy_param_view',       'public');
  cmgrant('execute', 'ku$_xsinst_acl_t',              'public');
  cmgrant('read'   , 'ku$_xsinst_acl_view',           'public');
  cmgrant('execute', 'ku$_xsinstacl_list_t',          'public');
  cmgrant('execute', 'ku$_xsinst_rule_t',             'public');
  cmgrant('read'   , 'ku$_xsinst_rule_view',          'public');
  cmgrant('execute', 'ku$_xsinst_inhkey_t',           'public');
  cmgrant('read'   , 'ku$_xsinst_inhkey_view',        'public');
  cmgrant('execute', 'ku$_xsinstinhkey_list_t',       'public');
  cmgrant('execute', 'ku$_xsinst_inh_t',              'public');
  cmgrant('read'   , 'ku$_xsinst_inh_view',           'public');
  cmgrant('execute', 'ku$_xsinstinh_list_t',          'public');
  cmgrant('execute', 'ku$_xsattrsec_list_t',          'public');
  cmgrant('read'   , 'ku$_xsattrsec_view',            'public');
  cmgrant('execute', 'ku$_xsinstset_t',               'public');
  cmgrant('execute', 'ku$_xsinstset_list_t',          'public');
  cmgrant('read'   , 'ku$_xsinstset_view',            'public');
  cmgrant('execute', 'ku$_xsolap_policy_t',           'public');
  cmgrant('execute', 'ku$_xsolap_policy_list_t',      'public');
  cmgrant('read'   , 'ku$_xsolap_policy_view',        'public');
  cmgrant('read'   , 'ku$_xsrls_policy_view',         'public');
  cmgrant('execute', 'ku$_xspolicy_t',                'public');
  cmgrant('read'   , 'ku$_xspolicy_view',             'public');
  cmgrant('execute', 'ku$_xsnstmpl_attr_t',           'public');
  cmgrant('read'   , 'ku$_xsnstmpl_attr_view',        'public');
  cmgrant('execute', 'ku$_xsnstmpl_attr_list_t',      'public');
  cmgrant('execute', 'ku$_xsnspace_t',                'public');
  cmgrant('read'   , 'ku$_xsnspace_view',             'public');
  cmgrant('execute', 'ku$_user_t',                    'public');
  cmgrant('read'   , 'ku$_user_view',                 'public');
  cmgrant('execute', 'ku$_role_t',                    'public');
  cmgrant('read'   , 'ku$_role_view',                 'public');
  cmgrant('execute', 'ku$_profile_attr_t',            'public');
  cmgrant('select' , 'ku$_profile_attr_view',         'select_catalog_role');
  cmgrant('execute', 'ku$_profile_list_t',            'public');
  cmgrant('execute', 'ku$_profile_t',                 'public');
  cmgrant('read'   , 'ku$_profile_view',              'public');
  cmgrant('execute', 'ku$_defrole_item_t',            'public');
  cmgrant('select' , 'ku$_defrole_list_view',         'select_catalog_role');
  cmgrant('execute', 'ku$_defrole_list_t',            'public');
  cmgrant('execute', 'ku$_defrole_t',                 'public');
  cmgrant('read'   , 'ku$_defrole_view',              'public');
  cmgrant('execute', 'ku$_proxy_role_item_t',         'public');
  cmgrant('select' , 'ku$_proxy_role_list_view',      'select_catalog_role');
  cmgrant('execute', 'ku$_proxy_role_list_t',         'public');
  cmgrant('execute', 'ku$_proxy_t',                   'public');
  cmgrant('read'   , 'ku$_proxy_view',                'public');
  cmgrant('read'   , 'ku$_10_1_proxy_view',           'public');
  cmgrant('execute', 'ku$_rogrant_t',                 'public');
  cmgrant('read'   , 'ku$_rogrant_view',              'public');
  cmgrant('read'   , 'ku$_11_2_rogrant_view',         'public');
  cmgrant('read'   , 'ku$_10_2_rogrant_view',         'public');
  cmgrant('execute', 'ku$_tsquota_t',                 'public');
  cmgrant('read'   , 'ku$_tsquota_view',              'public');
  cmgrant('execute', 'ku$_resocost_item_t',           'public');
  cmgrant('select' , 'ku$_resocost_list_view',        'select_catalog_role');
  cmgrant('execute', 'ku$_resocost_list_t',           'public');
  cmgrant('execute', 'ku$_resocost_t',                'public');
  cmgrant('select' , 'ku$_resocost_view',             'select_catalog_role');
  cmgrant('execute', 'ku$_sequence_t',                'public');
  cmgrant('read'   , 'ku$_sequence_view',             'public');
  cmgrant('execute', 'ku$_context_t',                 'public');
  cmgrant('read'   , 'ku$_context_view',              'public');
  cmgrant('execute', 'ku$_dimension_t',               'public');
  cmgrant('read'   , 'ku$_dimension_view',            'public');
  cmgrant('execute', 'ku$_assoc_t',                   'public');
  cmgrant('read'   , 'ku$_assoc_view',                'public');
  cmgrant('select' , 'ku$_pwdvfc_view',               'select_catalog_role');
  cmgrant('execute', 'ku$_comment_t',                 'public');
  cmgrant('read'   , 'ku$_comment_view',              'public');
  cmgrant('read'   , 'ku$_10_1_comment_view',         'public');
  cmgrant('execute', 'ku$_cluster_t',                 'public');
  cmgrant('read'   , 'ku$_cluster_view',              'public');
  cmgrant('execute', 'ku$_audit_t',                   'public');
  cmgrant('read'   , 'ku$_audit_view',                'public');
  cmgrant('read'   , 'ku$_11_2_audit_view',           'public');
  cmgrant('execute', 'ku$_audit_obj_t',               'public');
  cmgrant('select' , 'ku$_audit_obj_base_view',       'select_catalog_role');
  cmgrant('read'   , 'ku$_audit_obj_view',            'public');
  cmgrant('execute', 'ku$_audit_default_t',           'public');
  cmgrant('select' , 'ku$_audit_default_view',        'select_catalog_role');
  cmgrant('read'   , 'ku$_java_objnum_view',          'public');
  cmgrant('execute', 'ku$_java_source_t',             'public');
  cmgrant('read'   , 'ku$_java_source_view',          'public');
  cmgrant('execute', 'ku$_qtab_storage_t',            'public');
  cmgrant('select' , 'ku$_qtab_storage_view',         'select_catalog_role');
  cmgrant('execute', 'ku$_queue_table_t',             'public');
  cmgrant('read'   , 'ku$_queue_table_view',          'public');
  cmgrant('execute', 'ku$_queues_t',                  'public');
  cmgrant('read'   , 'ku$_queues_view',               'public');
  cmgrant('execute', 'ku$_qtrans_t',                  'public');
  cmgrant('read'   , 'ku$_qtrans_view',               'public');
  cmgrant('execute', 'ku$_job_t',                     'public');
  cmgrant('read'   , 'ku$_job_view',                  'public');
  cmgrant('execute', 'ku$_histgrm_t',                 'public');
  cmgrant('execute', 'ku$_histgrm_list_t',            'public');
  cmgrant('select' , 'ku$_histgrm_view',              'select_catalog_role');
  cmgrant('select' , 'ku$_10_1_histgrm_min_view',     'select_catalog_role');
  cmgrant('select' , 'ku$_10_1_histgrm_max_view',     'select_catalog_role');
  cmgrant('execute', 'ku$_col_stats_t',               'public');
  cmgrant('execute', 'ku$_col_stats_list_t',          'public');
  cmgrant('execute', 'ku$_10_1_col_stats_t',          'public');
  cmgrant('execute', 'ku$_10_1_col_stats_list_t',     'public');
  cmgrant('select' , 'ku$_col_stats_view',            'select_catalog_role');
  cmgrant('select' , 'ku$_10_1_tab_col_stats_view',   'select_catalog_role');
  cmgrant('select' , 'ku$_10_1_ptab_col_stats_view',  'select_catalog_role');
  cmgrant('execute', 'ku$_cached_stats_t',            'public');
  cmgrant('select' , 'ku$_tab_cache_stats_view',      'select_catalog_role');
  cmgrant('select' , 'ku$_ind_cache_stats_view',      'select_catalog_role');
  cmgrant('execute', 'ku$_tab_ptab_stats_t',          'public');
  cmgrant('execute', 'ku$_ptab_stats_list_t',         'public');
  cmgrant('execute', 'ku$_10_1_tab_ptab_stats_t',     'public');
  cmgrant('execute', 'ku$_10_1_ptab_stats_list_t',    'public');
  cmgrant('select' , 'ku$_tab_only_stats_view',       'select_catalog_role');
  cmgrant('select' , 'ku$_10_1_tab_only_stats_view',  'select_catalog_role');
  cmgrant('select' , 'ku$_ptab_stats_view',           'select_catalog_role');
  cmgrant('select' , 'ku$_10_1_ptab_stats_view',      'select_catalog_role');
  cmgrant('execute', 'ku$_tab_col_t',                 'public');
  cmgrant('execute', 'ku$_tab_col_list_t',            'public');
  cmgrant('select' , 'ku$_tab_col_view',              'select_catalog_role');
  cmgrant('select' , 'ku$_10_2_tab_col_view',         'select_catalog_role');
  cmgrant('execute', 'ku$_tab_stats_t',               'public');
  cmgrant('execute', 'ku$_11_2_tab_stats_t',          'public');
  cmgrant('execute', 'ku$_10_1_tab_stats_t',          'public');
  cmgrant('read'   , 'ku$_tab_stats_view',            'public');
  cmgrant('read'   , 'ku$_11_2_tab_stats_view',       'public');
  cmgrant('read'   , 'ku$_10_2_tab_stats_view',       'public');
  cmgrant('read'   , 'ku$_10_1_tab_stats_view',       'public');
  cmgrant('execute', 'ku$_spind_stats_t',             'public');
  cmgrant('execute', 'ku$_spind_stats_list_t',        'public');
  cmgrant('execute', 'ku$_10_1_spind_stats_t',        'public');
  cmgrant('execute', 'ku$_10_1_spind_stats_list_t',   'public');
  cmgrant('select' , 'ku$_spind_stats_view',          'select_catalog_role');
  cmgrant('select' , 'ku$_10_1_spind_stats_view',     'select_catalog_role');
  cmgrant('execute', 'ku$_pind_stats_t',              'public');
  cmgrant('execute', 'ku$_pind_stats_list_t',         'public');
  cmgrant('execute', 'ku$_10_1_pind_stats_t',         'public');
  cmgrant('execute', 'ku$_10_1_pind_stats_list_t',    'public');
  cmgrant('select' , 'ku$_pind_stats_view',           'select_catalog_role');
  cmgrant('select' , 'ku$_10_1_pind_stats_view',      'select_catalog_role');
  cmgrant('select' , 'ku$_ind_col_view',              'select_catalog_role');
  cmgrant('execute', 'ku$_ind_stats_t',               'public');
  cmgrant('execute', 'ku$_11_2_ind_stats_t',          'public');
  cmgrant('execute', 'ku$_10_1_ind_stats_t',          'public');
  cmgrant('read'   , 'ku$_ind_stats_view',            'public');
  cmgrant('read'   , 'ku$_11_2_ind_stats_view',       'public');
  cmgrant('read'   , 'ku$_10_2_ind_stats_view',       'public');
  cmgrant('read'   , 'ku$_10_1_ind_stats_view',       'public');
  cmgrant('execute', 'ku$_sgi_col_t',                 'public');
  cmgrant('execute', 'ku$_sgi_col_list_t',            'public');
  cmgrant('select' , 'ku$_find_sgc_cols_view',        'select_catalog_role');
  cmgrant('select' , 'ku$_find_sgi_cols_view',        'select_catalog_role');
  cmgrant('execute', 'ku$_find_sgc_t',                'public');
  cmgrant('read'   , 'ku$_find_sgc_view',             'public');
  cmgrant('read'   , 'ku$_find_sgcol_view',           'public');
  cmgrant('read'   , 'ku$_find_attrcol_view',         'public');
  cmgrant('read'   , 'ku$_find_ntab_attrcol_view',    'public');
  cmgrant('execute', 'ku$_up_stats_t',                'public');
  cmgrant('execute', 'ku$_up_stats_list_t',           'public');
  cmgrant('select' , 'ku$_up_stats_view',             'select_catalog_role');
  cmgrant('execute', 'ku$_user_pref_stats_t',         'public');
  cmgrant('read'   , 'ku$_user_pref_stats_view',      'public');
  cmgrant('execute', 'ku$_java_class_t',              'public');
  cmgrant('read'   , 'ku$_java_class_view',           'public');
  cmgrant('execute', 'ku$_java_resource_t',           'public');
  cmgrant('read'   , 'ku$_java_resource_view',        'public');
  cmgrant('execute', 'ku$_add_snap_t',                'public');
  cmgrant('execute', 'ku$_add_snap_list_t',           'public');
  cmgrant('select' , 'ku$_add_snap_view',             'select_catalog_role');
  cmgrant('execute', 'ku$_refgroup_t',                'public');
  cmgrant('read'   , 'ku$_refgroup_view',             'public');
  cmgrant('execute', 'ku$_monitor_t',                 'select_catalog_role');
  cmgrant('read'   , 'ku$_monitor_view',              'public');
  cmgrant('execute', 'ku$_rmgr_plan_t',               'public');
  cmgrant('select' , 'ku$_rmgr_plan_view',            'select_catalog_role');
  cmgrant('execute', 'ku$_rmgr_plan_direct_t',        'public');
  cmgrant('select' , 'ku$_rmgr_plan_direct_view',     'select_catalog_role');
  cmgrant('execute', 'ku$_rmgr_consumer_t',           'public');
  cmgrant('select' , 'ku$_rmgr_consumer_view',        'select_catalog_role');
  cmgrant('execute', 'ku$_rmgr_init_consumer_t',      'public');
  cmgrant('select' , 'ku$_rmgr_init_consumer_view',   'select_catalog_role');
  cmgrant('execute', 'ku$_psw_hist_item_t',           'public');
  cmgrant('select' , 'ku$_psw_hist_list_view',        'exp_full_database');
  cmgrant('execute', 'ku$_psw_hist_list_t',           'public');
  cmgrant('execute', 'ku$_psw_hist_t',                'public');
  cmgrant('select' , 'ku$_psw_hist_view',             'exp_full_database');
  cmgrant('select' , 'ku$_11_2_psw_hist_view',        'exp_full_database');
  cmgrant('execute', 'ku$_objpkg_t',                  'public');
  cmgrant('read'   , 'ku$_objpkg_view',               'public');
  cmgrant('execute', 'ku$_objpkg_privs_t',            'public');
  cmgrant('select' , 'ku$_proc_grant_view',           'select_catalog_role');
  cmgrant('select' , 'ku$_proc_audit_view',           'select_catalog_role');
  cmgrant('read'   , 'ku$_exppkgobj_view',            'select_catalog_role');
  cmgrant('read'   , 'ku$_exppkgact_view',            'select_catalog_role');
  cmgrant('execute', 'ku$_procobj_t',                 'public');
  cmgrant('read'   , 'ku$_procobj_view',              'public');
  cmgrant('read'   , 'ku$_procobj_objnum_view',       'public');
  cmgrant('execute', 'ku$_procobj_grant_t',           'public');
  cmgrant('read'   , 'ku$_procobj_grant_view',        'public');
  cmgrant('execute', 'ku$_procobj_audit_t',           'public');
  cmgrant('read'   , 'ku$_procobj_audit_view',        'public');
  cmgrant('execute', 'ku$_procdepobj_t',              'public');
  cmgrant('read'   , 'ku$_procdepobj_view',           'public');
  cmgrant('execute', 'ku$_procdepobjg_t',             'public');
  cmgrant('read'   , 'ku$_procdepobj_grant_view',     'public');
  cmgrant('execute', 'ku$_procdepobja_t',             'public');
  cmgrant('read'   , 'ku$_procdepobj_audit_view',     'public');
  cmgrant('select' , 'ku$_prepost_view',              'select_catalog_role');
  cmgrant('execute', 'ku$_procobjact_t',              'public');
  cmgrant('read'   , 'ku$_procobjact_view',           'public');
  cmgrant('execute', 'ku$_procact_t',                 'public');
  cmgrant('select' , 'ku$_procact_sys_view',          'select_catalog_role');
  cmgrant('select' , 'ku$_procact_sys_pkg_view',      'select_catalog_role');
  cmgrant('execute', 'ku$_procact_schema_t',          'public');
  cmgrant('read'   , 'ku$_procact_schema_view',       'public');
  cmgrant('read'   , 'ku$_procact_schema_pkg_view',   'public');
  cmgrant('execute', 'ku$_procact_instance_t',        'public');
  cmgrant('execute', 'ku$_procact_instance_tbl_t',    'public');
  cmgrant('read'   , 'ku$_procact_instance_view',     'public');
  cmgrant('select' , 'ku$_expact_view',               'select_catalog_role');
  cmgrant('execute', 'ku$_prepost_table_t',           'public');
  cmgrant('read'   , 'ku$_pre_table_view',            'public');
  cmgrant('read'   , 'ku$_post_table_view',           'public');
  cmgrant('execute', 'ku$_callout_t',                 'public');
  cmgrant('select' , 'ku$_syscallout_view',           'select_catalog_role');
  cmgrant('read'   , 'ku$_schema_callout_view',       'public');
  cmgrant('read'   , 'ku$_instance_callout_view',     'public');
  cmgrant('select' , 'ku$_tts_tabview',               'select_catalog_role');
  cmgrant('select' , 'ku$_tts_tabpartview',           'select_catalog_role');
  cmgrant('select' , 'ku$_tts_tabsubpartview',        'select_catalog_role');
  cmgrant('select' , 'ku$_tts_tab_tablespace_view',   'select_catalog_role');
  cmgrant('select' , 'ku$_tts_idxview',               'select_catalog_role');
  cmgrant('select' , 'ku$_tts_indpartview',           'select_catalog_role');
  cmgrant('select' , 'ku$_ttsp_indpartview',          'select_catalog_role');
  cmgrant('select' , 'ku$_tts_indsubpartview',        'select_catalog_role');
  cmgrant('select' , 'ku$_ttsp_indsubpartview',       'select_catalog_role');
  cmgrant('select' , 'ku$_tts_idx_tablespace_view',   'select_catalog_role');
  cmgrant('select' , 'ku$_ttsp_idx_tablespace_view',  'select_catalog_role');
  cmgrant('read'   , 'ku$_plugts_begin_view',         'public');
  cmgrant('read'   , 'ku$_plugts_tsname_full_view',   'public');
  cmgrant('read'   , 'ku$_plugts_tsname_table_view',  'public');
  cmgrant('read'   , 'ku$_plugts_tsname_index_view',  'public');
  cmgrant('read'   , 'ku$_plugts_tsname_indexp_view', 'public');
  cmgrant('read'   , 'ku$_plugts_tsname_view',        'public');
  cmgrant('read'   , 'ku$_plugts_checkpl_view',       'public');
  cmgrant('execute', 'ku$_plugts_blk_t',              'public');
  cmgrant('read'   , 'ku$_plugts_blk_view',           'public');
  cmgrant('read'   , 'ku$_end_plugts_blk_view',       'public');
  cmgrant('select' , 'ku$_plugts_early_tblsp_view',   'select_catalog_role');
  cmgrant('execute', 'ku$_plugts_tablespace_t',       'public');
  cmgrant('select' , 'ku$_plugts_tablespace_view',    'select_catalog_role');
  cmgrant('read'   , 'DATAPUMP_PATHS_VERSION',        'public');
  cmgrant('read'   , 'DATAPUMP_PATHS',                'public');
  cmgrant('read'   , 'DATAPUMP_PATHMAP',              'public');
  cmgrant('read'   , 'DATAPUMP_TABLE_DATA',           'public');
  cmgrant('read'   , 'DATAPUMP_OBJECT_CONNECT',       'public');
  cmgrant('read'   , 'DATAPUMP_DDL_TRANSFORM_PARAMS', 'public');
  cmgrant('select' , 'DBA_EXPORT_OBJECTS',            'select_catalog_role');
  cmgrant('read'   , 'TABLE_EXPORT_OBJECTS',          'public');
  cmgrant('read'   , 'SCHEMA_EXPORT_OBJECTS',         'public');
  cmgrant('read'   , 'DATABASE_EXPORT_OBJECTS',       'public');
  cmgrant('read'   , 'TABLESPACE_EXPORT_OBJECTS',     'public');
  cmgrant('read'   , 'TRANSPORTABLE_EXPORT_OBJECTS',  'public');
  cmgrant('select' , 'DBA_EXPORT_PATHS',              'select_catalog_role');
  cmgrant('read'   , 'TABLE_EXPORT_PATHS',            'public');
  cmgrant('read'   , 'SCHEMA_EXPORT_PATHS',           'public');
  cmgrant('read'   , 'DATABASE_EXPORT_PATHS',         'public');
  cmgrant('read'   , 'TABLESPACE_EXPORT_PATHS',       'public');
  cmgrant('read'   , 'TRANSPORTABLE_EXPORT_PATHS',    'public');
  cmgrant('read'   , 'DATAPUMP_REMAP_OBJECTS',        'public');
  cmgrant('select' , 'dbms_metadata_all_transforms',  'select_catalog_role');
  cmgrant('read'   , 'dbms_metadata_transforms',      'public');
  cmgrant('read'   , 'dbms_metadata_transform_params','public');
  cmgrant('select' , 'dbms_metadata_all_tparams',     'select_catalog_role');
  cmgrant('read'   , 'dbms_metadata_parse_items',     'public');
  cmgrant('select' , 'dbms_metadata_all_parse_items', 'select_catalog_role');
  cmgrant('select' , 'dbms_metadata_tparams_base',    'select_catalog_role');
  cmgrant('execute', 'ku$_audit_act_list_t',          'public');
  cmgrant('execute', 'ku$_audit_act_t',               'public');
  cmgrant('execute', 'ku$_audit_attr_list_t',         'public');
  cmgrant('execute', 'ku$_audit_context_t',           'public');
  cmgrant('execute', 'ku$_audit_namespace_list_t',    'public');
  cmgrant('execute', 'ku$_audit_namespace_t',         'public');
  cmgrant('execute', 'ku$_audit_pol_role_list_t',     'public');
  cmgrant('execute', 'ku$_audit_pol_role_t',          'public');
  cmgrant('execute', 'ku$_audit_policy_enable_t',     'public');
  cmgrant('execute', 'ku$_audit_policy_t',            'public');
  cmgrant('execute', 'ku$_audit_sys_priv_list_t',     'public');
  cmgrant('execute', 'ku$_audit_sys_priv_t',          'public');
  cmgrant('execute', 'ku$_auditp_obj_list_t',         'public');
  cmgrant('execute', 'ku$_auditp_obj_t',              'public');
  cmgrant('select' , 'ku$_audcontext_namespace_view', 'select_catalog_role');
  cmgrant('select' , 'ku$_audcontext_user_view',      'select_catalog_role');
  cmgrant('read'   , 'ku$_audit_context_view',        'exp_full_database');
  cmgrant('read'   , 'ku$_audit_policy_enable_view',  'exp_full_database');
  cmgrant('read'   , 'ku$_12audit_policy_enable_view','exp_full_database');
  cmgrant('read'   , 'ku$_audit_policy_view',         'exp_full_database');
  cmgrant('execute', 'ku$_on_user_grant_t',           'public');
  cmgrant('read'   , 'ku$_on_user_grant_view',        'public');
  cmgrant('execute', 'ku$_code_base_grant_t',         'public');
  cmgrant('read'   , 'ku$_code_base_grant_view',      'public');
  cmgrant('execute', 'ku$_credential_t',              'public');
  cmgrant('read'   , 'ku$_credential_view',           'public');
  cmgrant('execute', 'ku$_user_editioning_t',         'public');
  cmgrant('execute', 'ku$_user_editioning_list_t',    'public');
  cmgrant('read'   , 'ku$_user_editioning_view',      'public');
  cmgrant('read'   , 'ku$_user_base_view',            'public');
  :catmetgrant2_summary := final_summary;
END;
/

PRINT :catmetgrant2_summary

@?/rdbms/admin/sqlsessend.sql

