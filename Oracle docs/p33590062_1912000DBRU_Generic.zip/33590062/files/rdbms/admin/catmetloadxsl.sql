Rem
Rem $Header: rdbms/admin/catmetloadxsl.sql sdavidso_blr_backport_32919937_19.12.0.0.210720dbru/2 2021/06/19 11:45:42 sdavidso Exp $
Rem
Rem catmetloadxsl.sql
Rem
Rem Copyright (c) 2019, 2021, Oracle and/or its affiliates.
Rem All rights reserved.
Rem
Rem    NAME
Rem      catmetloadxsl.sql - load xsl style sheets for DataPump Metadata API
Rem
Rem    DESCRIPTION
Rem      load stylesheets for DataPump Metadata API
Rem
Rem    NOTES
Rem
Rem    BEGIN SQL_FILE_METADATA
Rem    SQL_SOURCE_FILE: rdbms/admin/catmetloadxsl.sql
Rem    SQL_SHIPPED_FILE: rdbms/admin/catmetloadxsl.sql
Rem    SQL_PHASE: RDBMS_POSTAPPLY
Rem    SQL_STARTUP_MODE: NORMAL
Rem    SQL_IGNORABLE_ERRORS: NONE
Rem    SQL_CALLING_FILE: 
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    pamalik     05/24/21 - backout
Rem                           apfwkr_ci_backport_32019620_19.0.0.0.0dbru from
Rem                           19.12
Rem    apfwkr      04/02/21 - Backport
Rem                           bwright_blr_backport_32551008_19.10.0.0.210119dbru
Rem                           from st_rdbms_19.10.0.0.0dbru
Rem    rapayne     03/31/21 - load_stylesheets should not be commented out.
Rem    bwright     03/23/21 - Backport bwright_bug-32551008 from
Rem                           st_rdbms_19.10.0.0.0dbru
Rem    bwright     02/26/21 - Bug 32551008: reinvoke loading stylesheets.
Rem                           That is what this script is meant for.
Rem    mstasiew    09/13/19 - Bug 29943904: av materialize table not working
Rem    beiyu       07/11/19 - Created
Rem

@@?/rdbms/admin/sqlsessstart.sql

Rem exec dbms_metadata_util.load_stylesheets;

@?/rdbms/admin/sqlsessend.sql
 
