Rem Copyright (c) 1987, 2021, Oracle and/or its affiliates.
Rem All rights reserved.
Rem NAME
Rem    CATMETGRANT1.SQL - Grants of the Oracle dictionary for
Rem                       Metadata API.
Rem  FUNCTION
Rem     Grants privileges on views, objects and types of
Rem     the Oracle dictionary for use by the DataPump Metadata API.
Rem  NOTES
Rem     Must be run when connected to SYS or INTERNAL.
Rem     IMPORTANT! Keep the file catnomta.sql in synch with this file.
Rem     This is invoked by catnodp.sql during downgrade.
Rem
Rem     All types must have EXECUTE granted to PUBLIC.
Rem     All top-level views used by the mdAPI to actually fetch full object
Rem     metadata (eg, KU$_TABLE_VIEW) must have SELECT granted to PUBLIC, but
Rem     must have CURRENT_USERID checking security clause.
Rem     All views subordinate to the top level views (eg, KU$_SCHEMAOBJ_VIEW)
Rem     must have SELECT granted to SELECT_CATALOG_ROLE.
Rem
Rem     Put new grants into the smaller of this file or catmetgrant2.sql.
Rem     There are two files strictly for load balancing during || upgrade.
Rem
Rem     This entire script is ran in a temporary, anonymous PLSQL block.
Rem     Nothing is left around in the rare event this script is
Rem     interrupted in the middle.  Since we are dealing with granting
Rem     privileges, we don't want anything left around that even looks
Rem     like it could possibly be mis-used.
Rem
Rem BEGIN SQL_FILE_METADATA
Rem SQL_SOURCE_FILE: rdbms/admin/catmetgrant1.sql
Rem SQL_SHIPPED_FILE: rdbms/admin/catmetgrant1.sql
Rem SQL_PHASE: CATMETGRANT1
Rem SQL_STARTUP_MODE: NORMAL
Rem SQL_IGNORABLE_ERRORS: NONE
Rem SQL_CALLING_FILE: rdbms/admin/catpdeps.sql
Rem END SQL_FILE_METADATA
Rem
Rem  MODIFIED
Rem     apfwkr     04/02/21 - Backport
Rem                           bwright_blr_backport_32551008_19.10.0.0.210119dbru
Rem                           from st_rdbms_19.10.0.0.0dbru
Rem     apfwkr     01/13/21 - Backport rapayne_bug-32080081 from main
Rem     rapayne    11/03/20 - Bug 32080081: add COLLIST interface
Rem     bwright    03/23/21 - Backport bwright_bug-32551008 from
Rem                           st_rdbms_19.10.0.0.0dbru
Rem     bwright    03/02/21 - Bug 32551008: backport 31054943: perf improvement
Rem                           of catmetgrant1/2; 30051876: split HCS objects
Rem                           out from MDAPI files; 31113196: move ku$xktfbue
Rem                           to catdpb; 31207242: remove SQL SET commands 
Rem     jjanosik   03/29/18 - Bug 27568405: remove references to ku$_hnt_t and
Rem                           ku$_iont_t and add ku$_ntab_t
Rem     sjavagal   02/02/18 - Proj #74557: Add grants for DV app protection auth
Rem                           dummy view
Rem     sdavidso   10/20/17 - lrg20624856 add grant for
Rem                           KU$_P2T_DOMIDX_OBJNUM_VIEW
Rem     sdavidso   08/29/17 - bug25453685 move chunk - domain index
Rem     jjanosik   06/22/17 - Bug 24719359: Add support for RADM Policy
Rem                           Expressions
Rem     qinwu      01/19/17 - proj 70151: support db capture and replay auth
Rem     bwright    09/08/16 - Bug 24513141: Remove project 30935 implementation
Rem     sdavidso   02/20/16 - bug22577904 shard P2T - missing constraint
Rem     youyang    02/15/16 - bug22672722:dv support for index functions
Rem     sogugupt   12/03/15 - Remove ku$_find_hidden_cons_t 
Rem     sdavidso   11/24/15 - bug22264616 more move chunk subpart
Rem     smesropi   11/08/15 - Bug 21171628: Rename HCS views
Rem     sdavidso   11/02/15 - bug21869037 chunk move w/subpartitions
Rem     jibyun     11/01/15 - support DIAGNOSTIC auth for Database Vault
Rem     mstasiew   09/25/15 - Bug 21867527: hier cube measure cache
Rem     mstasiew   08/27/15 - Bug 21384694: hier hier attr classifications
Rem     sdavidso   08/17/15 - bug-20756759: lobs, indexes, droppped tables
Rem     tbhukya    08/17/15 - Bug 21555645: Partitioned mapping io table
Rem     sdavidso   08/03/15 - bug21539111: include check constraint for P2T exp
Rem     yanchuan   07/27/15 - Bug 21299533: support for Database Vault
Rem                           Authorization
Rem     sanbhara   06/01/15 - Bug 21158282 - adding ku$_dummy_comm_rule_alts_t
Rem                           and ku$_dummy_comm_rule_alts_v.
Rem     mstasiew   05/14/15 - Bug 20845789: more hcs views
Rem     sdavidso   03/13/15 - proj 56220 - partition transportable
Rem     sdavidso   03/06/15 - Parallel metadata export
Rem     beiyu      12/16/14 - Proj 47091: add grant for views of new HCS objs
Rem     skayoor    11/30/14 - Proj 58196: Change Select priv to Read Priv
Rem     kaizhuan   11/11/14 - Project 46812: support for Database Vault policy
Rem     gclaborn   09/12/14 - 30395: New views for source as tables
Rem     tbhukya    09/10/14 - Bug 13217417: Remove grant on ku$_12_1_index_view
Rem     jibyun     08/05/14 - Project 46812: support for Database Vault policy
Rem     lbarton    04/23/14 - bug 18374198: default on null
Rem     surman     12/29/13 - 13922626: Update SQL metadata
Rem     tbhukya    12/11/13 - Bug 17803321: Add grant to ku$_12_1_index_view
Rem     sdavidso   11/03/13 - bug17718297 - IMC selective column
Rem     lbarton    06/27/13 - bug 16800820: valid-time temporal
Rem     sdavidso   12/24/12 - XbranchMerge sdavidso_bug14490576-2 from
Rem                           st_rdbms_12.1.0.1
Rem     sdavidso   11/01/12 - bug14490576 - 2ndary tables for
Rem                           full/transportable
Rem     lbarton    10/11/12 - bug 14358248: non-privileged parallel export of
Rem                           views-as-tables fails
Rem     lbarton    10/03/12 - bug 10350062: ILM compression and storage tiering
Rem     bwright    10/03/12 - Bug 14679947: Add grant to ku$_object_error_view
Rem     rapayne    09/20/12 - bug 12899189: add grant to new view, 
Rem                           ku$_10_1_table_objnum_view.
Rem     lbarton    07/26/12 - bug 13454387: long varchar
Rem     surman     03/27/12 - 13615447: Add SQL patching tags
Rem     lbarton    10/27/11 - 36954_dpump_tabcluster_zonemap
Rem     lbarton    10/13/11 - bug 13092452: hygiene
Rem     jerrede    09/07/11 - Created for Parallel Upgrade Project #23496
Rem

@@?/rdbms/admin/sqlsessstart.sql

VARIABLE catmetgrant1_summary VARCHAR2(1024)
COLUMN   catmetgrant1_summary format a79
--
-- ----------------------------------------------------------------------------
-- The following functions/procedures/variables in this anonymous PLSQL block 
-- should remain identical to the ones in catmetgrant1.sql except for the 
-- references to the above summary variable which should be 
-- '<filename>_summary'. 
--
-- Also, note these functions/procedures are only visible within this
-- anonymous PLSQL block; they are never visible externally nor do they
-- persist after this script has been run.
-- ----------------------------------------------------------------------------
DECLARE
  v_last_err      VARCHAR2(500);
  v_skip_cnt      NUMBER := 0;
  v_grant_cnt     NUMBER := 0;
  v_error_cnt     NUMBER := 0;
  v_query_stmt    VARCHAR2(1000) :=
    'select 1 from dual where exists 
     (select 1
       from sys.objauth$ oa 
         inner join sys.obj$ o on (oa.obj# = o.obj#)
         inner join sys.user$ ue on (oa.grantee# = ue.user#)
         inner join table_privilege_map tpm
           on (oa.privilege# = tpm.privilege)
       where oa.grantor# = 0 and o.owner# = 0
         and oa.col# is null
         and (o.type# <> 13 or
             (o.type# = 13 and o.subname is null))
         and o.name = :1
         and ue.name = :2
         and tpm.name = :3)';

  FUNCTION final_summary
  RETURN VARCHAR2
  IS
    l_sum       VARCHAR2(1024);
  BEGIN
    l_sum := 'grants ' || 
             'skipped('   || v_skip_cnt  || '), ' || 
             'succeeded(' || v_grant_cnt || '), ' || 
             'failed('    || v_error_cnt || ')';
 
    IF v_last_err IS NOT NULL THEN                        -- display last error
      l_sum := l_sum || CHR(10) || v_last_err; 
    END IF;

    RETURN l_sum;
  END;

  --
  -- See if priv already exists on this object for this grantee.
  --
  FUNCTION is_granted (
    priv      IN VARCHAR2,  -- privilege to grant
    objnam    IN VARCHAR2,  -- on what object
    grantee   IN VARCHAR2)  -- to whom (the grantee)
  RETURN BOOLEAN IS
    l_exists     NUMBER := 0;
  BEGIN
    EXECUTE IMMEDIATE v_query_stmt 
                 INTO l_exists 
                USING UPPER(objnam), UPPER(grantee), UPPER(priv);
    IF l_exists = 1 THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END;
 
  --
  -- Try to grant the privilege
  --
  FUNCTION grant_priv (
    priv      IN VARCHAR2,  -- privilege to grant
    objnam    IN VARCHAR2,  -- on what object
    grantee   IN VARCHAR2)  -- to whom (the grantee)
  RETURN BOOLEAN IS
  BEGIN
    EXECUTE IMMEDIATE 'grant ' || priv    || 
                      ' on '   || objnam  || 
                      ' to '   || grantee;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN                       -- Don't expect any error on GRANT
      v_last_err := 'last error, granting ' || 
                     priv || ' on ' || objnam || ' to ' || grantee || ':' ||
                     CHR(10) || SUBSTR(SQLERRM, 1, 200);
      RETURN FALSE;
  END;

  --
  -- Check if the privilege is already granted before granting it.  This
  -- is a significant performance improvement over attempting to grant 
  -- a privilege that is already granted (not a cheap no-op).
  --
  PROCEDURE cmgrant(
    priv      IN VARCHAR2,  -- privilege to grant
    objnam    IN VARCHAR2,  -- on what object
    grantee   IN VARCHAR2)  -- to whom (the grantee)
  IS
  BEGIN
    IF is_granted(priv, objnam, grantee) THEN
      v_skip_cnt := v_skip_cnt + 1;                     -- Grant exists so skip
    ELSIF grant_priv(priv, objnam, grantee) THEN 
      v_grant_cnt := v_grant_cnt + 1;                   -- Grant was successful
    ELSE 
      v_error_cnt := v_error_cnt + 1;                         -- Error occurred
 
    END IF;
  END; 

BEGIN
  cmgrant('execute', 'ku$_schemaobj_t',               'public');
  cmgrant('select' , 'ku$_schemaobj_view',            'select_catalog_role');
  cmgrant('select' , 'ku$_schemaobjnum_view',         'select_catalog_role');
  cmgrant('select' , 'ku$_edition_schemaobj_view',    'select_catalog_role');
  cmgrant('select' , 'ku$_edition_obj_view',          'select_catalog_role');
  cmgrant('execute', 'ku$_storage_t',                 'public');
  cmgrant('select' , 'ku$_storage_view',              'select_catalog_role');
  cmgrant('execute', 'ku$_deferred_stg_t',            'public');
  cmgrant('select' , 'ku$_deferred_stg_view',         'select_catalog_role');
  cmgrant('execute', 'ku$_file_t',                    'public');
  cmgrant('select' , 'ku$_file_view',                 'select_catalog_role');
  cmgrant('execute', 'ku$_file_list_t',               'public');
  cmgrant('execute', 'ku$_tablespace_t',              'public');
  cmgrant('read'   , 'ku$_tablespace_view',           'public');
  cmgrant('execute', 'ku$_switch_compiler_t',         'public');
  cmgrant('read'   , 'ku$_switch_compiler_view',      'public');
  cmgrant('execute', 'ku$_simple_type_t',             'public');
  cmgrant('read'   , 'ku$_simple_type_view',          'public');
  cmgrant('execute', 'ku$_collection_t',              'public');
  cmgrant('read'   , 'ku$_collection_view',           'public');
  cmgrant('execute', 'ku$_argument_t',                'public');
  cmgrant('execute', 'ku$_argument_list_t',           'public');
  cmgrant('read'   , 'ku$_argument_view',             'public');
  cmgrant('execute', 'ku$_procinfo_t',                'public');
  cmgrant('read'   , 'ku$_procinfo_view',             'public');
  cmgrant('execute', 'ku$_procjava_t',                'public');
  cmgrant('read'   , 'ku$_procjava_view',             'public');
  cmgrant('execute', 'ku$_procc_t',                   'public');
  cmgrant('read'   , 'ku$_procc_view',                'public');
  cmgrant('execute', 'ku$_procplsql_t',               'public');
  cmgrant('read'   , 'ku$_procplsql_view',            'public');
  cmgrant('execute', 'ku$_method_list_t',             'public');
  cmgrant('read'   , 'ku$_method_view',               'public');
  cmgrant('execute' , 'ku$_type_attr_t',              'public');
  cmgrant('execute', 'ku$_type_attr_list_t',          'public');
  cmgrant('read'   , 'ku$_type_attr_view',            'public');
  cmgrant('execute', 'ku$_type_t',                    'public');
  cmgrant('read'   , 'ku$_type_view',                 'public');
  cmgrant('execute', 'ku$_type_body_t',               'public');
  cmgrant('read'   , 'ku$_type_body_view',            'public');
  cmgrant('execute', 'ku$_full_type_t',               'public');
  cmgrant('read'   , 'ku$_full_type_view',            'public');
  cmgrant('execute', 'ku$_exp_type_body_t',           'public');
  cmgrant('read'   , 'ku$_exp_type_body_view',        'public');
  cmgrant('read'   , 'ku$_inc_type_view',             'public');
  cmgrant('select' , 'ku$_deptypes_base_view',        'select_catalog_role');
  cmgrant('read'   , 'ku$_deptypes_view',             'public');
  cmgrant('execute', 'ku$_simple_col_t',              'public');
  cmgrant('execute', 'ku$_simple_col_list_t',         'public');
  cmgrant('select' , 'ku$_simple_col_view',           'select_catalog_role');
  cmgrant('select' , 'ku$_simple_setid_col_view',     'select_catalog_role');
  cmgrant('select' , 'ku$_simple_pkref_col_view',     'select_catalog_role');
  cmgrant('execute', 'ku$_index_col_t',               'public');
  cmgrant('execute', 'ku$_index_col_list_t',          'public');
  cmgrant('select' , 'ku$_index_col_view',            'select_catalog_role');
  cmgrant('execute', 'ku$_lobindex_t',                'public');
  cmgrant('select' , 'ku$_lobindex_view',             'select_catalog_role');
  cmgrant('execute', 'ku$_lob_t',                     'public');
  cmgrant('select' , 'ku$_lob_view',                  'select_catalog_role');
  cmgrant('select' , 'ku$_p2tlob_view',               'select_catalog_role');
  cmgrant('select' , 'ku$_sp2tlob_view',              'select_catalog_role');
  cmgrant('execute', 'ku$_partlob_t',                 'public');
  cmgrant('select' , 'ku$_partlob_view',              'select_catalog_role');
  cmgrant('select' , 'ku$_lobfragindex_view',         'select_catalog_role');
  cmgrant('select' , 'ku$_sublobfragindex_view',      'select_catalog_role');
  cmgrant('execute', 'ku$_lobfrag_list_t',            'public');
  cmgrant('select' , 'ku$_lobfrag_view',              'select_catalog_role');
  cmgrant('select' , 'ku$_piotlobfrag_view',          'select_catalog_role');
  cmgrant('select' , 'ku$_sublobfrag_view',           'select_catalog_role');
  cmgrant('execute', 'ku$_lobcomppart_t',             'public');
  cmgrant('execute', 'ku$_lobcomppart_list_t',        'public');
  cmgrant('select' , 'ku$_lobcomppart_view',          'select_catalog_role');
  cmgrant('execute', 'ku$_tlob_comppart_t',           'public');
  cmgrant('execute', 'ku$_tlob_comppart_list_t',      'public');
  cmgrant('select' , 'ku$_tlob_comppart_view',        'select_catalog_role');
  cmgrant('execute', 'ku$_temp_subpart_t',            'public');
  cmgrant('select' , 'ku$_temp_subpart_view',         'select_catalog_role');
  cmgrant('execute', 'ku$_temp_subpartdata_t',        'public');
  CMGRANT('read'   , 'ku$_temp_subpartdata_view',     'public');
  cmgrant('execute', 'ku$_temp_subpartlobfrg_t',      'public');
  cmgrant('select' , 'ku$_temp_subpartlobfrg_view',   'select_catalog_role');
  cmgrant('execute', 'ku$_temp_subpartlob_t',         'public');
  CMGRANT('read'   , 'ku$_temp_subpartlob_view',      'public');
  cmgrant('execute', 'ku$_hntp_t',                    'public');
  cmgrant('select' , 'ku$_hntp_view',                 'select_catalog_role');
  cmgrant('execute', 'ku$_ntpart_t',                  'public');
  cmgrant('select' , 'ku$_ntpart_view',               'select_catalog_role');
  cmgrant('execute', 'ku$_ntpart_list_t',             'public');
  cmgrant('execute', 'ku$_ntpart_parent_t',           'public');
  cmgrant('select' , 'ku$_ntpart_parent_view',        'select_catalog_role');
  cmgrant('execute', 'ku$_ind_part_t',                'public');
  cmgrant('execute', 'ku$_ind_part_list_t',           'public');
  cmgrant('select' , 'ku$_ind_part_view',             'select_catalog_role');
  cmgrant('execute', 'ku$_piot_part_t',               'public');
  cmgrant('execute', 'ku$_piot_part_list_t',          'public');
  cmgrant('select' , 'ku$_piot_part_view',            'select_catalog_role');
  cmgrant('execute', 'ku$_tab_part_t',                'public');
  cmgrant('execute', 'ku$_tab_part_list_t',           'public');
  cmgrant('select' , 'ku$_tab_part_view',             'select_catalog_role');
  cmgrant('execute', 'ku$_tab_subpart_t',             'public');
  cmgrant('execute', 'ku$_tab_subpart_list_t',        'public');
  cmgrant('select' , 'ku$_tab_subpart_view',          'select_catalog_role');
  cmgrant('execute', 'ku$_tab_tsubpart_t',            'public');
  cmgrant('execute', 'ku$_tab_tsubpart_list_t',       'public');
  cmgrant('select' , 'ku$_tab_tsubpart_view',         'select_catalog_role');
  cmgrant('execute', 'ku$_tab_compart_t',             'public');
  cmgrant('execute', 'ku$_tab_compart_list_t',        'public');
  cmgrant('select' , 'ku$_tab_compart_view',          'select_catalog_role');
  cmgrant('select' , 'ku$_ind_subpart_view',          'select_catalog_role');
  cmgrant('execute', 'ku$_ind_compart_t',             'public');
  cmgrant('execute', 'ku$_ind_compart_list_t',        'public');
  cmgrant('select' , 'ku$_ind_compart_view',          'select_catalog_role');
  cmgrant('execute', 'ku$_part_col_t',                'public');
  cmgrant('execute', 'ku$_part_col_list_t',           'public');
  cmgrant('select' , 'ku$_tab_part_col_view',         'select_catalog_role');
  cmgrant('select' , 'ku$_tab_subpart_col_view',      'select_catalog_role');
  cmgrant('select' , 'ku$_ind_part_col_view',         'select_catalog_role');
  cmgrant('select' , 'ku$_ind_subpart_col_view',      'select_catalog_role');
  cmgrant('execute', 'ku$_insert_ts_t',               'public');
  cmgrant('execute', 'ku$_insert_ts_list_t',          'public');
  cmgrant('select' , 'ku$_insert_ts_view',            'select_catalog_role');
  cmgrant('execute', 'ku$_partobj_t',                 'public');
  cmgrant('select' , 'ku$_partobj_view',              'select_catalog_role');
  cmgrant('execute', 'ku$_tab_partobj_t',             'public');
  cmgrant('select' , 'ku$_tab_partobj_view',          'select_catalog_role');
  cmgrant('execute', 'ku$_ind_partobj_t',             'public');
  cmgrant('select' , 'ku$_ind_partobj_view',          'select_catalog_role');
  cmgrant('execute', 'ku$_domidx_2ndtab_t',           'public');
  cmgrant('execute', 'ku$_domidx_2ndtab_list_t',      'public');
  cmgrant('select' , 'ku$_domidx_2ndtab_view',        'select_catalog_role');
  cmgrant('read'   , 'ku$_2ndtab_info_view',          'public');
  cmgrant('execute', 'ku$_domidx_plsql_t',            'public');
  cmgrant('select' , 'ku$_domidx_plsql_view',         'select_catalog_role');
  cmgrant('execute', 'ku$_jijoin_table_t',            'public');
  cmgrant('execute', 'ku$_jijoin_table_list_t',       'public');
  cmgrant('select' , 'ku$_jijoin_table_view',         'select_catalog_role');
  cmgrant('execute', 'ku$_jijoin_t',                  'public');
  cmgrant('execute', 'ku$_jijoin_list_t',             'public');
  cmgrant('select' , 'ku$_jijoin_view',               'select_catalog_role');
  cmgrant('execute', 'ku$_index_t',                   'public');
  cmgrant('execute', 'ku$_index_list_t',              'public');
  cmgrant('read'   , 'ku$_all_index_view',            'public');
  cmgrant('read'   , 'ku$_index_partition_view',      'public');
  cmgrant('read'   , 'ku$_domidx_partition_view',     'public');
  cmgrant('read'   , 'ku$_index_subpartition_view',   'public');
  cmgrant('read'   , 'ku$_index_view',                'public');
  cmgrant('read'   , 'ku$_index_objnum_view',         'public');
  cmgrant('read'   , 'ku$_10_2_index_view',           'public');
  cmgrant('execute', 'ku$_constraint_col_t',          'public');
  cmgrant('select' , 'ku$_constraint_col_view',       'select_catalog_role');
  cmgrant('execute', 'ku$_constraint_col_list_t',     'public');
  cmgrant('execute', 'ku$_im_colsel_t',               'public');
  cmgrant('execute', 'ku$_im_colsel_list_t',          'public');
  cmgrant('execute', 'ku$_constraint0_t',             'public');
  cmgrant('execute', 'ku$_constraint0_list_t',        'public');
  cmgrant('execute', 'ku$_constraint1_t',             'public');
  cmgrant('execute', 'ku$_constraint1_list_t',        'public');
  cmgrant('execute', 'ku$_constraint2_t',             'public');
  cmgrant('execute', 'ku$_constraint2_list_t',        'public');
  cmgrant('select' , 'ku$_im_colsel_view',            'select_catalog_role');
  cmgrant('select' , 'ku$_constraint0_view',          'select_catalog_role');
  cmgrant('select' , 'ku$_constraint1_view',          'select_catalog_role');
  cmgrant('select' , 'ku$_p2t_constraint1_view',      'select_catalog_role');
  cmgrant('select' , 'ku$_p2t_con1a_view',            'select_catalog_role');
  cmgrant('select' , 'ku$_p2t_con1b_view',            'select_catalog_role');
  cmgrant('select' , 'ku$_sp2t_constraint1_view',     'select_catalog_role');
  cmgrant('select' , 'ku$_sp2t_con1a_view',           'select_catalog_role');
  cmgrant('select' , 'ku$_constraint2_view',          'select_catalog_role');
  cmgrant('select' , 'ku$_p2t_constraint2_view',      'select_catalog_role');
  cmgrant('execute', 'ku$_pkref_constraint_t',        'public');
  cmgrant('execute', 'ku$_pkref_constraint_list_t',   'public');
  cmgrant('select' , 'ku$_pkref_constraint_view',     'select_catalog_role');
  cmgrant('execute', 'ku$_constraint_t',              'public');
  cmgrant('read'   , 'ku$_constraint_view',           'public');
  cmgrant('execute', 'ku$_ref_constraint_t',          'public');
  cmgrant('read'   , 'ku$_ref_constraint_view',       'public');
  cmgrant('read'   , 'ku$_find_hidden_cons_view',     'public');
  cmgrant('select' , 'ku$_prim_column_view',          'select_catalog_role');
  cmgrant('execute', 'ku$_subcoltype_t',              'public');
  cmgrant('execute', 'ku$_subcoltype_list_t',         'public');
  cmgrant('select' , 'ku$_subcoltype_view',           'select_catalog_role');
  cmgrant('execute', 'ku$_coltype_t',                 'public');
  cmgrant('select' , 'ku$_coltype_view',              'select_catalog_role');
  cmgrant('execute', 'ku$_xmlschema_t',               'public');
  cmgrant('read'   , 'ku$_xmlschema_view',            'public');
  cmgrant('read'   , 'ku$_exp_xmlschema_view',        'public');
  cmgrant('execute', 'ku$_xmlschema_elmt_t',          'public');
  cmgrant('select' , 'ku$_xmlschema_elmt_view',       'select_catalog_role');
  cmgrant('read'   , 'ku$_xmlschema_special_view',    'public');
  cmgrant('execute', 'ku$_opqtype_t',                 'public');
  cmgrant('select' , 'ku$_opqtype_view',              'select_catalog_role');
  cmgrant('execute', 'ku$_radm_policy_expr_t',        'public');
  cmgrant('select' , 'ku$_radm_policy_expr_view',     'select_catalog_role');
  cmgrant('execute', 'ku$_radm_mc_t',                 'public');
  cmgrant('execute', 'ku$_radm_mc_list_t',            'public');
  cmgrant('select' , 'ku$_radm_mc_view',              'select_catalog_role');
  cmgrant('execute', 'ku$_radm_policy_t',             'public');
  cmgrant('select' , 'ku$_radm_policy_view',          'select_catalog_role');
  cmgrant('execute', 'ku$_radm_fptm_t',               'public');
  cmgrant('select' , 'ku$_radm_fptm_view',            'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_isr_t',               'public');
  cmgrant('select' , 'ku$_dummy_isr_view',            'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_isrm_t',              'public');
  cmgrant('select' , 'ku$_dummy_isrm_view',           'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_realm_t',             'public');
  cmgrant('select' , 'ku$_dummy_realm_view',          'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_realm_member_t',      'public');
  cmgrant('select' , 'ku$_dummy_realm_member_view',   'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_realm_auth_t',        'public');
  cmgrant('select' , 'ku$_dummy_realm_auth_view',     'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_rule_t',              'public');
  cmgrant('select' , 'ku$_dummy_rule_view',           'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_rule_set_t',          'public');
  cmgrant('select' , 'ku$_dummy_rule_set_view',       'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_rule_set_member_t',   'public');
  cmgrant('select' , 'ku$_dummy_rule_set_member_view','select_catalog_role');
  cmgrant('execute', 'ku$_dummy_command_rule_t',      'public');
  cmgrant('select' , 'ku$_dummy_command_rule_view',   'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_comm_rule_alts_t',    'public');
  cmgrant('select' , 'ku$_dummy_comm_rule_alts_v',    'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_role_t',              'public');
  cmgrant('select' , 'ku$_dummy_role_view',           'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_factor_t',            'public');
  cmgrant('select' , 'ku$_dummy_factor_view',         'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_factor_link_t',       'public');
  cmgrant('select' , 'ku$_dummy_factor_link_view',    'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_factor_type_t',       'public');
  cmgrant('select' , 'ku$_dummy_factor_type_view',    'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_identity_t',          'public');
  cmgrant('select' , 'ku$_dummy_identity_view',       'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_identity_map_t',      'public');
  cmgrant('select' , 'ku$_dummy_identity_map_view',   'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_policy_t',            'public');
  cmgrant('select' , 'ku$_dummy_policy_v',            'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_policy_obj_r_t',      'public');
  cmgrant('select' , 'ku$_dummy_policy_obj_r_v',      'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_policy_obj_c_t',      'public');
  cmgrant('select' , 'ku$_dummy_policy_obj_c_v',      'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_policy_obj_c_alts_t', 'public');
  cmgrant('select' , 'ku$_dummy_policy_obj_c_alts_v', 'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_policy_owner_t',      'public');
  cmgrant('select' , 'ku$_dummy_policy_owner_v',      'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_dv_auth_dp_t',        'public');
  cmgrant('select' , 'ku$_dummy_dv_auth_dp_v',        'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_dv_auth_ap_t',        'public');
  cmgrant('select' , 'ku$_dummy_dv_auth_ap_v',        'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_dv_auth_tts_t',       'public');
  cmgrant('select' , 'ku$_dummy_dv_auth_tts_v',       'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_dv_auth_job_t',       'public');
  cmgrant('select' , 'ku$_dummy_dv_auth_job_v',       'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_dv_auth_proxy_t',     'public');
  cmgrant('select' , 'ku$_dummy_dv_auth_proxy_v',     'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_dv_auth_ddl_t',       'public');
  cmgrant('select' , 'ku$_dummy_dv_auth_ddl_v',       'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_dv_auth_prep_t',      'public');
  cmgrant('select' , 'ku$_dummy_dv_auth_prep_v',      'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_dv_auth_maint_t',     'public');
  cmgrant('select' , 'ku$_dummy_dv_auth_maint_v',     'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_dv_auth_diag_t',      'public');
  cmgrant('select' , 'ku$_dummy_dv_auth_diag_v',      'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_dv_index_func_t',     'public');
  cmgrant('select' , 'ku$_dummy_dv_index_func_v',     'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_dv_oradebug_t',       'public');
  cmgrant('select' , 'ku$_dummy_dv_oradebug_v',       'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_dv_accts_t',          'public');
  cmgrant('select' , 'ku$_dummy_dv_accts_v',          'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_dv_auth_dbcapture_t', 'public');
  cmgrant('select' , 'ku$_dummy_dv_auth_dbcapture_v', 'select_catalog_role');
  cmgrant('execute', 'ku$_dummy_dv_auth_dbreplay_t',  'public');
  cmgrant('select' , 'ku$_dummy_dv_auth_dbreplay_v',  'select_catalog_role');
  cmgrant('select' , 'ku$_table_xmlschema_view',      'select_catalog_role');
  cmgrant('execute', 'ku$_oidindex_t',                'public');
  cmgrant('select' , 'ku$_oidindex_view',             'select_catalog_role');
  cmgrant('select' , 'ku$_column_view',               'select_catalog_role');
  cmgrant('select' , 'ku$_pcolumn_view',              'select_catalog_role');
  cmgrant('select' , 'ku$_p2tpartcol_view',           'select_catalog_role');
  cmgrant('select' , 'ku$_p2tcolumn_view',            'select_catalog_role');
  cmgrant('select' , 'ku$_sp2tpartcol_view',          'select_catalog_role');
  cmgrant('select' , 'ku$_sp2tcolumn_view',           'select_catalog_role');
  cmgrant('execute', 'ku$_ov_table_t',                'public');
  cmgrant('select' , 'ku$_ov_table_view',             'select_catalog_role');
  cmgrant('execute', 'ku$_map_table_t',               'public');
  cmgrant('select' , 'ku$_map_table_view',            'select_catalog_role');
  cmgrant('execute', 'ku$_ntab_t',                    'public');
  cmgrant('select' , 'ku$_hnt_view',                  'select_catalog_role');
  cmgrant('select' , 'ku$_iont_view',                 'select_catalog_role');
  cmgrant('execute', 'ku$_nt_t',                      'public');
  cmgrant('execute', 'ku$_nt_list_t',                 'public');
  cmgrant('execute', 'ku$_nt_parent_t',               'public');
  cmgrant('select' , 'ku$_nt_parent_view',            'select_catalog_role');
  cmgrant('execute', 'ku$_tabcluster_t',              'public');
  cmgrant('select' , 'ku$_tabcluster_col_view',       'select_catalog_role');
  cmgrant('select' , 'ku$_tabcluster_view',           'select_catalog_role');
  cmgrant('execute', 'ku$_clstcol_t',                 'public');
  cmgrant('select' , 'ku$_clstcol_view',              'select_catalog_role');
  cmgrant('execute', 'ku$_clstcol_list_t',            'public');
  cmgrant('execute', 'ku$_clstjoin_t',                'public');
  cmgrant('execute', 'ku$_clstjoin_list_t',           'public');
  cmgrant('select' , 'ku$_clstjoin_view',             'select_catalog_role');
  cmgrant('execute', 'ku$_clst_zonemap_t',            'public');
  cmgrant('select' , 'ku$_clst_zonemap_view',         'select_catalog_role');
  cmgrant('execute', 'ku$_clst_t',                    'public');
  cmgrant('select' , 'ku$_clst_view',                 'select_catalog_role');
  cmgrant('execute', 'ku$_tabclst_t',                 'public');
  cmgrant('read'   , 'ku$_tabclst_view',              'public');
  cmgrant('execute', 'ku$_ilm_policy_t',              'public');
  cmgrant('execute', 'ku$_ilm_policy_list_t',         'public');
  cmgrant('select' , 'ku$_ilm_policy_view',           'select_catalog_role');
  cmgrant('select' , 'ku$_ilm_policy_view2',          'select_catalog_role');
  cmgrant('select' , 'ku$_tbs_ilm_policy_view',       'select_catalog_role');
  cmgrant('execute', 'ku$_extloc_t',                  'public');
  cmgrant('execute', 'ku$_extloc_list_t',             'public');
  cmgrant('execute', 'ku$_exttab_t',                  'public');
  cmgrant('read'   , 'ku$_exttab_view',               'public');
  cmgrant('execute', 'ku$_cube_fact_t',               'public');
  cmgrant('execute', 'ku$_cube_fact_list_t',          'public');
  cmgrant('execute', 'ku$_cube_hier_t',               'public');
  cmgrant('execute', 'ku$_cube_hier_list_t',          'public');
  cmgrant('execute', 'ku$_cube_dim_t',                'public');
  cmgrant('execute', 'ku$_cube_dim_list_t',           'public');
  cmgrant('execute', 'ku$_cube_tab_t',                'public');
  cmgrant('select' , 'ku$_cube_fact_view',            'select_catalog_role');
  cmgrant('select' , 'ku$_cube_tab_view',             'select_catalog_role');
  cmgrant('execute', 'ku$_fba_t',                     'public');
  cmgrant('select' , 'ku$_fba_view',                  'select_catalog_role');
  cmgrant('execute', 'ku$_fba_period_t',              'public');
  cmgrant('select' , 'ku$_fba_period_view',           'select_catalog_role');
  cmgrant('execute', 'ku$_collist_t',                 'public');
  cmgrant('read'   , 'ku$_collist_view',              'public');
  cmgrant('read'   , 'ku$_htable_view',               'public');
  cmgrant('read'   , 'ku$_10_1_htable_view',          'public');
  cmgrant('read'   , 'ku$_phtable_view',              'public');
  cmgrant('read'   , 'ku$_10_1_phtable_view',         'public');
  cmgrant('read'   , 'ku$_fhtable_view',              'public');
  cmgrant('read'   , 'ku$_10_2_fhtable_view',         'public');
  cmgrant('read'   , 'ku$_10_1_fhtable_view',         'public');
  cmgrant('read'   , 'ku$_pfhtable_view',             'public');
  cmgrant('read'   , 'ku$_10_1_pfhtable_view',        'public');
  cmgrant('read'   , 'ku$_ref_par_level_view',        'public');
  cmgrant('read'   , 'ku$_acptable_view',             'public');
  cmgrant('read'   , 'ku$_iotable_view',              'public');
  cmgrant('read'   , 'ku$_10_1_iotable_view',         'public');
  cmgrant('execute', 'ku$_ov_tabpart_t',              'public');
  cmgrant('execute', 'ku$_ov_tabpart_list_t',         'public');
  cmgrant('select' , 'ku$_ov_tabpart_view',           'select_catalog_role');
  cmgrant('execute', 'ku$_map_tabpart_list_t',        'public');
  cmgrant('select' , 'ku$_map_tabpart_view',          'select_catalog_role');
  cmgrant('execute', 'ku$_iot_partobj_t',             'public');
  cmgrant('select' , 'ku$_iot_partobj_view',          'select_catalog_role');
  cmgrant('read'   , 'ku$_piotable_view',             'public');
  cmgrant('read'   , 'ku$_10_1_piotable_view',        'public');
  cmgrant('execute', 'ku$_partition_t',               'public');
  cmgrant('read'   , 'ku$_partition_view',            'public');
  cmgrant('read'   , 'ku$_subpartition_view',         'public');
  cmgrant('execute', 'ku$_table_objnum_t',            'public');
  cmgrant('read'   , 'ku$_table_objnum_view',         'public');
  cmgrant('read'   , 'ku$_2nd_table_objnum_view',     'public');
  cmgrant('select' , 'ku$_ptable_ts_view',            'select_catalog_role');
  cmgrant('read'   , 'ku$_11_2_table_objnum_view',    'public');
  cmgrant('read'   , 'ku$_10_1_table_objnum_view',    'public');
  cmgrant('read'   , 'ku$_ntable_objnum_view',        'public');
  cmgrant('read'   , 'ku$_11_2_ntable_objnum_view',   'public');
  cmgrant('read'   , 'ku$_xdb_ntable_objnum_view',    'public');
  cmgrant('read'   , 'ku$_11_2_xdb_ntbl_objnum_view', 'public');
  cmgrant('read'   , 'ku$_deptable_objnum_view',      'public');
  cmgrant('read'   , 'ku$_11_2_deptbl_objnum_view',   'public');
  cmgrant('select' , 'ku$_table_types_view',          'select_catalog_role');
  cmgrant('select' , 'ku$_xmlschema_types_view',      'select_catalog_role');
  cmgrant('select' , 'ku$_tts_types_view',            'select_catalog_role');
  cmgrant('read'   , 'ku$_domidx_objnum_view',        'public');
  cmgrant('read'   , 'ku$_p2t_domidx_objnum_view',    'public');
  cmgrant('execute', 'ku$_option_objnum_t',           'public');
  cmgrant('select' , 'ku$_expreg',                    'select_catalog_role');
  cmgrant('select' , 'ku$_option_objnum_view',        'select_catalog_role');
  cmgrant('select' , 'ku$_option_view_objnum_view',   'select_catalog_role');
  cmgrant('execute', 'ku$_marker_t',                  'public');
  cmgrant('read'   , 'ku$_marker_view',               'public');
  cmgrant('read'   , 'ku$_tabprop_view',              'public');
  cmgrant('read'   , 'ku$_viewprop_view',             'public');
  cmgrant('read'   , 'ku$_view_exists_view',          'public');
  cmgrant('read'   , 'ku$_pfhtabprop_view',           'public');
  cmgrant('read'   , 'ku$_refparttabprop_view',       'public');
  cmgrant('read'   , 'ku$_mvprop_view',               'public');
  cmgrant('read'   , 'ku$_mvlprop_view',              'public');
  cmgrant('read'   , 'ku$_mzprop_view',               'public');
  cmgrant('read'   , 'ku$_syn_exists_view',           'public');
  cmgrant('read'   , 'ku$_objgrant_exists_view',      'public');
  cmgrant('read'   , 'ku$_constraint_exists_view',    'public');
  cmgrant('read'   , 'ku$_ref_constraint_exists_view','public');
  cmgrant('read'   , 'ku$_ind_exists_view',           'public');
  cmgrant('read'   , 'ku$_trig_exists_view',          'public');
  cmgrant('read'   , 'ku$_edition_trig_exists_view',  'public');
  cmgrant('read'   , 'ku$_proc_exists_view',          'public');
  cmgrant('read'   , 'ku$_edition_proc_exists_view',  'public');
  cmgrant('read'   , 'ku$_seq_in_default_view',       'public');
  cmgrant('select' , 'ku$_tts_view',                  'select_catalog_role');
  cmgrant('read'   , 'ku$_tab_ts_view',               'public');
  cmgrant('select' , 'ku$_tts_ind_view',              'select_catalog_role');
  cmgrant('read'   , 'ku$_ind_ts_view',               'public');
  cmgrant('read'   , 'ku$_clu_ts_view',               'public');
  cmgrant('select' , 'ku$_tts_mv_view',               'select_catalog_role');
  cmgrant('read'   , 'ku$_mv_ts_view',                'public');
  cmgrant('execute', 'ku$_mv_deptbl_objnum_t',        'public');
  cmgrant('read'   , 'ku$_mv_deptbl_objnum_view',     'public');
  cmgrant('select' , 'ku$_tts_mvl_view',              'select_catalog_role');
  cmgrant('read'   , 'ku$_mvl_ts_view',               'public');
  cmgrant('select' , 'ku$_unload_method_view',        'select_catalog_role');
  cmgrant('execute', 'ku$_bytes_alloc_t',             'public');
  cmgrant('select' , 'ku$_bytes_alloc_view',          'select_catalog_role');
  cmgrant('execute', 'ku$_tab_bytes_alloc_t',         'public');
  cmgrant('execute', 'ku$_table_data_t',              'public');
  cmgrant('select' , 'ku$_htable_bytes_alloc_view',   'select_catalog_role');
  cmgrant('read'   , 'ku$_htable_data_view',          'public');
  cmgrant('select' , 'ku$_htpart_bytes_alloc_view',   'select_catalog_role');
  cmgrant('read'   , 'ku$_htpart_data_view',          'public');
  cmgrant('select' , 'ku$_htspart_bytes_alloc_view',  'select_catalog_role');
  cmgrant('read'   , 'ku$_htspart_data_view',         'public');
  cmgrant('select' , 'ku$_iotable_bytes_alloc_view',  'select_catalog_role');
  cmgrant('read'   , 'ku$_iotable_data_view',         'public');
  cmgrant('select' , 'ku$_iotpart_bytes_alloc_view',  'select_catalog_role');
  cmgrant('read'   , 'ku$_iotpart_data_view',         'public');
  cmgrant('select' , 'ku$_ntable_bytes_alloc_view',   'select_catalog_role');
  cmgrant('read'   , 'ku$_ntable_data_view',          'public');
  cmgrant('read'   , 'ku$_niotable_data_view',        'public');
  cmgrant('select' , 'ku$_eqntable_bytes_alloc_view', 'select_catalog_role');
  cmgrant('read'   , 'ku$_eqntable_data_view',        'public');
  cmgrant('read'   , 'ku$_table_data_view',           'public');
  cmgrant('read'   , 'ku$_10_2_table_data_view',      'public');
  cmgrant('read'   , 'ku$_10_1_table_data_view',      'public');
  cmgrant('read'   , 'ku$_tab_subname_view',          'public');
  cmgrant('read'   , 'ku$_ind_subname_view',          'public');
  cmgrant('execute', 'ku$_post_data_table_t',         'public');
  cmgrant('read'   , 'ku$_post_data_table_view',      'public');
  cmgrant('execute', 'ku$_strmsubcoltype_t',          'public');
  cmgrant('execute', 'ku$_strmsubcoltype_list_t',     'public');
  cmgrant('select' , 'ku$_strmsubcoltype_view',       'select_catalog_role');
  cmgrant('execute', 'ku$_strmcoltype_t',             'public');
  cmgrant('select' , 'ku$_strmcoltype_view',          'select_catalog_role');
  cmgrant('select' , 'ku$_10_2_strmsubcoltype_view',  'select_catalog_role');
  cmgrant('execute', 'ku$_10_2_strmcoltype_t',        'public');
  cmgrant('select' , 'ku$_10_2_strmcoltype_view',     'select_catalog_role');
  cmgrant('execute', 'ku$_strmcol_t',                 'public');
  cmgrant('execute', 'ku$_strmcol_list_t',            'public');
  cmgrant('select' , 'ku$_strmcol_view',              'select_catalog_role');
  cmgrant('execute', 'ku$_10_2_strmcol_t',            'public');
  cmgrant('execute', 'ku$_10_2_strmcol_list_t',       'public');
  cmgrant('select' , 'ku$_10_2_strmcol_view',         'select_catalog_role');
  cmgrant('execute', 'ku$_strmtable_t',               'public');
  cmgrant('read'   , 'ku$_strmtable_view',            'public');
  cmgrant('execute', 'ku$_10_2_strmtable_t',          'public');
  cmgrant('read'   , 'ku$_10_2_strmtable_view',       'public');
  cmgrant('execute', 'ku$_proc_t',                    'public');
  cmgrant('select' , 'ku$_base_proc_view',            'select_catalog_role');
  cmgrant('execute', 'ku$_proc_objnum_t',             'public');
  cmgrant('select' , 'ku$_base_proc_objnum_view',     'select_catalog_role');
  cmgrant('read'   , 'ku$_proc_view',                 'public');
  cmgrant('read'   , 'ku$_func_view',                 'public');
  cmgrant('read'   , 'ku$_pkg_objnum_view',           'public');
  cmgrant('read'   , 'ku$_pkg_view',                  'public');
  cmgrant('read'   , 'ku$_pkgbdy_view',               'public');
  cmgrant('execute', 'ku$_full_pkg_t',                'public');
  cmgrant('read'   , 'ku$_full_pkg_view',             'public');
  cmgrant('execute', 'ku$_exp_pkg_body_t',            'public');
  cmgrant('read'   , 'ku$_exp_pkg_body_view',         'public');
  cmgrant('execute', 'ku$_alter_proc_t',              'public');
  cmgrant('read'   , 'ku$_alter_proc_view',           'public');
  cmgrant('read'   , 'ku$_alter_func_view',           'public');
  cmgrant('read'   , 'ku$_alter_pkgspc_view',         'public');
  cmgrant('read'   , 'ku$_alter_pkgbdy_view',         'public');
  cmgrant('execute', 'ku$_oparg_t',                   'public');
  cmgrant('execute', 'ku$_oparg_list_t',              'public');
  cmgrant('execute', 'ku$_opancillary_t',             'public');
  cmgrant('execute', 'ku$_opancillary_list_t',        'public');
  cmgrant('select' , 'ku$_opancillary_view',          'select_catalog_role');
  cmgrant('execute', 'ku$_opbinding_t',               'public');
  cmgrant('read'   , 'ku$_object_error_view',         'public');
  :catmetgrant1_summary := final_summary;
END;
/

PRINT :catmetgrant1_summary

@?/rdbms/admin/sqlsessend.sql


