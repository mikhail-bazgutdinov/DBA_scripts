Rem
Rem $Header: rdbms/admin/catmetgrants_hcs.sql sdavidso_blr_backport_32919937_19.12.0.0.210720dbru/1 2021/05/28 09:25:22 sdavidso Exp $
Rem
Rem catmetgrants_hcs.sql
Rem
Rem Copyright (c) 2021, Oracle and/or its affiliates.
Rem
Rem    NAME
Rem      catmetgrants_hcs.sql - HCS object grants for DataPump Metadata API
Rem
Rem    DESCRIPTION
Rem      grant privileges for HCS objects for DataPump Metadata API
Rem
Rem    NOTES
Rem     All types must have EXECUTE granted to PUBLIC.
Rem     All top-level views used by the mdAPI to actually fetch full object
Rem     metadata (eg, KU$_ANALYTIC_VIEW) must have SELECT granted to PUBLIC, 
Rem     but must have CURRENT_USERID checking security clause.
Rem     All views subordinate to the top level views (eg, KU$_HCS_SRC_VIEW)
Rem     must have SELECT granted to SELECT_CATALOG_ROLE.
Rem
Rem    BEGIN SQL_FILE_METADATA
Rem    SQL_SOURCE_FILE: rdbms/admin/catmetgrants_hcs.sql
Rem    SQL_SHIPPED_FILE: rdbms/admin/catmetgrants_hcs.sql
Rem    SQL_PHASE: CATMETGRANTS_HCS
Rem    SQL_STARTUP_MODE: NORMAL
Rem    SQL_IGNORABLE_ERRORS: NONE
Rem    SQL_CALLING_FILE: rdbms/admin/catpdeps.sql
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    bwright     02/25/21 - Bug 32551008: Backport 30051876: split HCS 
Rem                           objects out from MDAPI files
Rem

@@?/rdbms/admin/sqlsessstart.sql

------------------------------------------------------------------------------
--          ATTRIBUTE DIMENSION / HIERARCHY / ANALYTIC VIEW grants
------------------------------------------------------------------------------

grant execute on ku$_attribute_dimension_t to public
/
grant read on ku$_attribute_dimension_view to public
/
grant execute on ku$_hierarchy_t to public
/
grant read on ku$_hierarchy_view to public
/
grant execute on ku$_analytic_view_t to public
/
grant read on ku$_analytic_view to public
/
grant execute on ku$_attr_dim_lvl_ordby_t to public
/
grant execute on ku$_attr_dim_lvl_ordby_list_t to public
/
grant select on ku$_attr_dim_lvl_ordby_view to select_catalog_role
/
grant execute on ku$_attr_dim_lvl_t to public
/
grant execute on ku$_attr_dim_lvl_list_t to public
/
grant select on ku$_attr_dim_lvl_view to select_catalog_role
/
grant execute on ku$_attr_dim_attr_t to public
/
grant execute on ku$_attr_dim_attr_list_t to public
/
grant select on ku$_attr_dim_attr_view to select_catalog_role
/
grant execute on ku$_hier_lvl_t to public
/
grant execute on ku$_hier_lvl_list_t to public
/
grant select on ku$_hier_lvl_view to select_catalog_role
/
grant execute on ku$_hier_hier_attr_t to public
/
grant execute on ku$_hier_hier_attr_list_t to public
/
grant select on ku$_hier_hier_attr_view to select_catalog_role
/
grant execute on ku$_analytic_view_keys_t to public
/
grant execute on ku$_analytic_view_keys_list_t to public
/
grant select on ku$_analytic_view_keys_view to select_catalog_role
/
grant execute on ku$_analytic_view_hiers_t to public
/
grant execute on ku$_analytic_view_hiers_list_t to public
/
grant select on ku$_analytic_view_hiers_view to select_catalog_role
/
grant execute on ku$_analytic_view_dim_t to public
/
grant execute on ku$_analytic_view_dim_list_t to public
/
grant select on ku$_analytic_view_dim_view to select_catalog_role
/
grant execute on ku$_analytic_view_meas_t to public
/
grant execute on ku$_analytic_view_meas_list_t to public
/
grant select on ku$_analytic_view_meas_view to select_catalog_role
/
grant select on ku$_hcs_av_cache_dst_mslst to select_catalog_role
/
grant execute on ku$_hcs_av_cache_meas_t to public
/
grant execute on ku$_hcs_av_cache_meas_list_t to public
/
grant select on ku$_hcs_av_cache_meas_view to select_catalog_role
/
grant execute on ku$_hcs_av_cache_lvl_t to public
/
grant execute on ku$_hcs_av_cache_lvl_list_t to public
/
grant select on ku$_hcs_av_cache_lvl_view to select_catalog_role
/
grant execute on ku$_hcs_av_cache_lvgp_t to public
/
grant execute on ku$_hcs_av_cache_lvgp_list_t to public
/
grant select on ku$_hcs_av_cache_lvgp_view to select_catalog_role
/
grant execute on ku$_hcs_av_cache_mlst_t to public
/
grant execute on ku$_hcs_av_cache_mlst_list_t to public
/
grant select on ku$_hcs_av_cache_mlst_view to select_catalog_role
/
grant execute on ku$_attr_dim_join_path_t to public
/
grant execute on ku$_attr_dim_join_path_list_t to public
/
grant select on ku$_attr_dim_join_path_view to select_catalog_role
/
grant execute on ku$_hier_join_path_t to public
/
grant execute on ku$_hier_join_path_list_t to public
/
grant select on ku$_hier_join_path_view to select_catalog_role
/
grant execute on ku$_hcs_clsfctn_t to public
/
grant execute on ku$_hcs_clsfctn_list_t to public
/
grant select on ku$_hcs_clsfctn_view to select_catalog_role
/
grant execute on ku$_hcs_src_t to public
/
grant execute on ku$_hcs_src_list_t to public
/
grant select on ku$_hcs_src_view to select_catalog_role
/
grant execute on ku$_attr_dim_lvl_key_t to public
/
grant execute on ku$_attr_dim_lvl_key_list_t to public
/
grant execute on ku$_hcs_src_col_t to public
/
grant select on ku$_hcs_src_col_view to select_catalog_role
/
grant select on ku$_attr_dim_lvl_key_view to select_catalog_role
/

@?/rdbms/admin/sqlsessend.sql
 
