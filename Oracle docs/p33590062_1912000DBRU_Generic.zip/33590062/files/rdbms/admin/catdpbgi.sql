Rem
Rem $Header: rdbms/admin/catdpbgi.sql sdavidso_blr_backport_32919937_19.12.0.0.210720dbru/1 2021/05/28 09:25:22 sdavidso Exp $
Rem
Rem catdpbgi.sql
Rem
Rem Copyright (c) 2021, Oracle and/or its affiliates.
Rem All rights reserved.
Rem
Rem    NAME
Rem      catdpbgi.sql - Grants and Inserts for objects created in catdbp.sql
Rem
Rem    DESCRIPTION
Rem      This script conditionally grants privileges and inserts into rows
Rem      for Data Pump objects created in catdpb.sql.   This was split out from
Rem      catdpb.sql so the more dynamic operations done here of grants/inserts 
Rem      can be invoked from dpload.sql during the application of patches without
Rem      doing the heavy-handed actions of dropping/recreating the objects that
Rem      are done in catdpb.sql.  This reduces the number of objects invalidated
Rem      during the installation of a Data Pump patch.
Rem
Rem    NOTES
Rem      This script is called from dpload.sql during patching and during
Rem      database creation/upgrade/downgrade, etc:
Rem
Rem      Reload:    catrelod ------+
Rem                                |
Rem                                v
Rem      Upgrade:   catupgrd -> catproc -> catptabs-> catdpb -> catdpbgi
Rem                                ^                                ^
Rem                                |                                |
Rem      Downgrade: catdwgrd ------+                                |
Rem                                                                 |
REm      Patch:     dpload -----------------------------------------+
Rem
Rem
Rem BEGIN SQL_FILE_METADATA
Rem SQL_SOURCE_FILE: rdbms/admin/catdpbgi.sql
Rem SQL_SHIPPED_FILE: rdbms/admin/catdpbgi.sql
Rem SQL_PHASE: CATDPB
Rem SQL_STARTUP_MODE: NORMAL
Rem SQL_IGNORABLE_ERRORS: NONE
Rem SQL_CALLING_FILE: rdbms/admin/catdpb.sql
Rem END SQL_FILE_METADATA
Rem
Rem    MODIFIED (MM/DD/YY)
Rem    bwright   03/02/21 - Bug 32551008: backport 31113196: move ku$xktfbue
Rem                         creation to catdpb, 32195077: Move grants/inserts
Rem                         into catdpbgi.sql
Rem    bwright   03/02/21 - Created
Rem
@@?/rdbms/admin/sqlsessstart.sql

VARIABLE grants_on_catdpb_objs VARCHAR2(1024)
COLUMN   grants_on_catdpb_objs FORMAT A79

--
-- ============================================================
-- Issue grants, if necessary, on objects created in catdpb.sql
-- ============================================================
--
-- This is the only grant with the added 'with grant option' so it doesn't
-- work using the function below that queries for the privilege and only
-- issues the grant if the privilege doesn't already exist.
GRANT read ON sys.user_datapump_jobs TO PUBLIC WITH GRANT OPTION
/

DECLARE
  v_last_err    VARCHAR2(500);
  v_skip_cnt    NUMBER := 0;
  v_success_cnt NUMBER := 0;
  v_error_cnt   NUMBER := 0;
  v_sysqry      VARCHAR2(1000) :=
    'select 1 from sys.dual where exists 
     (select 1 from dba_sys_privs where privilege = :1 and grantee = :2)';
  v_roleqry     VARCHAR2(1000) :=
    'select 1 from sys.dual where exists 
     (select 1 from dba_role_privs where granted_role = :1 and grantee = :2)';
  v_tabqry      VARCHAR2(1000) :=
    'select 1 from sys.dual where exists 
     (select 1 from dba_tab_privs where privilege = :1 and grantee = :2 and
        owner=''SYS'' and table_name=:3)';

  FUNCTION final_summary
  RETURN        VARCHAR2
  IS
    l_sum       VARCHAR2(1024);
  BEGIN
    l_sum := 'skipped('   || v_skip_cnt    || '), ' || 
             'succeeded(' || v_success_cnt || '), ' || 
             'failed('    || v_error_cnt   || ')';
    IF v_last_err IS NOT NULL THEN                        -- display last error
      l_sum := l_sum || CHR(10) || v_last_err; 
    END IF;
    RETURN l_sum;
  END;

  --
  -- Check if the privilege is already granted before granting it.  No only
  -- is this a performance improvement, but 
  -- a privilege that is already granted (not a cheap no-op).
  --
  PROCEDURE grnt(
    privtyp  IN CHAR,                   -- 'S'ystem priv, 'T'able priv, 'R'ole
    priv     IN VARCHAR2,                           -- privilege/role to grant
    grantee  IN VARCHAR2,                             -- to whom (the grantee)
    objnam   IN VARCHAR2 DEFAULT NULL)                 -- (opt) on what object
  IS
    l_privtyp   CHAR := UPPER(privtyp);
    l_exists    NUMBER := 0;
  BEGIN
    --
    -- Query to see if priv/role is already granted to grantee
    --
    BEGIN
      IF l_privtyp = 'S' THEN
        EXECUTE IMMEDIATE v_sysqry
                     INTO l_exists 
                    USING UPPER(priv), UPPER(grantee);
      ELSIF l_privtyp = 'R' THEN
        EXECUTE IMMEDIATE v_roleqry
                     INTO l_exists 
                    USING UPPER(priv), UPPER(grantee);
      ELSIF l_privtyp = 'T' THEN
        EXECUTE IMMEDIATE v_tabqry
                     INTO l_exists 
                    USING UPPER(priv), UPPER(grantee), UPPER(objnam);
      END IF;

      -- Priv/role already granted, so skip granting it.
      IF l_exists = 1 THEN
        v_skip_cnt := v_skip_cnt + 1; 
        RETURN;
      END IF;

    EXCEPTION
      WHEN OTHERS THEN
        -- Ignore all query errors.  Drop down and try the grant.
        NULL;
    END;

    --
    -- Priv/role doesn't exist, so grant it now
    --
    IF objnam IS NULL THEN
      EXECUTE IMMEDIATE 'grant ' || priv || ' to ' || grantee;
    ELSE
      EXECUTE IMMEDIATE 'grant ' || priv || ' on sys.' || objnam || 
                        ' to ' || grantee;
    END IF;
    v_success_cnt := v_success_cnt + 1;                 -- Grant was successful

  EXCEPTION
    WHEN OTHERS THEN                         -- Don't expect any error on GRANT
      v_error_cnt := v_error_cnt + 1;                         -- Error occurred

      v_last_err := 'last error, granting ' || priv || ' to ' || grantee;
      IF objnam IS NOT NULL THEN
        v_last_err := v_last_err || ' on ' || objnam;
      END IF;
      v_last_err := v_last_err || ': ' || CHR(10) || SUBSTR(SQLERRM, 1, 200);
      RETURN;
  END;
BEGIN
  --
  -- ---------------------------t
  -- Grant system-privs to roles
  -- ---------------------------
  --         priv                         grantee
  --         ----                         -------
  grnt('S', 'analyze any',               'exp_full_database');
  grnt('S', 'create session',            'exp_full_database');
  -- Needed for fgac test in dpx3f2
  grnt('S', 'create table',              'exp_full_database');
  grnt('S', 'exempt redaction policy',   'exp_full_database');          -- RADM
  grnt('S', 'flashback any table',       'exp_full_database');
  
  grnt('S', 'alter database',            'imp_full_database');
  grnt('S', 'alter profile',             'imp_full_database');
  grnt('S', 'alter resource cost',       'imp_full_database');
  grnt('S', 'alter tablespace',          'imp_full_database');
  grnt('S', 'alter user',                'imp_full_database');
  grnt('S', 'audit any',                 'imp_full_database');
  grnt('S', 'audit system',              'imp_full_database');
  grnt('S', 'create profile',            'imp_full_database');
  grnt('S', 'create session',            'imp_full_database');
  grnt('S', 'delete any table',          'imp_full_database');
  grnt('S', 'execute any operator',      'imp_full_database');
  grnt('S', 'grant any object privilege','imp_full_database');
  grnt('S', 'grant any privilege',       'imp_full_database');
  grnt('S', 'grant any role',            'imp_full_database');
  grnt('S', 'select any table',          'imp_full_database');

  grnt('S', 'create session',            'datapump_exp_full_database');
  --  Needed for fgac test in dpx3f2 
  grnt('S', 'create table',              'datapump_exp_full_database');
  -- Even though we grant the old imp role to our Data Pump imp role
  -- (below) grant the same individual privileges given to the old 
  -- role to the Data Pump role here as well.  This way, should a
  -- customer ever delete the old imp role, the Data Pump role will
  -- still have all necessary privileges.  NOTE:  This is an incomplete
  -- list of privs/roles and should be updated. See catexp7.sql (WAW).
  grnt('S', 'alter database',            'datapump_imp_full_database');
  grnt('S', 'alter profile',             'datapump_imp_full_database');
  grnt('S', 'alter resource cost',       'datapump_imp_full_database');
  grnt('S', 'alter user',                'datapump_imp_full_database');
  grnt('S', 'audit any',                 'datapump_imp_full_database');
  grnt('S', 'audit system',              'datapump_imp_full_database');
  grnt('S', 'create profile',            'datapump_imp_full_database');
  grnt('S', 'create session',            'datapump_imp_full_database');
  grnt('S', 'delete any table',          'datapump_imp_full_database');
  grnt('S', 'execute any operator',      'datapump_imp_full_database');
  grnt('S', 'grant any object privilege','datapump_imp_full_database');
  grnt('S', 'grant any privilege',       'datapump_imp_full_database');
  grnt('S', 'grant any role',            'datapump_imp_full_database');
  grnt('S', 'select any table',          'datapump_imp_full_database');          

  -- ---------------------------
  -- Grant roles to roles
  -- ---------------------------
  -- Grant old exp/imp roles to Data Pump roles.  Note: Grant of old
  -- exp role is needed to make loopback network jobs work since the 
  -- application role makes it disappear otherwise. 
  --
  --         role                         grantee
  --         ----                         ------- 
  grnt('R', 'exp_full_database',         'datapump_exp_full_database');
  grnt('R', 'exp_full_database',         'datapump_imp_full_database');
  grnt('R', 'imp_full_database',         'datapump_imp_full_database');
  -- Grant Data Pump roles to DBA
  grnt('R', 'datapump_exp_full_database','dba');
  grnt('R', 'datapump_imp_full_database','dba');
  -- Grant import/export system privileges to dba
  grnt('S', 'export full database',      'dba');
  grnt('S', 'import full database',      'dba');

  -- -------------------------------------------------------------
  -- Grant table privilege to grantee on specific SYS tables/views
  -- -------------------------------------------------------------
  --          priv          grantee                               table/view
  --          ----          -------                               ----------
  grnt('T', 'delete',      'public',                   'data_pump_xpl_table$');
  grnt('T', 'insert',      'public',                   'data_pump_xpl_table$');
  grnt('T', 'select',      'public',                   'data_pump_xpl_table$');
  grnt('T', 'update',      'public',                   'data_pump_xpl_table$');
  grnt('T', 'delete',      'public',                   'ku$_list_filter_temp');
  grnt('T', 'insert',      'public',                   'ku$_list_filter_temp');
  grnt('T', 'select',      'public',                   'ku$_list_filter_temp');
  grnt('T', 'delete',      'public',                 'ku$_list_filter_temp_2');
  grnt('T', 'insert',      'public',                 'ku$_list_filter_temp_2');
  grnt('T', 'select',      'public',                 'ku$_list_filter_temp_2');
  -- Since table content is only visible within a session, and we only rely
  -- on the context within a sharding specific session, we can safely grant
  -- read and insert to PUBLIC.
  grnt('T', 'read',        'public',               'ku$_shard_domidx_namemap');
  grnt('T', 'insert',      'public',               'ku$_shard_domidx_namemap');
  -- Add privs to global temp table used to speed up ESTIMATE=BLOCKS
  grnt('T', 'read',        'public',                             'ku$xktfbue');
  grnt('T', 'insert',      'public',                             'ku$xktfbue');
  -- Registration of Oracle objects not to include in full database export.
  grnt('T', 'read',        'public',                          'ku_noexp_view');
  grnt('T', 'insert',      'public',                           'ku$noexp_tab');
  grnt('T', 'select',      'public',                           'ku$noexp_tab');
  -- For transportable import:
  grnt('T', 'delete',      'imp_full_database',              'expimp_tts_ct$');
  grnt('T', 'insert',      'imp_full_database',              'expimp_tts_ct$');
  grnt('T', 'select',      'imp_full_database',              'expimp_tts_ct$');
  grnt('T', 'update',      'imp_full_database',              'expimp_tts_ct$');
  -- 12c project 32006 RADM:
  grnt('T', 'delete',      'imp_full_database',                  'radm_fptm$');
  grnt('T', 'insert',      'imp_full_database',                  'radm_fptm$');
  grnt('T', 'select',      'imp_full_database',                  'radm_fptm$');
  grnt('T', 'select',      'select_catalog_role',         'dba_datapump_jobs');
  grnt('T', 'select',      'select_catalog_role',     'dba_datapump_sessions');
  grnt('T', 'select',      'select_catalog_role',         'cdb_datapump_jobs');
  grnt('T', 'select',      'select_catalog_role',     'cdb_datapump_sessions');
  grnt('T', 'flashback',   'select_catalog_role',     'ku$_user_mapping_view');
  grnt('T', 'select',      'select_catalog_role',     'ku$_user_mapping_view');
  grnt('T', 'select',      'select_catalog_role', 'ku$_user_mapping_view_tbl');  
  -- For Public Dynamic and Global Dynamic performance views
  grnt('T', 'select',      'select_catalog_role',           'v_$datapump_job');
  grnt('T', 'select',      'select_catalog_role',       'v_$datapump_session');
  grnt('T', 'select',      'select_catalog_role',          'gv_$datapump_job');
  grnt('T', 'select',      'select_catalog_role',      'gv_$datapump_session');
  -- So the worker can look at impcalloutreg$ from an account that just has
  -- IMPFULLDATABASE, grant select on impcalloutreg$ to select_catalog_role.
  -- IMPFULLDATABASE has been granted select_catalog_role.
  grnt('T', 'select',       'select_catalog_role',            'impcalloutreg$');

  COMMIT;
  :grants_on_catdpb_objs := final_summary;
END;
/
PRINT :grants_on_catdpb_objs

--
-- ============================================
-- Insert rows into ku_utluse, if necessary.
-- ============================================
--
VARIABLE inserts_into_ku_utluse VARCHAR2(1024)
COLUMN   inserts_into_ku_utluse FORMAT A79
DECLARE
  v_last_err    VARCHAR2(500);
  v_skip_cnt    NUMBER := 0;
  v_success_cnt NUMBER := 0;
  v_error_cnt   NUMBER := 0;

  FUNCTION final_summary
  RETURN        VARCHAR2
  IS
    l_sum       VARCHAR2(1024);
  BEGIN
    l_sum := 'skipped('   || v_skip_cnt    || '), ' || 
             'succeeded(' || v_success_cnt || '), ' || 
             'failed('    || v_error_cnt   || ')'; 
    IF v_last_err IS NOT NULL THEN                        -- display last error
      l_sum := l_sum || CHR(10) || v_last_err; 
    END IF;
    RETURN l_sum;
  END;

  --
  -- Check if the row exists and only insert if it doesn't.
  --
  PROCEDURE utluseins( 
    utlnam   IN VARCHAR2)
  IS
    l_exists    NUMBER := 0;
    l_qry       VARCHAR2(200);
    l_ins       VARCHAR2(200);
  BEGIN
    -- Set up query and insert stmts based on schema being null or not.
    l_qry := 'SELECT 1 FROM sys.ku_utluse WHERE utlname=:1';
    l_ins := 'INSERT INTO sys.ku_utluse VALUES(''' || utlnam || '''' ||
             ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0)';

    -- Query table to see if row already exists
    BEGIN
      EXECUTE IMMEDIATE l_qry INTO l_exists USING utlnam;
    EXCEPTION
      WHEN OTHERS THEN
        l_exists := 0;
    END;

    -- Row exists so skip the insert
    IF l_exists = 1 THEN
      v_skip_cnt := v_skip_cnt + 1;
      RETURN;
    END IF;

    -- Perform the insert.
    BEGIN
      EXECUTE IMMEDIATE l_ins;
      v_success_cnt := v_success_cnt + 1;              -- Insert was successful

    EXCEPTION
      WHEN OTHERS THEN
        -- Count # errors seen and record the error.
        v_error_cnt := v_error_cnt + 1;
        v_last_err := 'last error, inserting into ku_utluse for ' || 
                      utlnam || ':' ||
                      CHR(10) || SUBSTR(SQLERRM, 1, 200);
    END;
  END; 

BEGIN
--          utlname
--          -------
  utluseins('Oracle Utility Datapump (Export)');
  utluseins('Oracle Utility Datapump (Import)');
  utluseins('Oracle Utility SQL Loader (Direct Path Load)');
  utluseins('Oracle Utility Metadata API');
  utluseins('Oracle Utility External Table (ORACLE_DATAPUMP)');
  utluseins('Oracle Utility External Table (ORACLE_LOADER)');
  utluseins('Oracle Utility External Table (ORACLE_BIGSQL)');

  COMMIT;

  :inserts_into_ku_utluse := final_summary;
END;
/
PRINT :inserts_into_ku_utluse

--
-- ============================================
-- Insert rows into ku_noexp_tab, if necessary.
-- ============================================
-- This table holds objects that are not to be exported in a full export. This
-- and rows from sys.noexp$ form the complete exclusion set (which is built at
-- Data Pump run time into the global temporary table that it uses).  Leave
-- SYS.NOEXP$ as-is since external products use it.  IMPORTANT: Some metadata 
-- API views do not use this table but instead have their own hard-coded list
-- of schemas to exclude.  When a new schema is added to the exclude list, 
-- that list must be updated in catmetviews.sql.  Also 
-- datapump/ddl/prvtmetd.sqL may need to be updated for similar reasons.
--
VARIABLE inserts_into_ku_noexp_tab VARCHAR2(1024)
COLUMN   inserts_into_ku_noexp_tab FORMAT A79
DECLARE
  v_last_err    VARCHAR2(500);
  v_skip_cnt    NUMBER := 0;
  v_success_cnt NUMBER := 0;
  v_error_cnt   NUMBER := 0;

  FUNCTION final_summary
  RETURN        VARCHAR2
  IS
    l_sum       VARCHAR2(1024);
  BEGIN
    l_sum := 'skipped('   || v_skip_cnt  || '), ' || 
             'succeeded(' || v_success_cnt || '), ' || 
             'failed('    || v_error_cnt || ')';
    IF v_last_err IS NOT NULL THEN                        -- display last error
      l_sum := l_sum || CHR(10) || v_last_err; 
    END IF;
    RETURN l_sum;
  END;

  --
  -- Check if the row exists and only insert if it doesn't.
  --
  PROCEDURE noexpins(
    objtyp   IN VARCHAR2, 
    schema   IN VARCHAR2, 
    name     IN VARCHAR2)
  IS
    l_exists    NUMBER := 0;
    l_qry       VARCHAR2(200);
    l_ins       VARCHAR2(200);
    l_schema    VARCHAR2(128);
  BEGIN
    -- Set up query and insert stmts based on schema being null or not.
    l_qry := 'SELECT 1 FROM sys.ku_noexp_tab WHERE obj_type=:1 AND name=:2';
    l_ins := 'INSERT INTO sys.ku_noexp_tab (obj_type, schema, name) VALUES';
    IF schema IS NOT NULL THEN
      l_qry := l_qry || ' AND schema=:3';
      l_ins := l_ins || ' (''' || 
               objtyp || ''', ''' || 
               schema ||  ''', ''' || 
               name ||  ''')';
    ELSE
      l_qry := l_qry || ' AND schema is null';
      l_ins := l_ins || ' (''' || objtyp || ''', NULL, ''' || name || ''')';
    END IF;

    -- Query table to see if row already exists
    BEGIN
      IF schema IS NOT NULL THEN
        EXECUTE IMMEDIATE l_qry INTO l_exists USING objtyp, name, schema;
      ELSE
        EXECUTE IMMEDIATE l_qry INTO l_exists USING objtyp, name;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        l_exists := 0;
    END;

    -- Row exists so skip the insert
    IF l_exists = 1 THEN
      v_skip_cnt := v_skip_cnt + 1;
      RETURN;
    END IF;

    -- Perform the insert.
    BEGIN
      EXECUTE IMMEDIATE l_ins;
      v_success_cnt := v_success_cnt + 1;             -- Insert was successful 

    EXCEPTION
      WHEN OTHERS THEN
        -- Set up schema name for error handling.   
        IF schema IS NULL THEN
          l_schema := 'NULL';
        ELSE
          l_schema := schema;
        END IF;

        -- Count # errors seen and record the error.
        v_error_cnt := v_error_cnt + 1;
        v_last_err := 'last error, inserting into ku_noexp_tab (' || 
                      objtyp || ',' || l_schema || ',' || name || '):' ||
                      CHR(10) || SUBSTR(SQLERRM, 1, 200);
    END;
  END; 
BEGIN
-- ------------------
-- SCHEMAs to exclude
-- ------------------ 
-- NOTE: Many object types' exclusion filters use the following SCHEMA rows
--          objtyp                schema                            objname
--          ------                ------                            -------
  noexpins('SCHEMA',              NULL,                           'ANONYMOUS');
  noexpins('SCHEMA',              NULL,                         'APEX_030200');
  noexpins('SCHEMA',              NULL,                         'APEX_040000');
  noexpins('SCHEMA',              NULL,                         'APEX_040100');
  noexpins('SCHEMA',              NULL,                         'APEX_040200');
  noexpins('SCHEMA',              NULL,                         'APEX_050000');
  noexpins('SCHEMA',              NULL,                       'APEX_LISTENER');
  noexpins('SCHEMA',              NULL,                    'APEX_PUBLIC_USER');
  noexpins('SCHEMA',              NULL,               'APEX_REST_PUBLIC_USER');
  noexpins('SCHEMA',              NULL,                           'APPQOSSYS');
  noexpins('SCHEMA',              NULL,                              'AUDSYS');
  noexpins('SCHEMA',              NULL,                              'CTXSYS');
  noexpins('SCHEMA',              NULL,                           'DBSFWUSER');
  noexpins('SCHEMA',              NULL,                              'DBSNMP');
  noexpins('SCHEMA',              NULL,                                 'DIP');
  noexpins('SCHEMA',              NULL,                                 'DVF');
  noexpins('SCHEMA',              NULL,                               'DVSYS');
  noexpins('SCHEMA',              NULL,                              'EXFSYS');
  noexpins('SCHEMA',              NULL,                        'FLOWS_030000');
  noexpins('SCHEMA',              NULL,                        'FLOWS_030100');
  noexpins('SCHEMA',              NULL,                         'FLOWS_FILES');
  noexpins('SCHEMA',              NULL,                               'GGSYS');
  noexpins('SCHEMA',              NULL,                   'GSMADMIN_INTERNAL');
  noexpins('SCHEMA',              NULL,                          'GSMCATUSER');
  noexpins('SCHEMA',              NULL,                             'GSMUSER');
  noexpins('SCHEMA',              NULL,                             'LBACSYS');
  noexpins('SCHEMA',              NULL,                               'MDSYS');
  noexpins('SCHEMA',              NULL,                              'MGDSYS');
  noexpins('SCHEMA',              NULL,                             'OJVMSYS');
  noexpins('SCHEMA',              NULL,                             'OLAPSYS');
  noexpins('SCHEMA',              NULL,                          'ORACLE_OCM');
  noexpins('SCHEMA',              NULL,                             'ORDDATA');
  noexpins('SCHEMA',              NULL,                          'ORDPLUGINS');
  noexpins('SCHEMA',              NULL,                              'ORDSYS');
  noexpins('SCHEMA',              NULL,              'REMOTE_SCHEDULER_AGENT');
  noexpins('SCHEMA',              NULL,                  'SI_INFORMTN_SCHEMA');
  noexpins('SCHEMA',              NULL,                             'SYS$UMF');
  noexpins('SCHEMA',              NULL,                                 'SYS');
  noexpins('SCHEMA',              NULL,                           'SYSBACKUP');
  noexpins('SCHEMA',              NULL,                               'SYSDG');
  noexpins('SCHEMA',              NULL,                               'SYSKM');
  noexpins('SCHEMA',              NULL,                              'SYSRAC');
  noexpins('SCHEMA',              NULL,                              'TSMSYS');
  noexpins('SCHEMA',              NULL,                               'WMSYS');
  noexpins('SCHEMA',              NULL,                                 'XDB');
  noexpins('SCHEMA',              NULL,                             'XS$NULL');

  -- Roles: Note that most user and role exclusions are now accomplished
  -- by the fact that their Oracle-supplied or Common-user bit is set 
  -- (user$.spare1 0x100 and 0x80);
  noexpins('ROLE',                NULL,                          '_NEXT_USER');

  -- ------------------
  -- GRANTS to exclude
  -- ------------------
  -- Object grants
  noexpins('OBJECT_GRANT',        NULL,                              'SYSTEM');

  -- Role grants to Oracle-supplied users are excluded using the SCHEMA
  -- entries above. Add ROLE_GRANT rows below only for grants to roles.
  noexpins('ROLE_GRANT',          NULL,          'DATAPUMP_EXP_FULL_DATABASE');
  noexpins('ROLE_GRANT',          NULL,          'DATAPUMP_IMP_FULL_DATABASE');
  noexpins('ROLE_GRANT',          NULL,              'LOGSTDBY_ADMINISTRATOR');

  -- System grants to Oracle-supplied users are excluded using the SCHEMA
  -- entries above. Add SYSTEM_GRANT rows below only for grants to roles.
  noexpins('SYSTEM_GRANT',        NULL,                         'AUDIT_ADMIN');
  noexpins('SYSTEM_GRANT',        NULL,                        'AUDIT_VIEWER');
  noexpins('SYSTEM_GRANT',        NULL,                             'CONNECT');
  noexpins('SYSTEM_GRANT',        NULL,          'DATAPUMP_EXP_FULL_DATABASE');
  noexpins('SYSTEM_GRANT',        NULL,          'DATAPUMP_IMP_FULL_DATABASE');
  noexpins('SYSTEM_GRANT',        NULL,                                 'DBA');
  noexpins('SYSTEM_GRANT',        NULL,                   'EXP_FULL_DATABASE');
  noexpins('SYSTEM_GRANT',        NULL,                   'IMP_FULL_DATABASE');
  noexpins('SYSTEM_GRANT',        NULL,              'LOGSTDBY_ADMINISTRATOR');
  noexpins('SYSTEM_GRANT',        NULL,                            'RESOURCE');
  noexpins('SYSTEM_GRANT',        NULL,                          '_NEXT_USER');

  -- There are a couple static (rather unintuitive) on_user_grants required to
  -- make the new invoker's rights grant checking work. They are:
  -- GRANT INHERIT PRIVILEGES ON USER PUBLIC  TO PUBLIC  and
  -- GRANT INHERIT PRIVILEGES ON USER XS$NULL TO PUBLIC
  -- Add exclusion rows for these special cases here. Note that the schema rows
  -- above are used to exclude all on_user_grants where our internal schemas are
  -- the grantee.
  noexpins('ON_USER_GRANT',       NULL,                              'PUBLIC');
  noexpins('ON_USER_GRANT',       NULL,                             'XS$NULL');
 
  -- -------------------------------- 
  -- Miscellaneous objects to exclude
  -- --------------------------------
  noexpins('DB_LINK',    'PUBLIC', 'CDB$ROOT.REGRESS.RDBMS.DEV.US.ORACLE.COM');
  noexpins('DIRECTORY',           NULL,                             'IDR_DIR');
  noexpins('DIRECTORY',           NULL,                      'OPATCH_LOG_DIR');
  noexpins('DIRECTORY',           NULL,                   'OPATCH_SCRIPT_DIR');
  noexpins('DIRECTORY',           NULL,                     'OPATCH_TEMP_DIR');
  noexpins('DIRECTORY',           NULL,               'ORACLE_OCM_CONFIG_DIR');
  noexpins('DIRECTORY',           NULL,              'ORACLE_OCM_CONFIG_DIR2');
  noexpins('PROFILE',             NULL,                            'GSM_PROF');
  noexpins('PROFILE',             NULL,                    'ORA_STIG_PROFILE');
  noexpins('ROLLBACK_SEGMENT',    NULL,                              'SYSTEM');
  noexpins('SYNONYM',             'PUBLIC',                 'PRODUCT_PROFILE');
  noexpins('SYNONYM',             'PUBLIC',            'PRODUCT_USER_PROFILE');
  noexpins('SYNONYM',             'SYSTEM',            'PRODUCT_USER_PROFILE');
  noexpins('TABLE',               'SYSTEM',         'SQLPLUS_PRODUCT_PROFILE');
  noexpins('TABLESPACE',          NULL,                              'SYSAUX');
  noexpins('TABLESPACE',          NULL,                              'SYSTEM');
  noexpins('VIEW',                'SYSTEM',                   'PRODUCT_PRIVS');

  COMMIT;

  :inserts_into_ku_noexp_tab := final_summary;
END;
/
PRINT inserts_into_ku_noexp_tab

--
-- ======================================
-- Data Pump import callout registrations
-- ======================================
--
PROMPT 
PROMPT UPDATING IMPCALLOUTREG$
PROMPT --------------------------------------------------------------------------------

-- Delete all Oracle Multimedia (desupported in 19c) registrations.
DELETE FROM sys.impcalloutreg$ where tag='ORDIM';

-- Delete all Data Pump registrations, first.
DELETE FROM sys.impcalloutreg$ where tag='DATAPUMP';
 
-- Register the user mapping view.
INSERT INTO sys.impcalloutreg$ (
  package, schema, tag, class, level#, flags,
  tgt_schema, tgt_object, tgt_type)
VALUES (
  'DBMS_DATAPUMP_UTL', 'SYS', 'DATAPUMP', 3 , 1, 2,
  'SYS', 'KU$_USER_MAPPING_VIEW', 4);

-- Register a system callout that does various things when called post-import:
-- makes calls to transportable fixup routines for TSTZ and encrypted tables, 
-- and drops the user mapping tbl. It has a very high level# to ensure that 
-- it runs last so that the user mapping tbl is available as long as possible.
INSERT INTO sys.impcalloutreg$ (
  package, schema, tag, class, level#, flags,
  tgt_schema, tgt_object, tgt_type)
VALUES (
  'DBMS_DATAPUMP_UTL', 'SYS', 'DATAPUMP', 1, 999999999, 0, 
  '', '', 0);

COMMIT;
--
-- -------------------
-- End of catdpbgi.sql
-- -------------------
--
@?/rdbms/admin/sqlsessend.sql


