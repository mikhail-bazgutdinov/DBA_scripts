Rem
Rem $Header: rdbms/admin/catmetviews_hcs.sql sdavidso_blr_backport_32919937_19.12.0.0.210720dbru/1 2021/05/28 09:25:22 sdavidso Exp $
Rem
Rem catmetviews_hcs.sql
Rem
Rem Copyright (c) 2021, Oracle and/or its affiliates.
Rem
Rem    NAME
Rem      catmetviews_hcs.sql - HCS object views for DataPump Metadata API
Rem
Rem    DESCRIPTION
Rem      Creates HCS object views for use by the
Rem      DataPump Metadata API.
Rem
Rem    NOTES
Rem     All types must have EXECUTE granted to PUBLIC.
Rem     All top-level views used by the mdAPI to actually fetch full object
Rem     metadata (eg, KU$_ANALYTIC_VIEW) must have SELECT granted to PUBLIC,
Rem     but must have CURRENT_USERID checking security clause.
Rem     All views subordinate to the top level views (eg, KU$_HCS_SRC_VIEW)
Rem     must have SELECT granted to SELECT_CATALOG_ROLE.
Rem
Rem     Note that new views added to this file should be dropped in 
Rem     catnodp_hcs.sql.
Rem
Rem    BEGIN SQL_FILE_METADATA
Rem    SQL_SOURCE_FILE: rdbms/admin/catmetviews_hcs.sql
Rem    SQL_SHIPPED_FILE: rdbms/admin/catmetviews_hcs.sql
Rem    SQL_PHASE: CATMETVIEWS_HCS
Rem    SQL_STARTUP_MODE: NORMAL
Rem    SQL_IGNORABLE_ERRORS: NONE
Rem    SQL_CALLING_FILE: rdbms/admin/catpdeps.sql
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    bwright     02/25/21 - Bug 32551008: Backport 30051876: split HCS 
Rem                           objects out from MDAPI files
Rem    bwright     02/25/21 - Created
Rem

@@?/rdbms/admin/sqlsessstart.sql

-------------------------------------------------------------------------------
--           ATTRIBUTE DIMENSION / HIERARCHY / ANALYTIC VIEW views
-------------------------------------------------------------------------------

-- hcs src view
create or replace force view ku$_hcs_src_view of ku$_hcs_src_t
  with object identifier (hcs_obj#, src_id) as 
  select s.hcs_obj#,
         s.src#,
         s.owner,
         s.owner_in_ddl,
         s.name,
         s.alias,
         s.order_num
  from sys.hcs_src$ s
/

-- hcs src col view
create or replace force view ku$_hcs_src_col_view of ku$_hcs_src_col_t
  with object identifier (obj#, src_col#) as
  select sc.obj#,
         sc.src_col#,
         sc.obj_type,
         sc.table_alias,
         sc.src_col_name
  from sys.hcs_src_col$ sc
/

-- classification view
create or replace force view ku$_hcs_clsfctn_view of ku$_hcs_clsfctn_t
  with object identifier (obj#, sub_obj#, obj_type, clsfction_name) as
  select c.obj#,
         c.sub_obj#,
         c.obj_type,
         c.clsfction_name,
         c.clsfction_lang,
         c.clsfction_value,
         c.order_num
  from sys.hcs_clsfctn$ c
/

-- hier dim join path view
create or replace force view ku$_attr_dim_join_path_view
  of ku$_attr_dim_join_path_t
  with object identifier (dim_obj#, join_path_id) as
WITH
  cond_vars AS
    (SELECT
       '"' || lhsc.table_alias || '"."' || lhsc.src_col_name || '" = "' ||
       rhsc.table_alias || '"."' || rhsc.src_col_name || '"' cond,
       jce.dim# dimnum, jce.joinpath# joinpathnum, jce.order_num
     FROM hcs_dim_join_path$ djp, hcs_join_cond_elem$ jce, 
          hcs_src_col$ lhsc, hcs_src_col$ rhsc
     WHERE  jce.dim# = djp.dim#
            and jce.joinpath# = djp.joinpath#
            and jce.dim# = lhsc.obj# and jce.dim# = rhsc.obj# 
            and jce.lhs_src_col# = lhsc.src_col# 
            and jce.rhs_src_col# = rhsc.src_col# 
            and lhsc.obj_type = 12 
            and rhsc.obj_type = 12 
    ),
  all_cond_vars(cond, dimnum, joinpathnum, order_num) AS
    (SELECT cond, dimnum, joinpathnum, order_num
     FROM cond_vars
     WHERE order_num = 0
     UNION ALL
       (SELECT a.cond || ' AND ' || c.cond cond, c.dimnum, 
        c.joinpathnum, c.order_num
        FROM cond_vars c, all_cond_vars a
        WHERE c.joinpathnum = a.joinpathnum
              and c.dimnum = a.dimnum
              and c.order_num = a.order_num + 1
       )
    ),
  last_cond_vars AS
    (SELECT cond, dimnum, joinpathnum
     FROM
       (SELECT cond, dimnum, joinpathnum, order_num, 
           MAX(order_num) OVER (PARTITION BY dimnum, joinpathnum) max_order_num
        FROM all_cond_vars
       )
     WHERE order_num = max_order_num
    )
select djp.dim#,
       djp.joinpath#,
       djp.join_path_name,
       lcv.cond,
       djp.order_num
from   obj$ o, hcs_dim_join_path$ djp, user$ u, last_cond_vars lcv
where  o.owner# = u.user#
       and djp.dim# = o.obj#
       and djp.joinpath# = lcv.joinpathnum
       and djp.dim# = lcv.dimnum
/

-- hier join path view
create or replace force view ku$_hier_join_path_view
  of ku$_hier_join_path_t
  with object identifier (hier_obj#) as
  select hjp.hier#,
       hjp.join_path_name,
       hjp.order_num
  from  hcs_hier_join_path$ hjp
/

-- attribute dimension attr view
create or replace force view ku$_attr_dim_attr_view of ku$_attr_dim_attr_t
  with object identifier (dim_obj#, attr_id) as
  select a.dim#,
         a.attr#,
         a.attr_name,
         sc.table_alias,
         sc.src_col_name,
         cast(multiset(select c.*
                       from ku$_hcs_clsfctn_view c
                       where c.obj# = a.dim#
                       and c.sub_obj# = a.attr#
                       and c.obj_type = 4
                       order by c.order_num
                      ) as ku$_hcs_clsfctn_list_t
         ),
         a.order_num
  from sys.hcs_dim_attr$ a, sys.obj$ o, sys.obj$ co, 
       sys.hcs_dim$ d, sys.hcs_src_col$ sc
  where a.dim# = o.obj#
      and d.obj# = a.dim#
      and a.src_col# = sc.src_col#
      and sc.obj_type = 4 -- HCSDDL_DICT_TYPE_DIMATR
      and a.dim# = sc.obj#
      and co.obj# = sc.obj#
      and co.owner# = o.owner#
/

-- attribute dim level key view
create or replace force view ku$_attr_dim_lvl_key_view 
  of ku$_attr_dim_lvl_key_t
  with object identifier (dim_obj#, lvl_id, key_id) as
  select k.dim#,
         k.lvl#,
         k.lvl_key#,
         cast(multiset(select av.*
                       from ku$_attr_dim_attr_view av, 
                            hcs_dim_lvl_key_attr$ ka
                       where av.dim_obj# = ka.dim#
                             and av.attr_id = ka.attr#
                             and ka.lvl# = k.lvl#
                             and ka.lvl_key# = k.lvl_key#
                             and ka.dim# = k.dim#
                       order by ka.order_num) as ku$_attr_dim_attr_list_t
             ),
        k.order_num
  from sys.hcs_dim_lvl_key$ k
/

-- hier dim level order by view
create or replace force view ku$_attr_dim_lvl_ordby_view
  of ku$_attr_dim_lvl_ordby_t
  with object identifier (dim_obj#, lvl_id) as
select lo.dim#,
       dl.lvl#,
       DECODE(lo.aggr_func, 1, 'MIN', 2, 'MAX') AGG_FUNC,
       da.attr_name ATTRIBUTE_NAME,
       lo.order_num,
       DECODE(lo.is_asc, 1, 'ASC',0, 'DESC') CRITERIA,
       DECODE(lo.null_first, 1, 'FIRST', 0, 'LAST') NULLS_POSITION
from hcs_dim_attr$ da, hcs_dim_lvl$ dl, hcs_lvl_ord$ lo, obj$ o
where lo.dim# = o.obj#
      and dl.lvl# = lo.dim_lvl#
      and da.attr# = lo.attr#
      and o.obj# = dl.dim#
      and o.obj# = da.dim#
/

-- attribute dim level view
create or replace force view ku$_attr_dim_lvl_view
  of ku$_attr_dim_lvl_t
  with object identifier (dim_obj#, lvl_id) as
  select l.dim#,
         l.lvl#,
         l.lvl_name,
         l.member_name,
         l.member_caption,
         l.member_desc,
         DECODE(l.skip_when_null, 0, 'N', 'Y') SKIP_WHEN_NULL,
         DECODE(l.lvl_type, 1, 'STANDARD', 2, 'YEARS', 3, 'HALF_YEARS', 
		4, 'QUARTERS', 5, 'MONTHS', 6, 'WEEKS', 7, 'DAYS',
		8, 'HOURS', 9, 'MINUTES', 10, 'SECONDS')  LEVEL_TYPE,
         cast(multiset(select c.*
                       from ku$_hcs_clsfctn_view c
                       where c.obj# = l.dim#
                       and c.sub_obj# = l.lvl#
                       and c.obj_type = 5
                       order by c.order_num
                      ) as ku$_hcs_clsfctn_list_t
         ),
         cast(multiset(select lkv.*
                       from ku$_attr_dim_lvl_key_view lkv
                       where lkv.dim_obj# = l.dim#
                             and lkv.lvl_id = l.lvl#
                       order by lkv.order_num) as ku$_attr_dim_lvl_key_list_t
             ),
         cast(multiset(select ob.*
                       from ku$_attr_dim_lvl_ordby_view ob
                       where ob.dim_obj# = l.dim#
                             and ob.lvl_id = l.lvl#
                       order by ob.order_num) as ku$_attr_dim_lvl_ordby_list_t
             ),
         cast(multiset(select av.*
                       from ku$_attr_dim_attr_view av, hcs_dim_dtm_attr$ da
                       where av.dim_obj# = da.dim#
                             and av.attr_id = da.attr#
                             and da.dim# = l.dim#
                             and da.lvl# = l.lvl#
                             and da.in_minimal = 1
                       order by da.order_num
                      ) as ku$_attr_dim_attr_list_t
             ),
         l.order_num
  from sys.hcs_dim_lvl$ l
/

-- hier level view
create or replace force view ku$_hier_lvl_view
  of ku$_hier_lvl_t
  with object identifier (hier_obj#, name) as
  select h.obj#,
         hl.lvl_name,
         hl.order_num
  from obj$ o, hcs_hierarchy$ h, hcs_hr_lvl$ hl
  where h.obj# = o.obj#
      and hl.hier# = h.obj#
/

-- hierarchy hier attr view
create or replace force view ku$_hier_hier_attr_view
  of ku$_hier_hier_attr_t
  with object identifier (hier_obj#, name) as
  select h.obj#,
         ha.attr_name,
         case when ha.is_sys_expr = 0 then ha.expr else null end,
         cast(multiset(select c.*
                       from ku$_hcs_clsfctn_view c
                       where c.obj# = ha.hier#
                       and c.sub_obj# = ha.attr#
                       and c.obj_type = 11
                       order by c.order_num
                      ) as ku$_hcs_clsfctn_list_t
         ),
         ha.order_num
  from obj$ o, hcs_hierarchy$ h, hcs_hier_attr$ ha
  where h.obj# = o.obj#
      and ha.hier# = o.obj#
      and (exists (select * from ku$_hcs_clsfctn_view c
                  where c.obj# = ha.hier#
                  and c.sub_obj# = ha.attr#
                  and c.obj_type = 11)
          or ha.is_sys_expr = 0)
/


-- analytic view keys view
create or replace force view ku$_analytic_view_keys_view
  of ku$_analytic_view_keys_t
  with object identifier (av_obj#, dim_obj#, key_col_name) as
select av.obj#,
       avd.av_dim#,
       sc.src_col_name,
       k.ref_attr_name,
       k.order_num
from  hcs_analytic_view$ av, hcs_av_key$ k, hcs_av_dim$ avd, hcs_src_col$ sc
where av.obj# = k.av#
      and avd.av# = av.obj#
      and k.av_dim# = avd.av_dim#
      -- join for srcCol of analytic view key
      and k.src_col# = sc.src_col#
      and sc.obj# = k.av#
      and sc.obj_type = 10 -- HCSDDL_DICT_TYPE_AVKEY
/

-- analytic view hiers view
create or replace force view ku$_analytic_view_hiers_view
  of ku$_analytic_view_hiers_t
  with object identifier (av_obj#, dim_obj#, hier_name) as
select avh.av#,
       avh.av_dim#,
       avh.hier_owner,
       avh.owner_in_ddl,
       avh.hier_name,
       avh.hier_alias,       
       DECODE(avh.is_default, 0, 'N', 'Y') IS_DEFAULT,
       avh.ORDER_NUM
from hcs_av_hier$ avh
/

-- analytic view dim view
create or replace force view ku$_analytic_view_dim_view
  of ku$_analytic_view_dim_t
  with object identifier (av_obj#, dim_obj#) as
select avd.av#,
       avd.av_dim#,
       avd.dim_owner,
       avd.owner_in_ddl,	
       avd.dim_name,
       avd.alias,
       avd.ref_distinct,
       cast(multiset(select k.*
                       from ku$_analytic_view_keys_view k
                       where k.av_obj# = avd.av#
                       and k.dim_obj# = avd.av_dim#
                       order by k.order_num
                      ) as ku$_analytic_view_keys_list_t
         ),
       cast(multiset(select avh.*
                       from ku$_analytic_view_hiers_view avh
                       where avh.av_obj# = avd.av#
                       and avh.dim_obj# = avd.av_dim#
                       order by avh.order_num
                      ) as ku$_analytic_view_hiers_list_t
         ),
         cast(multiset(select c.*
                       from ku$_hcs_clsfctn_view c
                       where c.obj# = avd.av#
                       and c.sub_obj# = avd.av_dim#
                       and c.obj_type = 6    --HCSDDL_DICT_TYPE_AVDIM
                       order by c.order_num
                      ) as ku$_hcs_clsfctn_list_t
         ),
       avd.order_num
from hcs_av_dim$ avd
/

-- analytic view meas view
create or replace force view ku$_analytic_view_meas_view
  of ku$_analytic_view_meas_t
  with object identifier (av_obj#, meas_id) as
select avm.av#,
       avm.meas#,
       avm.meas_type,
       avm.meas_name,
       sc.src_col_name,
       avm.expr,
       upper(avm.aggr),
       cast(multiset(select c.*
                       from ku$_hcs_clsfctn_view c
                       where c.obj# = avm.av#
                       and c.sub_obj# = avm.meas#
                       and c.obj_type = 7
                       order by c.order_num
                      ) as ku$_hcs_clsfctn_list_t
         ),
       avm.order_num
from hcs_av_meas$ avm, sys.hcs_src_col$ sc
where avm.av# = sc.obj#
  and avm.src_col# = sc.src_col#
  and sc.obj_type = 7
union all
select avm.av#,
       avm.meas#,
       avm.meas_type,
       avm.meas_name,
       cast(null as varchar2(1)),
       avm.expr,
       cast(null as varchar2(1)),
       cast(multiset(select c.*
                       from ku$_hcs_clsfctn_view c
                       where c.obj# = avm.av#
                       and c.sub_obj# = avm.meas#
                       and c.obj_type = 7 -- HCSDDL_DICT_TYPE_MEAS
                       order by c.order_num
                      ) as ku$_hcs_clsfctn_list_t
         ),
       avm.order_num
from hcs_av_meas$ avm
where avm.meas_type = 2
/

-- analytic view cache views

create or replace force view ku$_hcs_av_cache_dst_mslst
as select distinct av#,
                   measlst#
   from hcs_av_lvlgrp$
/

create or replace force view ku$_hcs_av_cache_meas_view
  of ku$_hcs_av_cache_meas_t
  with object identifier (av_obj#, measlst#) as
  select av#,
         measlst#,
         meas_name,
         order_num
  from hcs_measlst_measures$
/

create or replace force view ku$_hcs_av_cache_lvl_view
  of ku$_hcs_av_cache_lvl_t
  with object identifier (av_obj#, lvlgrp#) as
  select av#,
         lvlgrp#,
         dim_alias,
         hier_alias,
         level_name,
         order_num
  from hcs_lvlgrp_lvls$
/

create or replace force view ku$_hcs_av_cache_lvgp_view
  of ku$_hcs_av_cache_lvgp_t
  with object identifier (av_obj#, lvlgrp#) as
  select lg.av#,
         lg.measlst#,
         lg.lvlgrp#,
         lg.cache_type,
         cast(multiset(select lgl.*
                from ku$_hcs_av_cache_lvl_view lgl
                where lgl.av_obj# = lg.av#
                and lgl.lvlgrp# = lg.lvlgrp#
                order by lgl.order_num
             ) as ku$_hcs_av_cache_lvl_list_t
         ),
         order_num
  from hcs_av_lvlgrp$ lg
/

create or replace force view ku$_hcs_av_cache_mlst_view
  of ku$_hcs_av_cache_mlst_t
  with object identifier (av_obj#, measlst#) as
  select dml.av#,
         dml.measlst#,
         cast(multiset(select cm.*
                 from ku$_hcs_av_cache_meas_view cm
                 where cm.av_obj# = dml.av#
                 and cm.measlst# = dml.measlst#
                 order by cm.order_num
             ) as ku$_hcs_av_cache_meas_list_t
         ),
         cast(multiset(select lg.*
                 from ku$_hcs_av_cache_lvgp_view lg
                 where lg.av_obj# = dml.av#
                 and lg.measlst# = dml.measlst#
                 order by lg.order_num
             ) as ku$_hcs_av_cache_lvgp_list_t
         )
  from ku$_hcs_av_cache_dst_mslst dml
/

-- end analytic view cache views


-- attribute dimension view
create or replace force view ku$_attribute_dimension_view 
  of ku$_attribute_dimension_t
  with object identifier (obj_num) as 
  select d.obj#,
         value(o),
         DECODE(d.dim_type, 1, 'STANDARD', 2, 'TIME') DIMENSION_TYPE,
         d.all_member_name ALL_MEMBER_NAME,
         d.all_member_caption ALL_MEMBER_CAPTION,
         d.all_member_desc ALL_MEMBER_DESC,
         cast(multiset(select sv.*
                       from ku$_hcs_src_view sv
                       where sv.hcs_obj# = d.obj#
                       order by sv.order_num
                      ) as ku$_hcs_src_list_t
         ),
         cast(multiset(select av.*
                       from ku$_attr_dim_attr_view av
                       where av.dim_obj# = d.obj#
                       order by av.order_num
                      ) as ku$_attr_dim_attr_list_t
         ),
         cast(multiset(select lv.*
                       from ku$_attr_dim_lvl_view lv
                       where lv.dim_obj# = d.obj#
                       order by lv.order_num
                      ) as ku$_attr_dim_lvl_list_t
         ),
         cast(multiset(select c.*
                       from ku$_hcs_clsfctn_view c
                       where c.obj# = d.obj#
                       and c.obj_type = 1
                       order by c.order_num
                      ) as ku$_hcs_clsfctn_list_t
         ),
         cast(multiset(select jp.*
                       from ku$_attr_dim_join_path_view jp
                       where jp.dim_obj# = d.obj#
                       order by jp.order_num
                       ) as ku$_attr_dim_join_path_list_t
         )
  from sys.hcs_dim$ d, sys.ku$_edition_schemaobj_view o
  where d.obj# = o.obj_num
         AND (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num, 0) OR
              EXISTS ( SELECT * FROM sys.session_roles
                       WHERE NLSSORT(role, 'NLS_SORT=BINARY') = NLSSORT('SELECT_CATALOG_ROLE', 'NLS_SORT=BINARY')))
/

-- hier view
create or replace force view ku$_hierarchy_view 
  of ku$_hierarchy_t
  with object identifier (obj_num) as 
  select h.obj#,
         value(o),
         h.dim_owner,
         h.owner_in_ddl,
         h.dim_name,
         cast(multiset(select lv.*
                       from ku$_hier_lvl_view lv
                       where lv.hier_obj# = h.obj#
                       order by lv.order_num desc
                      ) as ku$_hier_lvl_list_t
         ),
         cast(multiset(select c.*
                       from ku$_hcs_clsfctn_view c
                       where c.obj# = h.obj#
                       and c.obj_type = 2
                       order by c.order_num
                      ) as ku$_hcs_clsfctn_list_t
         ),
         cast(multiset(select jp.*
                       from ku$_hier_join_path_view jp
                       where jp.hier_obj# = h.obj#
                       order by jp.order_num
                       ) as ku$_hier_join_path_list_t
         ),
         cast(multiset(select ha.*
                       from ku$_hier_hier_attr_view ha
                       where ha.hier_obj# = h.obj#
                       order by ha.order_num
                       ) as ku$_hier_hier_attr_list_t
         )
  from sys.hcs_hierarchy$ h, sys.ku$_edition_schemaobj_view o
  where h.obj# = o.obj_num
         AND (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num, 0) OR
              EXISTS ( SELECT * FROM sys.session_roles
                       WHERE NLSSORT(role, 'NLS_SORT=BINARY') = NLSSORT('SELECT_CATALOG_ROLE', 'NLS_SORT=BINARY')))
/

-- analytic_view view
create or replace force view ku$_analytic_view
  of ku$_analytic_view_t
  with object identifier (obj_num) as 
  select av.obj#,
         value(o),
         avm.meas_name,
         upper(av.default_aggr),
         cast(multiset(select sv.*
                       from ku$_hcs_src_view sv
                       where sv.hcs_obj# = av.obj#
                       order by sv.order_num
                      ) as ku$_hcs_src_list_t
         ),
         cast(multiset(select avd.*
                       from ku$_analytic_view_dim_view avd
                       where avd.av_obj# = av.obj#
                       order by avd.order_num
                      ) as ku$_analytic_view_dim_list_t
         ),
         cast(multiset(select avm.*
                       from ku$_analytic_view_meas_view avm
                       where avm.av_obj# = av.obj#
                       order by avm.order_num
                      ) as ku$_analytic_view_meas_list_t
         ),
         cast(multiset(select c.*
                       from ku$_hcs_clsfctn_view c
                       where c.obj# = av.obj#
                       and c.obj_type = 3
                       order by c.order_num
                      ) as ku$_hcs_clsfctn_list_t
         ),
         cast(multiset(select cam.*
                       from ku$_hcs_av_cache_mlst_view cam
                       where cam.av_obj# = av.obj#
                      ) as ku$_hcs_av_cache_mlst_list_t
         ),
         av.dyn_all_cache
  from sys.hcs_analytic_view$ av, sys.ku$_edition_schemaobj_view o,
       sys.hcs_av_meas$ avm
  where av.obj# = o.obj_num
         AND (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num, 0) OR
              EXISTS ( SELECT * FROM sys.session_roles
                       WHERE NLSSORT(role, 'NLS_SORT=BINARY') = NLSSORT('SELECT_CATALOG_ROLE', 'NLS_SORT=BINARY')))
         AND av.obj# = avm.av#
         AND av.default_measure# = avm.meas#
/

@?/rdbms/admin/sqlsessend.sql
 
