Rem
Rem $Header: rdbms/admin/catnodpall.sql sdavidso_blr_backport_32919937_19.12.0.0.210720dbru/1 2021/05/28 09:25:21 sdavidso Exp $
Rem
Rem catnodpall.sql
Rem
Rem Copyright (c) 2002, 2021, Oracle and/or its affiliates.
Rem All rights reserved.
Rem
Rem    NAME
Rem     catnodpall.sql - Drop all DataPump components
Rem
Rem    DESCRIPTION 
Rem
Rem    NOTES
Rem     This script only gets executed from downgrade scripts.  
Rem
Rem    BEGIN SQL_FILE_METADATA
Rem     SQL_SOURCE_FILE: rdbms/admin/catnodpall.sql
Rem     SQL_SHIPPED_FILE: rdbms/admin/catnodpall.sql
Rem     SQL_PHASE: DOWNGRADE
Rem     SQL_STARTUP_MODE: DOWNGRADE
Rem     SQL_IGNORABLE_ERRORS: NONE
Rem     SQL_CALLING_FILE: rdbms/admin/catdwgrd.sql
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED (MM/DD/YY)
Rem    apfwkr    04/02/21 - Backport
Rem                         bwright_blr_backport_32551008_19.10.0.0.210119dbru
Rem                         from st_rdbms_19.10.0.0.0dbru
Rem    bwright   03/23/21 - Backport bwright_bug-32551008 from
Rem                         st_rdbms_19.10.0.0.0dbru
Rem    bwright   02/24/21 - Bug 32551008: backport 32316344
Rem    bwright   06/21/17 - Bug 25651930: Add OBSOLETE, ALL script options
Rem    bwright   06/21/17 - Created
Rem

@@?/rdbms/admin/sqlsessstart.sql

--------------------------------------------------
--     Start by dropping Data Pump's AQ tables
--------------------------------------------------
@@catnodpaq.sql

--------------------------------------------------
--     Wipe out all of Data Pump and Metadata API
--------------------------------------------------
@@catnodp.sql ALL

@?/rdbms/admin/sqlsessend.sql
