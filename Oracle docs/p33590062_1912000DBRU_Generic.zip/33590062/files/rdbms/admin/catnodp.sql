Rem
Rem $Header: rdbms/admin/catnodp.sql sdavidso_blr_backport_32919937_19.12.0.0.210720dbru/1 2021/05/28 09:25:21 sdavidso Exp $
Rem
Rem catnodp.sql
Rem
Rem Copyright (c) 2002, 2021, Oracle and/or its affiliates.
Rem All rights reserved.
Rem
Rem    NAME
Rem     catnodp.sql - Drop all DataPump components
Rem
Rem    DESCRIPTION
Rem 
Rem    PARAMETERS
Rem      opt - what option to use when executing this script:
Rem            OBSOLETE: remove obsolete and required objects only
Rem            ALL:      remove all objects (original behavior)
DEFINE opt=&1  
Rem
Rem    NOTES
Rem     This is the central script for dropping Data Pump and MDAPI
Rem     objects during any type of operation.  The new flow looks like:
Rem
Rem     Reload:    catrelod ------+
Rem                               |
Rem                               v
Rem     Upgrade:   catupgrd -> catproc -> catptabs
Rem                                          |
Rem                                          v
Rem     Patch:     dpload -------------> catnodpobs
Rem                                          |
Rem                                          v
Rem                                       catnodp ---> catnomta
Rem                                          ^
Rem                                          |
Rem     Downgrade: catdwgrd -----------> catnodpall
Rem
Rem     Data Pump's AQ tables are now dropped in its own script, catnodpaq.sql.
Rem     This gets invoked in dpload.sql and catnodpall.sql (as well as in
Rem     catdph.sql).
Rem 
Rem     All scripts invoked from catptabs.sql must be able to run in parallel 
Rem     (for upgrade).  Our scripts catnodpobs.sql and catdpb.sql are invoked
Rem     from there.  Therefore, when this script is invoked from catnodpobs 
Rem     with 'OBSOLETE' parameter value, it cannot be dropping any objects 
Rem     referenced in catdpb.sql.
Rem 
Rem     --------------------------------------------
Rem     Data Pump objects that we don't want to drop 
Rem     --------------------------------------------
Rem      1. Roles DATAPUMP_EXP_FULL_DATABASE and DATAPUMP_IMP_FULL_DATABASE.
Rem         The drop-role operation removes that role from every user who
Rem         was granted it.  This cannot be rolled back, nor is there any
Rem         automated way to regrant a role to those users after re-creating 
Rem         the roles. 
Rem      2. Table KU_UTLUSE. It is used for database utility feature tracking 
Rem         (SQL*Loader, impdp, expdp, metadata API).  Downgrade scripts expect
Rem         this table to exist, so don't drop it,
Rem
Rem      Regarding the obs parameter values to the drop procedure:  
Rem      - ALWAYS:  Some objects always need to be dropped in order for
Rem        upgrade/patch/etc to succeed.  For example, always drop our global
Rem        temporary table as well as certain XDB related objects.
Rem      - OBS: Views are created using "create or replace" and this
Rem        effectively drops the old view and creates the new view.  However,
Rem        views that are no longer part of MDAPI (e.g. obsolete) would never
Rem        get dropped if not for doing it here. If the type that describes the
Rem        object view changes, the view gets recompiled and fails, leaving 
Rem        invalid objects.
Rem
Rem    BEGIN SQL_FILE_METADATA
Rem     SQL_SOURCE_FILE: rdbms/admin/catnodp.sql
Rem     SQL_SHIPPED_FILE: rdbms/admin/catnodp.sql
Rem     SQL_PHASE: UPGRADE
Rem     SQL_STARTUP_MODE: UPGRADE
Rem     SQL_IGNORABLE_ERRORS: NONE
Rem     SQL_CALLING_FILE: rdbms/admin/catnodpobs.sql
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    apfwkr      04/02/21 - Backport
Rem                           bwright_blr_backport_32551008_19.10.0.0.210119dbru
Rem                           from st_rdbms_19.10.0.0.0dbru
Rem    bwright     03/23/21 - Backport bwright_bug-32551008 from
Rem                           st_rdbms_19.10.0.0.0dbru
Rem    bwright     02/24/21 - Bug 32551008: backport 29835516, 31207734,
Rem                           32195313 and 32316344
Rem    bwright     10/03/17 - RTI 20625267: drop ku$_shard_domidx_namemap
Rem    bwright     09/14/17 - Bug 26797585: Remove disabling of SQL echo
Rem    bwright     08/14/17 - RTI 20496727: catdpb, catnodpobs run concurrently
Rem                           during upgrade, so cannot have any overlaps
Rem    bwright     08/03/17 - Bug 26290098: drop new KUPUTIL synonym
Rem    bwright     08/03/17 - Bug 26570943: Ignore index-does-not-exist error
Rem    bwright     06/13/17 - Bug 25651930: Add OBSOLETE, ALL script options
Rem    raeburns    03/25/17 - Bug 25752691: Use SQL_PHASE DOWNGRADE 
Rem    bwright     09/21/16 - Bug 24704817: Cleanup output from running dpload
Rem    sdipirro    07/01/15 - Fix invalid jobstatus object on downgrade
Rem    sdipirro    05/26/15 - Fix potential lident issue
Rem    tmontgom    05/15/14 - Drop new synonyms, showing up in dpload.sql.
Rem                           Noticed by rapayne as part of Bug 17039620.
Rem    gclaborn    10/19/10 - drop user mapping view stuff
Rem    sdipirro    01/15/08 - New status types for 11.2
Rem    wfisher     02/02/07 - Adding ku$_list_filter_temp
Rem    rburns      08/13/06 - add drop_queue and drop tables
Rem    tbgraves    04/14/04 - drop DBMS_DATAPUMP_UTL package 
Rem    sdipirro    04/16/04 - New dumpfile info type and synonym 
Rem    sdipirro    03/02/04 - New status types and synonyms to drop 
Rem    sdipirro    08/11/03 - Versioning for public types
Rem    ebatbout    06/03/03 - Drop package, kupd$data
Rem    gclaborn    03/09/03 - Drop package kupc$que_int
Rem    gclaborn    12/12/02 - Drop new tables
Rem    gclaborn    12/06/02 - Add new objects
Rem    sdipirro    11/21/02 - Remove obsolete emulation types
Rem    jkaloger    05/28/02 - Add filemgr internal package
Rem    gclaborn    05/24/02 - Add prvt{h|b}pci
Rem    emagrath    05/13/02 - Add Datapump fixed table support
Rem    sdipirro    04/18/02 - Add datapump packages
Rem    gclaborn    04/14/02 - gclaborn_catdp
Rem    gclaborn    04/09/02 - Created
Rem

@@?/rdbms/admin/sqlsessstart.sql

----------------------------------------------
-- First, drop all Metadata API objects
----------------------------------------------
@@catnomta.sql '&opt'

VARIABLE catnodp_summary VARCHAR2(1024)
COLUMN   catnodp_summary format a79

DECLARE
  v_opt       VARCHAR2(10);
  v_skip_cnt  NUMBER := 0;
  v_drop_cnt  NUMBER := 0;
  v_already_drop_cnt NUMBER := 0;
  v_error_cnt NUMBER := 0;

FUNCTION final_summary
RETURN VARCHAR2
IS
BEGIN
  RETURN 'objects ' || 
         'skipped('          || v_skip_cnt         || '), ' ||
         'already dropped('  || v_already_drop_cnt || '), ' ||
         'dropped('          || v_drop_cnt         || '), ' || 
         'failed('           || v_error_cnt        || ')';
END;

----------------------------------------------------------------
--    Procedure to drop object.  Ignore "doesn't exist" errors    
----------------------------------------------------------------
PROCEDURE catnodp_drop(
  opt    IN  VARCHAR2,
  objnam IN  VARCHAR2, 
  objtyp IN  VARCHAR2,
  obs    IN  VARCHAR2 DEFAULT NULL) 
IS
  stmt       VARCHAR2(4000);
  lc_objtyp  VARCHAR2(100) := LOWER(objtyp);
  l_objown   VARCHAR2(6);
  l_objtyp   VARCHAR2(20);
  l_objnam   VARCHAR2(60);
  l_objobs   VARCHAR2(6);
  l_sp       NUMBER;      
BEGIN

  CASE UPPER(opt)
    WHEN 'TEST' THEN                    -- Return object info. Used for testing
      IF SUBSTR(objtyp, 1, 7) = 'public ' THEN
        l_objown := 'PUBLIC';
        l_objtyp := SUBSTR(objtyp, 8);
      ELSE
        l_objown := 'SYS   ';
        l_objtyp := objtyp;
      END IF;

      l_objtyp := REPLACE(l_objtyp, ' ', '_');

      l_sp := INSTR(objnam, ' ');
      if l_sp > 0 THEN
        l_objnam := SUBSTR(objnam,1,l_sp - 1);
      ELSE
        l_objnam := objnam;
      END IF;

      IF obs IS NOT NULL AND
         SUBSTR(UPPER(obs),1,3) = 'OBS' THEN
        l_objobs := 'OBS   ';
      ELSE
        l_objobs := 'ALWAYS';
      END IF; 

$IF $$RUNNING_WITHIN_TEST $THEN
      dbms_output.put_line(
        'TEST: ' || 
        RPAD(UPPER(l_objtyp),10) ||
        RPAD(UPPER(l_objnam),38) || 
        l_objown || ' ' ||
        l_objobs);
$END
      RETURN;

    WHEN 'OBSOLETE' THEN                  -- Drop obsolete and required objects
      IF (obs IS NULL) THEN                  -- If not obsolete/always, skip it
        v_skip_cnt := v_skip_cnt + 1;
        RETURN;
      END IF;

    WHEN 'ALL' THEN                     -- Drop all objects (original behavior)
      NULL;

    ELSE                                         -- Unknown options, so skip it
      v_skip_cnt := v_skip_cnt + 1;
      RETURN;
  END CASE;

  stmt := 'DROP ' || lc_objtyp || ' ' || objnam;       -- Set up drop statement
  IF (lc_objtyp = 'type') THEN
    stmt := stmt || ' FORCE';                            -- Add FORCE for TYPEs
  END IF;

  EXECUTE IMMEDIATE stmt;                                       -- Execute drop
  v_drop_cnt := v_drop_cnt + 1;

EXCEPTION
  WHEN OTHERS THEN
    -- Ignore 'object does not exist' errors
    IF SQLCODE IN (-00942, -01418, -01432, -04043) THEN
      v_already_drop_cnt := v_already_drop_cnt + 1;
    ELSE
      v_error_cnt := v_error_cnt + 1;
    END IF;
END;

PROCEDURE catnodp_drop_idx(
  opt    IN  VARCHAR2,
  objnam IN  VARCHAR2, 
  obs    IN  VARCHAR2 DEFAULT NULL)  
IS
BEGIN
  catnodp_drop(opt, objnam, 'index', obs);
END;

PROCEDURE catnodp_drop_lib(
  opt    IN  VARCHAR2,
  objnam IN  VARCHAR2, 
  obs    IN  VARCHAR2 DEFAULT NULL)  
IS
BEGIN
  catnodp_drop(opt, objnam, 'library', obs);
END;

PROCEDURE catnodp_drop_pkg(
  opt    IN  VARCHAR2,
  objnam IN  VARCHAR2, 
  obs    IN  VARCHAR2 DEFAULT NULL)  
IS
BEGIN
  catnodp_drop(opt, objnam, 'package', obs);
END;

PROCEDURE catnodp_drop_psyn(
  opt    IN  VARCHAR2,
  objnam IN  VARCHAR2, 
  obs    IN  VARCHAR2 DEFAULT NULL)  
IS
BEGIN
  catnodp_drop(opt, objnam, 'public synonym', obs);
END;

PROCEDURE catnodp_drop_type(
  opt    IN  VARCHAR2,
  objnam IN  VARCHAR2, 
  obs    IN  VARCHAR2 DEFAULT NULL)  
IS
BEGIN
  catnodp_drop(opt, objnam, 'type', obs);
END;

PROCEDURE catnodp_drop_tbl(
  opt    IN  VARCHAR2,
  objnam IN  VARCHAR2, 
  obs    IN  VARCHAR2 DEFAULT NULL)  
IS
BEGIN
  catnodp_drop(opt, objnam, 'table', obs);
END;

PROCEDURE catnodp_drop_view(
  opt    IN  VARCHAR2,
  objnam IN  VARCHAR2, 
  obs    IN  VARCHAR2 DEFAULT NULL)  
IS
BEGIN
  catnodp_drop(opt, objnam, 'view', obs);
END;

PROCEDURE catnodp_drop_tps(
  opt    IN  VARCHAR2,
  objnam IN  VARCHAR2, 
  obs    IN  VARCHAR2 DEFAULT NULL)  
IS
BEGIN
  catnodp_drop_psyn(opt, objnam, obs);
  catnodp_drop_type(opt, objnam, obs);
END;

PROCEDURE catnodp_drop_vps(
  opt    IN  VARCHAR2,
  objnam IN  VARCHAR2, 
  obs    IN  VARCHAR2 DEFAULT NULL)  
IS
BEGIN
  catnodp_drop_psyn(opt, objnam, obs);
  catnodp_drop_view(opt, objnam, obs);
END;

PROCEDURE catnodp_drop_pkgps(
  opt    IN  VARCHAR2,
  objnam IN  VARCHAR2, 
  obs    IN  VARCHAR2 DEFAULT NULL)  
IS
BEGIN
  catnodp_drop_psyn(opt, objnam, obs);
  catnodp_drop_pkg (opt, objnam, obs);
END;

BEGIN
  v_opt := '&opt';
--
-- ----------------------------------------------------------------------------
-- TYPES
-- ----------------------------------------------------------------------------
--
--...Obsolete ones
  catnodp_drop_type(v_opt, 'kupc$_encrypted_pwd',             'OBS');
  -- From dbmsplts.sql (PLUGTS)
  catnodp_drop_type(v_opt, 'tts_info_tab',                    'OBS');
  catnodp_drop_type(v_opt, 'tts_error_tab',                   'OBS');

--...Always drop (related to persistable AQ msgs)
--......With Public Synonym
  catnodp_drop_tps (v_opt, 'ku$_logentry1010',             'ALWAYS');
  catnodp_drop_tps (v_opt, 'ku$_logline1010',              'ALWAYS');
--......Without Public Synonym
  catnodp_drop_type(v_opt, 'kupc$_add_device',             'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_add_file',               'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_api_ack',                'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_bad_file',               'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_complete_imp_object',    'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_data_filter',            'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_data_remap',             'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_device_ident',           'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_disk_file',              'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_encoded_pwd',            'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_estimate_job',           'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_exit',                   'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_file_list',              'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_fileinfo',               'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_filelist',               'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_fixup_virtual_column',   'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_get_work',               'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_jobinfo',                'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_load_data',              'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_load_metadata',          'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_lobpieces',              'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_log_entry',              'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_log_error',              'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_logentries',             'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_master_key_exchange',    'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_master_msg',             'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_mastererror',            'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_masterjobinfo',          'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_message',                'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_metadata_filter',        'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_metadata_remap',         'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_metadata_transform',     'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_open',                   'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_post_mt_init',           'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_prepare_data',           'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_recomp',                 'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_release_files',          'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_restart',                'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_restore_logging',        'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_sequential_file',        'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_set_parallel',           'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_set_parameter',          'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_shadow_key_exchange',    'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_shadow_msg',             'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_sql_file_job',           'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_start_job',              'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_stop_job',               'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_stop_worker',            'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_table_data',             'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_table_data_array',       'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_table_datas',            'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_type_comp_ready',        'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_unload_data',            'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_unload_metadata',        'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_worker_exit',            'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_worker_file',            'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_worker_file_list',       'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_worker_get_pwd',         'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_worker_log_entry',       'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_worker_msg',             'ALWAYS');
  catnodp_drop_type(v_opt, 'kupc$_workererror',            'ALWAYS');
--...with Public Synonym 
  catnodp_drop_tps (v_opt, 'ku$_dumpfile1010');
  catnodp_drop_tps (v_opt, 'ku$_dumpfileset1010');
  catnodp_drop_tps (v_opt, 'ku$_jobdesc1010');
  catnodp_drop_tps (v_opt, 'ku$_jobdesc1020');
  catnodp_drop_tps (v_opt, 'ku$_jobdesc1210');
  catnodp_drop_tps (v_opt, 'ku$_jobdesc1220');
  catnodp_drop_tps (v_opt, 'ku$_jobstatus1010');
  catnodp_drop_tps (v_opt, 'ku$_jobstatus1020');
  catnodp_drop_tps (v_opt, 'ku$_jobstatus1120');
  catnodp_drop_tps (v_opt, 'ku$_jobstatus1210');
  catnodp_drop_tps (v_opt, 'ku$_jobstatus1220');
  catnodp_drop_tps (v_opt, 'ku$_paramvalue1010');
  catnodp_drop_tps (v_opt, 'ku$_paramvalues1010');
  catnodp_drop_tps (v_opt, 'ku$_status1010');
  catnodp_drop_tps (v_opt, 'ku$_status1020');
  catnodp_drop_tps (v_opt, 'ku$_status1120');
  catnodp_drop_tps (v_opt, 'ku$_status1210');
  catnodp_drop_tps (v_opt, 'ku$_status1220');
  catnodp_drop_tps (v_opt, 'ku$_workerstatus1010');
  catnodp_drop_tps (v_opt, 'ku$_workerstatus1020');
  catnodp_drop_tps (v_opt, 'ku$_workerstatus1120');
  catnodp_drop_tps (v_opt, 'ku$_workerstatus1210'); 
  catnodp_drop_tps (v_opt, 'ku$_workerstatus1220');
  catnodp_drop_tps (v_opt, 'ku$_workerstatuslist1010');
  catnodp_drop_tps (v_opt, 'ku$_workerstatuslist1020');
  catnodp_drop_tps (v_opt, 'ku$_workerstatuslist1120');
  catnodp_drop_tps (v_opt, 'ku$_workerstatuslist1210'); 
  catnodp_drop_tps (v_opt, 'ku$_workerstatuslist1220');
--...without Public Synonym 
  catnodp_drop_type(v_opt, 'ku$_dropcollist');
  catnodp_drop_type(v_opt, 'ku$_dumpfile_info');
  catnodp_drop_type(v_opt, 'ku$_dumpfile_item');
  catnodp_drop_type(v_opt, 'kupc$_mdfilepiece');
  catnodp_drop_type(v_opt, 'kupc$_mdfilepiecelist');
  catnodp_drop_type(v_opt, 'kupc$_mdreploffsets');
  catnodp_drop_type(v_opt, 'kupc$_mdreploffsetslist');
  catnodp_drop_type(v_opt, 'kupc$_mt_col_info');
  catnodp_drop_type(v_opt, 'kupc$_mt_col_info_list');
  catnodp_drop_type(v_opt, 'kupc$_mt_info');
  catnodp_drop_type(v_opt, 'kupc$_mt_info_list');
  catnodp_drop_type(v_opt, 'kupc$_par_con');

--
-- ----------------------------------------------------------------------------
-- VIEWS
-- ----------------------------------------------------------------------------
--...With public synonym
  catnodp_drop_vps(v_opt, 'cdb_datapump_jobs');
  catnodp_drop_vps(v_opt, 'cdb_datapump_sessions');
  catnodp_drop_vps(v_opt, 'dba_datapump_jobs');
  catnodp_drop_vps(v_opt, 'dba_datapump_sessions');
  catnodp_drop_vps(v_opt, 'user_datapump_jobs');
--...Without public synonym
  catnodp_drop_view(v_opt, 'gv_$datapump_job');
  catnodp_drop_view(v_opt, 'gv_$datapump_session');
  catnodp_drop_view(v_opt, 'ku$_all_tsltz_tab_cols');
  catnodp_drop_view(v_opt, 'ku$_all_tsltz_tables');
  catnodp_drop_view(v_opt, 'ku$_child_nested_tab_view');
  catnodp_drop_view(v_opt, 'ku$_object_status_view');
  catnodp_drop_view(v_opt, 'ku$_refpar_level');
  catnodp_drop_view(v_opt, 'ku$_table_exists_view');
  catnodp_drop_view(v_opt, 'ku$_user_mapping_view');
  catnodp_drop_view(v_opt, 'ku_noexp_view');
  catnodp_drop_view(v_opt, 'v_$datapump_job');
  catnodp_drop_view(v_opt, 'v_$datapump_session');
--
-- ----------------------------------------------------------------------------
-- TABLES 
-- ----------------------------------------------------------------------------
--
--...Obsolete ones
  catnodp_drop_tbl (v_opt, 'ku$_expdp_impdp_master_10_1',     'OBS');
  catnodp_drop_tbl (v_opt, 'ku$_expdp_impdp_master_11_1',     'OBS');
--...Support for VIEW-AS-TABLE
  catnodp_drop_tbl (v_opt, 'ku$_user_mapping_view_tbl');
--...Support EXCLUDE_NOEXP filter
  catnodp_drop_tbl (v_opt, 'ku_noexp_tab');
  catnodp_drop_tbl (v_opt, 'ku$noexp_tab');
--...Support very long list filters
  catnodp_drop_tbl (v_opt, 'ku$_list_filter_temp');
  catnodp_drop_tbl (v_opt, 'ku$_list_filter_temp_2');
--...Sharding related
  catnodp_drop_tbl (v_opt, 'ku$_shard_domidx_namemap');

--
-- ----------------------------------------------------------------------------
-- PUBLIC SYNONYMS
-- ----------------------------------------------------------------------------
--
--...Fixed synonyms
  catnodp_drop_psyn(v_opt, 'gv$datapump_job');
  catnodp_drop_psyn(v_opt, 'gv$datapump_session');
  catnodp_drop_psyn(v_opt, 'v$datapump_job');
  catnodp_drop_psyn(v_opt, 'v$datapump_session');
--...DBMS_DATAPUMP.GET_STATUS synonyms 
  catnodp_drop_psyn(v_opt, 'ku$_dumpfile');
  catnodp_drop_psyn(v_opt, 'ku$_dumpfile1020');
  catnodp_drop_psyn(v_opt, 'ku$_dumpfile_info');
  catnodp_drop_psyn(v_opt, 'ku$_dumpfile_item');
  catnodp_drop_psyn(v_opt, 'ku$_dumpfileset');
  catnodp_drop_psyn(v_opt, 'ku$_dumpfileset1020');
  catnodp_drop_psyn(v_opt, 'ku$_jobdesc');
  catnodp_drop_psyn(v_opt, 'ku$_jobstatus');
  catnodp_drop_psyn(v_opt, 'ku$_logentry');
  catnodp_drop_psyn(v_opt, 'ku$_logentry1020');
  catnodp_drop_psyn(v_opt, 'ku$_logline');
  catnodp_drop_psyn(v_opt, 'ku$_logline1020');
  catnodp_drop_psyn(v_opt, 'ku$_paramvalue');
  catnodp_drop_psyn(v_opt, 'ku$_paramvalue1020');
  catnodp_drop_psyn(v_opt, 'ku$_paramvalues');
  catnodp_drop_psyn(v_opt, 'ku$_paramvalues1020');
  catnodp_drop_psyn(v_opt, 'ku$_status');
  catnodp_drop_psyn(v_opt, 'ku$_workerstatus' );
  catnodp_drop_psyn(v_opt, 'ku$_workerstatuslist');
  catnodp_drop_psyn(v_opt, 'kupcc');
  catnodp_drop_psyn(v_opt, 'kuputil');
--...DataPump package and master table object type
  catnodp_drop_psyn(v_opt, 'dbms_datapump');
--
-- ----------------------------------------------------------------------------
-- FUNCTIONS
-- ----------------------------------------------------------------------------
--
  catnodp_drop     (v_opt, 'kupc$_tab_mt_cols', 'function');

--
-- ----------------------------------------------------------------------------
-- PACKAGES
-- ----------------------------------------------------------------------------
--
--...API packages
  catnodp_drop_pkg (v_opt, 'dbms_datapump');
  catnodp_drop_pkg (v_opt, 'dbms_datapump_int');
  catnodp_drop_pkg (v_opt, 'dbms_datapump_utl');
--...private internal packages
  catnodp_drop_pkg (v_opt, 'kupcc');
  catnodp_drop_pkg (v_opt, 'kupc$queue');
  catnodp_drop_pkg (v_opt, 'kupc$queue_int');
  catnodp_drop_pkg (v_opt, 'kupc$que_int');
  catnodp_drop_pkg (v_opt, 'kupf$file');
  catnodp_drop_pkg (v_opt, 'kupf$file_int');
  catnodp_drop_pkg (v_opt, 'kupm$mcp');
  catnodp_drop_pkg (v_opt, 'kupp$proc');
  catnodp_drop_pkg (v_opt, 'kupu$utilities');
  catnodp_drop_pkg (v_opt, 'kupu$utilities_int');
  catnodp_drop_pkg (v_opt, 'kupv$ft');
  catnodp_drop_pkg (v_opt, 'kupv$ft_int');
  catnodp_drop_pkg (v_opt, 'kupw$worker');
  catnodp_drop_pkg (v_opt, 'kupd$data');
  catnodp_drop_pkg (v_opt, 'kupd$data_int');
--
-- ----------------------------------------------------------------------------
-- LIBRARIES -  DataPump private libraries
-- ----------------------------------------------------------------------------
--
  catnodp_drop_lib (v_opt, 'dbms_datapump_dv_lib');
  catnodp_drop_lib (v_opt, 'kupclib');
  catnodp_drop_lib (v_opt, 'kupdlib');
  catnodp_drop_lib (v_opt, 'kupflib');
  catnodp_drop_lib (v_opt, 'kupp_proc_lib');
  catnodp_drop_lib (v_opt, 'kupulib');
  catnodp_drop_lib (v_opt, 'kupvlib');

  -- Don't print out summary line when nothing is done (when in TEST phase)
  IF (v_skip_cnt + v_drop_cnt + v_already_drop_cnt + v_error_cnt) > 0 THEN
    :catnodp_summary := final_summary;
  END IF;
END;
/

PRINT :catnodp_summary

@?/rdbms/admin/sqlsessend.sql
