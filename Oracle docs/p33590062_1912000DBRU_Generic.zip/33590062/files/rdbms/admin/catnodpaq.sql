Rem
Rem $Header: rdbms/admin/catnodpaq.sql sdavidso_blr_backport_32919937_19.12.0.0.210720dbru/1 2021/05/28 09:25:22 sdavidso Exp $
Rem
Rem catnodpaq.sql
Rem
Rem Copyright (c) 2002, 2021, Oracle and/or its affiliates.
Rem All rights reserved.
Rem
Rem    NAME
Rem     catnodpaq.sql - Drop all DataPump AQ tables
Rem
Rem    DESCRIPTION 
Rem
Rem    NOTES
Rem     This script only gets executed from downgrade and patching (dpload), 
Rem     not during upgrade as the DBMS_ADADM package is not around then.  
Rem
Rem    BEGIN SQL_FILE_METADATA
Rem     SQL_SOURCE_FILE: rdbms/admin/catnodpaq.sql
Rem     SQL_SHIPPED_FILE: rdbms/admin/catnodpaq.sql
Rem     SQL_PHASE: DOWNGRADE
Rem     SQL_STARTUP_MODE: DOWNGRADE
Rem     SQL_IGNORABLE_ERRORS: NONE
Rem     SQL_CALLING_FILE: rdbms/admin/catnodpall.sql
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED (MM/DD/YY)
Rem    apfwkr    04/02/21 - Backport
Rem                         bwright_blr_backport_32551008_19.10.0.0.210119dbru
Rem                         from st_rdbms_19.10.0.0.0dbru
Rem    bwright   03/23/21 - Backport bwright_bug-32551008 from
Rem                         st_rdbms_19.10.0.0.0dbru
Rem    bwright   02/24/21 - Bug 32551008: backport 31014419, 31207542, 32316344
Rem    bwright   07/06/17 - Created, separated from catnodp.
Rem

@@?/rdbms/admin/sqlsessstart.sql

VARIABLE catnodpaq_summary VARCHAR2(500)
COLUMN   catnodpaq_summary format a79

----------------------------------------------
---     Drop DataPump queue tables 
----------------------------------------------
DECLARE
  v_drop_cnt  NUMBER := 0;
  v_error_cnt NUMBER := 0;
  v_sqlerrm   VARCHAR2(200);
  v_qtname    VARCHAR2(128);
  CURSOR c1 IS SELECT table_name FROM dba_tables WHERE
    owner = 'SYS' AND table_name LIKE 'KUPC$DATAPUMP_QUETAB%';

  FUNCTION final_summary
  RETURN VARCHAR2
  IS
    -- 500 characters is more than enough as final message length is
    -- 18 + (13 + max of 11) + (10 + max of 11) + 14 + 200[sqlerrm] = 277
    -- 
    l_sum     VARCHAR2(500) := 'dropping AQ table';                       -- 18
  BEGIN
    IF (v_drop_cnt + v_error_cnt) != 1 THEN
      l_sum := l_sum || 's';
    END IF;

    IF (v_drop_cnt + v_error_cnt) = 0 THEN                 -- no tables dropped
      RETURN l_sum || ': NONE found';
    END IF;

    l_sum := l_sum  ||                                       -- list # suc/fail
      ': success(' || v_drop_cnt  || '),' ||      -- 13 + #digits in v_drop_cnt
       ' failure(' || v_error_cnt || ')';        -- 10 + #digits in v_error_cnt

    IF v_sqlerrm IS NOT NULL THEN                      -- display last errormsg
      l_sum := l_sum || ', last error:' || CHR(10) || v_sqlerrm;   -- 14 + errm
    END IF;
    RETURN l_sum;
  END;
BEGIN
  OPEN c1;
  LOOP
    FETCH c1 INTO v_qtname;
    EXIT WHEN c1%NOTFOUND;               -- Exit when no more queue table names

    --
    -- For every Data Pump AQ table found, try to drop it.
    --
    BEGIN
      dbms_aqadm.drop_queue_table(queue_table => 'SYS.' || v_qtname,
                                  force       => TRUE);
      v_drop_cnt := v_drop_cnt + 1;                                  -- Success
    EXCEPTION
      WHEN OTHERS THEN
        IF SQLCODE != -24002 THEN   -- Ignore QUERY_TABLE <name> does not exist
          v_error_cnt := v_error_cnt + 1;                            -- Failure
          -- Remember the last unexpected error. Make sure it fits in variable.
          v_sqlerrm := SUBSTR(SQLERRM, 1, 200);
        END IF;
    END;
  END LOOP;
  CLOSE c1;
  :catnodpaq_summary := final_summary;
END;
/

PRINT :catnodpaq_summary

@?/rdbms/admin/sqlsessend.sql
