Rem
Rem $Header: rdbms/admin/dpload.sql sdavidso_blr_backport_32919937_19.12.0.0.210720dbru/1 2021/05/28 09:25:22 sdavidso Exp $
Rem
Rem dpload.sql
Rem
Rem Copyright (c) 2013, 2021, Oracle and/or its affiliates.
Rem All rights reserved.
Rem
Rem    NAME
Rem      dpload.sql - apply script for Data Pump utility / Metadata API.
Rem
Rem    DESCRIPTION
Rem      Patch apply script for Data Pump utility / Metadata API.
Rem
Rem    NOTES
Rem      This must be executed as SYS.
Rem
Rem      Use this script to install most patches of Data Pump / Metadata
Rem      API (bug fixes that only include C-code that is included in the
Rem      oracle executable do not need to use dpload.sql).   The current 
Rem      dpload.sql in MAIN is designed to run correctly on every supported
Rem      RDBMS version from 11.2.0.4 onward.  For any patch that needs
Rem      dpload.sql, the Data Pump development team recommends including 
Rem      the lastest one from MAIN.
Rem
Rem      The dpload.sql script's main purpose is to maintain the proper 
Rem      order in which Data Pump / MDAPI files need to be applied due to
Rem      the complex interdependencies within the Data Pump / MDAPI code base.
Rem      When dpload.sql was first developed, it also tried to completely tear
Rem      down the Data Pump and MDAPI infrastructures and recreate them from 
Rem      scratch.  For patching a functioning database, this was way too heavy 
Rem      handed and expensive, usually taking at least 8-10 minutes to run and 
Rem      leaving more than 100 objects in the invalid state.  Now, this 
Rem      approach is only used for older RDBMS versions.  Beginning with 18c, 
Rem      dpload.sql takes advantage of the CREATE OR REPLACE FORCE syntax 
Rem      to replace objects instead of dropping and re-creating them.  As of
Rem      Feb-2021, with this improvement plus many others in both the
Rem      dpload.sql script and the scripts that it invokes, dpload.sql
Rem      can execute quickly and does not cause ANY object to be left in 
Rem      the invalid state.  For example, in cases where there are little/no 
Rem      changes to the existing MDAPI infrastructure, dpload.sql can run 
Rem      in as little as 40-50 seconds. If many MDAPI objects, such as views,
Rem      need to be recompiled, then the elapsed time will be longer.
Rem
Rem      This script also uses the RDBMS lock manager to prohibit this script
Rem      and Data Pump / MDAPI users from executing concurrently.  Beginning
Rem      with version 12.2.0.2, each Data Pump job and MDAPI user takes out a 
Rem      shared lock on a resource that dpload.sql tries to lock exclusively.
Rem      If a user gets the lock first, dpload.sql cannot lock it, and exits
Rem      with a "try again later" message.  If dpload.sql acquires the lock, 
Rem      any new Data Pump job or MDAPI user is unable to get the lock and
Rem      receives a similar error.  Once dpload.sql has completed the 
Rem      installation, it releases the lock, allowing new users to execute.
Rem
Rem      This dpload.sql script doesn't use any SQL SET commands, as these
Rem      can impact the execution of any scripts that follow it. Because
Rem      80 is the default length for output, some abbreviating is used.
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    apfwkr      04/02/21 - Backport
Rem                           bwright_blr_backport_32551008_19.10.0.0.210119dbru
Rem                           from st_rdbms_19.10.0.0.0dbru
Rem    bwright     03/23/21 - Backport bwright_bug-32551008 from
Rem                           st_rdbms_19.10.0.0.0dbru
Rem    bwright     03/03/21 - Bug 32551008: Include latest dpload.sql from MAIN
Rem    bwright     03/02/21 - Bug 32525862: Fix version checks after MAIN's
Rem                           db version set to 23
Rem    bwright     02/08/21 - Bug 32479451: invoke catdph or catmet2
Rem    bwright     02/05/21 - Bug 32388966: remove dbmspump.sql which contains
Rem                           all exttbl driver defs, a bigger scope than Data
Rem                           Pump/MDAPI, and exttbl users are outside our lock
Rem    bwright     01/16/21 - Bug 32195077: Move grants/inserts into
Rem                           catdpbgi.sql for dpload to invoke for patching
Rem    bwright     01/15/21 - Bug 31650569: Load prvtkupc.sql earlier
Rem    bwright     01/07/21 - Bug 32195313: Add plugts files to dpload
Rem    bwright     01/05/21 - Bug 31214625: Cleanup dpload.  Add stubbed out
Rem                           setup for bugs 31650569, 32195077, and 32195313
Rem    bwright     03/30/20 - Bug 31086613: Split msg TYPEs/BODYs from prvtkupc
Rem    bwright     01/30/20 - Bug 29284656: remove delim dependencies in dur()
Rem    bwright     07/09/18 - Bug 28314747: Fix check_for_types_patch
Rem    surman      05/22/18 - 27464252: Update SQL_PHASE
Rem    sdavidso    03/23/18 - bug-27746488 handle backport of bug 25225293
Rem    sdavidso    08/29/17 - improve perf tracking
Rem    sdipirro    07/17/17 - Fix unsupported reference when used for backports
Rem                           to earlier than 12.1 release
Rem    bwright     06/21/17 - Bug 25651930: Add OBSOLETE, ALL script options
Rem    sdipirro    02/15/17 - Attempt to merge dpload and dpload2 back into a
Rem                           single file
Rem    sdipirro    01/10/17 - Project 68204 - Synchronized software update
Rem    rapayne     06/30/16 - Bug 23640417: in upgrade mode dropping 
Rem                           ku$noexp_tab results in an error. Add error to 
Rem                           ignorable metadata until better solution is found
Rem    rapayne     03/28/16 - Bug 22879025: correctly handle modules which 
Rem                           dont exist is older versions.
Rem    dvekaria    02/12/16 - Bug 22607194: Fix ORA-01775 and PLS-00201 errors.
Rem    sdipirro    11/19/15 - Add prvthdpi and prvtbdpi
Rem    sogugupt    11/26/15 - Bug 22245383: Add metadata SQL_IGNORABLE_ERRORS
Rem    mjangir     11/19/15 - bug 22222697: Move prvth*.plb utilities package
Rem                           header before prvtmet*.plb
Rem    tbhukya     09/02/15 - Bug 21776925: Use "@@" for file run
Rem    dgagne      08/13/15 - Fix loading of prvtdputh.plb
Rem    dgagne      08/11/15 - backout approot txn
Rem    rapayne     07/15/15 - Fix loading of prvtdputh.plb
Rem    tbhukya     06/12/15 - Bug 21137821: Run files directly instead of a
Rem                           script with relative paths.
Rem    rapayne     04/19/15 - lrg 15977957: remove connect string from the
Rem                           generated loadutl script.
Rem    rapayne     03/15/15 - bug 20680092: disable spooling
Rem    tmontgom    10/31/14 - Move prvtkupc.plb the Utilities package header
Rem                           (depends on types in prvtkupc.plb), mimic order
Rem                           of catproc.sql
Rem    surman      10/16/14 - Update phase
Rem    rapayne     05/14/14 - make changes to accommodate readonly admin dirs.
Rem                           Bug 17039620.
Rem    rapayne     09/17/13 - update sql_file_metadata tags as per sqlpatch team
Rem                           request.
Rem    rapayne     07/10/13 - Created
Rem
Rem    BEGIN SQL_FILE_METADATA
Rem    SQL_SOURCE_FILE: rdbms/admin/dpload.sql
Rem    SQL_SHIPPED_FILE: rdbms/admin/dpload.sql
Rem    SQL_PHASE: DPLOAD
Rem    SQL_STARTUP_MODE: NORMAL
Rem    SQL_IGNORABLE_ERRORS: ORA-04043, ORA-00942, ORA-01921, ORA-00955, ORA-14452
Rem    SQL_CALLING_FILE: NONE
Rem    END SQL_FILE_METADATA

--
-- Need these uncommented when setting to TRUE v_dbg_invobjs in ku$_dpload 
-- packag body.  Otherwise,  the list of invalid objects gets truncated to 
-- 80 characters.
--
-- SET LONG 90000000
-- SET PAGESIZE 50000

--
-- Workaround for problem with DBMS_SESION.RESET_PACKAGE that was
-- added to catmetinsert.sql as a bug fix.
--
VARIABLE saved_variables CLOB

--
-- Needed for conditional execution of scripts that is determined by
-- querying the 'prepare' function.  The 'new_val' clause is 
-- effectively the same as the INTO clause of a PLSQL query, the 
-- column's value is stored in the specified SQL variable where it 
-- can be used later to invoke the appropriate script file returned 
-- from the query.  The 'noprint' qualifier keeps the query from 
-- displaying its results.  This eliminates the confusing, multiline 
-- FNAME header from getting displayed.
--
COLUMN fname NEW_VAL file_name noprint

--
-- This is used in the 'finish' query to return the results of
-- the execution of the current script file.  Specify the header
-- here that gets displayed the result of that query.
--
COLUMN fsummary HEADING DPLOAD_FILE_EXECUTION_SUMMARY      FORMAT A79
COLUMN psummary HEADING DPLOAD_PROCEDURE_EXECUTION_SUMMARY FORMAT A79

--
-- ===========================================================
-- KU$_DPLOCK: Local package for SW update locking
-- ===========================================================
--
CREATE OR REPLACE PACKAGE ku$_dplock AS
  FUNCTION get_db_version
    RETURN VARCHAR2;

  FUNCTION start_sw_update(
    timeout IN NUMBER DEFAULT 0) 
    RETURN VARCHAR2;

  PROCEDURE end_sw_update(
    swlock_handle IN VARCHAR2);
END ku$_dplock;
/
--
-- ===========================================================
-- KU$_DPLOCK's package body
-- ===========================================================
--
CREATE OR REPLACE PACKAGE BODY ku$_dplock AS
  v_db_version VARCHAR2(10);

  -- --------------------------------------------------------------------------
  -- GET_DB_VERSION: Get the database version that dpload is being run against.
  -- 
  -- Implicit:
  --   Sets v_db_version if not already set using query below.
  --
  -- Returns:
  ---  Database version as a string
  --
  FUNCTION get_db_version
  RETURN VARCHAR2 
  IS
  BEGIN
    IF v_db_version IS NULL THEN
      BEGIN
        SELECT substr(dbms_registry.version('CATPROC'), 1, 10)
          INTO v_db_version
          FROM sys.dual;
      EXCEPTION
        WHEN OTHERS THEN
          raise_application_error(-20000,                     -- Raise an error
            'Unable to get database version, SQLCODE: ' || SQLCODE);
      END;
    END IF;
    RETURN v_db_version;
  END;

  -- --------------------------------------------------------------------------
  -- START_SW_UPDATE: Starts the software update by acquiring necessary lock
  -- 
  -- Parameters:
  --   timeout - how long to wait for a lock before it times out
  --
  -- Returns:
  --   The lock handle as a string, or NULL if lock was not acquired.
  --
  FUNCTION start_sw_update(
    timeout IN NUMBER DEFAULT 0) 
  RETURN VARCHAR2 
  IS
    db_version VARCHAR2(10) := get_db_version;
    swlock_ret NUMBER;  
    swlock_handle VARCHAR2(128);
  BEGIN
    --
    -- dpload locking started with 12.2.0.2.  Ignore for earlier versions.
    --
    IF db_version < '12.2.0.2' THEN
      RETURN NULL;
    END IF;

    --
    -- How lock is allocated is version specific.
    --
    $IF DBMS_DB_VERSION.Version < 12
    $THEN
      dbms_lock.allocate_unique('ORA$KU$DATAPUMP_SW_UPDATE',
                                swlock_handle);
    $ELSE
      dbms_lock.allocate_unique_autonomous('ORA$KU$DATAPUMP_SW_UPDATE',
                                           swlock_handle);
    $END

    --
    -- Attempt to acquire the lock
    --
    swlock_ret := dbms_lock.request (swlock_handle, dbms_lock.x_mode, timeout);
    IF NOT (swlock_ret = 0 OR swlock_ret = 4) THEN
      RETURN NULL;
    END IF;

    RETURN swlock_handle;

  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;

  -- --------------------------------------------------------------------------
  -- END_SW_UPDATE: Complete the software update by releasing  necessary lock.
  --   Ignore any errors (don't expect any).
  -- 
  -- Parameters:
  --   swlock_handle - the handle of the lock to release.
  --
  PROCEDURE end_sw_update(
    swlock_handle IN VARCHAR2)
  IS
    swlock_ret NUMBER;
  BEGIN
    IF swlock_handle IS NOT NULL THEN
      swlock_ret := dbms_lock.release (SUBSTR(swlock_handle, 1, 128));
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;

END ku$_dplock;
/ 
show errors

--
-- ===========================================================
-- KU$_DPLOAD: Local package for dpload execution
-- ===========================================================
--
CREATE OR REPLACE PACKAGE ku$_dpload AS
  PROCEDURE initial_phase;
  PROCEDURE final_phase;

  PROCEDURE save_vars(outvars OUT CLOB);
  PROCEDURE reset_vars(invars IN CLOB);

  FUNCTION prepare (
    filename    IN VARCHAR2,
    initial_ver IN VARCHAR2 DEFAULT NULL,
    before_ver  IN VARCHAR2 DEFAULT NULL,
    new_types   IN VARCHAR2 DEFAULT NULL,
    prvtkupc_split IN VARCHAR2 DEFAULT NULL,
    catdpb_split IN VARCHAR2 DEFAULT NULL)
    RETURN VARCHAR2;

  FUNCTION finish
    RETURN CLOB;

END ku$_dpload;
/
--
-- =============================
-- KU$_DPLOAD's package body
-- =============================
--
CREATE OR REPLACE PACKAGE BODY ku$_dpload AS
-- package local store
  C_FILE_DOES_NOT_EXIST    CONSTANT NUMBER        := 0;
  C_FILE_EXISTS            CONSTANT NUMBER        := 1;
  C_FILE_EXISTS_AS_SYMLINK CONSTANT NUMBER        := 2;
  C_NL                     CONSTANT CHAR          := CHR(10);       -- new line
  C_PFX                    CONSTANT VARCHAR2(6)   := '>>> ';
  C_NOOP_SCRIPT            CONSTANT VARCHAR2(128) := 
    dbms_registry.nothing_script;                  -- ?/rdbms/admin/nothing.sql
  C_INVOBJ_STMT            CONSTANT VARCHAR2(100) := 
    'select name, type# from sys.obj$ where status > 1 order by name asc';
  C_VALOBJ_STMT            CONSTANT VARCHAR2(100) := 
    'select 1 from sys.obj$ where name=:1 and type#=:2 and status = 1';

  C_FLAGS_SWLOCK_ERROR     CONSTANT NUMBER := 1;
  C_FLAGS_HAS_TYPES_PATCH  CONSTANT NUMBER := 2;     -- MDAPI types patch found
  C_FLAGS_PRVTKUPC_SPLIT   CONSTANT NUMBER := 4;
  C_FLAGS_CATDPB_SPLIT     CONSTANT NUMBER := 8;
  C_FLAGS_SAVE_INVOBJS     CONSTANT NUMBER := 16;

  --
  -- Manual debug options: Set to TRUE to...
  --
  v_dbg_reason   CONSTANT BOOLEAN := FALSE;       -- Display more 'reason' info
  v_dbg_invobjs  CONSTANT BOOLEAN := FALSE; -- Display invalid objects per file

  --
  -- Variables that need to be reset.  Variables in this list have to also be
  -- included in routines SAVE_VARS and RESET_VARS.
  -- 
  v_filename         VARCHAR2(100) := NULL;
  v_flags            NUMBER := 0;            
  v_init_h           NUMBER;
  v_init_hms         NUMBER;
  v_prev_invobjs     CLOB;
  v_prev_invobjs_cnt NUMBER := 0;
  v_prev_invobjs_len NUMBER := 0;
  v_reason           CLOB;
  v_save_h           NUMBER;
  v_save_hms         NUMBER;
  v_save_invobjs     CLOB;
  v_save_invobjs_cnt NUMBER := 0;
  v_save_invobjs_len NUMBER := 0;
 
  --
  -- Variables that don't have to be reset.
  --
  v_admin_dir        VARCHAR2(128);
  v_finish_str       CLOB;             -- Output gets written here and returned
  v_finish_sfx       VARCHAR(2000);       -- Optional; tack on at end of output
  v_swlock_handle    VARCHAR2(128) := NULL;     -- Locking began after versions
                                                -- needing save/reset_vars

  TYPE cursor_t IS REF CURSOR;
  --
  -- Map object type# to object type, for the ones we are interested in.
  --
  TYPE typename_tbl IS TABLE OF VARCHAR2(60) INDEX BY BINARY_INTEGER;
  type2name typename_tbl;

  -- -----------------------------------------
  -- INTERNAL KU$_DPLOAD FUNCTIONS/PROCEDURES
  -- -----------------------------------------

  -- --------------------------------------------------------------------------
  -- INITTIME: Initialize the beginning time to the current time
  --   
  -- Implicit:
  --   Sets global v_init_h and v_init_hms variables.
  --
  PROCEDURE inittime
  IS
    init_t TIMESTAMP := CAST(SYSTIMESTAMP AS DATE);
  BEGIN
    v_init_h   := EXTRACT (HOUR   FROM init_t);
    v_init_hms := v_init_h*60*60 +
                  EXTRACT (MINUTE FROM init_t)*60 +
                  EXTRACT (SECOND FROM init_t);
  END;

  -- --------------------------------------------------------------------------
  -- SAVE_INITTIME: Save the initial time for later use (for elapsed time of
  --   whole script).
  -- 
  -- Implicit:
  --   Sets v_save_h and v_save_hms variables.
  --
  PROCEDURE save_inittime
  IS
  BEGIN
    v_save_h   := v_init_h;
    v_save_hms := v_init_hms;
  END;

  --
  -- --------------------------------------------------------------------------
  -- ELAPSEDTTIME: Calculate the elapsed time of a single operation.  There is
  --   an inherent maximum of 24 hours for this elapsed time.  If this ever is 
  --   exceeded, there is something way more seriously wrong with dpload 
  --   execution as no operation should take more than a few minutes.
  --
  -- Notes:
  --   This operation's ending time becomes the starting time for the next one.
  -- 
  -- Implicit:
  --   Resets v_init_h and v_init_hms
  --
  -- Returns: 
  --   The elapsed time as a string: "<number of seconds> second[s]" 
  --
  FUNCTION elapsedtime
  RETURN VARCHAR2 
  IS
    delta_secs NUMBER;
    end_t      TIMESTAMP := CAST(SYSTIMESTAMP AS DATE);
    end_h      NUMBER := EXTRACT (HOUR   FROM end_t);
    end_hms    NUMBER := end_h*60*60 +
                         EXTRACT (MINUTE FROM end_t)*60 +
                         EXTRACT (SECOND FROM end_t);
  BEGIN
    --
    -- If clock turned over to the next day during this event
    -- (starting hour is greater than the ending hour), then 
    -- add 24 hours to the end so calculation feels like it is
    -- for the same day. For example, start time was 11pm (23hrs)
    -- and end date was 2am (2hrs), the elapsed time for hours is 
    -- (24+2) - 23 = 3hrs.
    --
    IF (v_init_h > end_h) THEN
      delta_secs := (end_hms + 24*60*60) - v_init_hms;
    ELSE
      delta_secs := end_hms - v_init_hms;
    END IF;

    --
    -- Use ending time as the starting time for next event
    --
    v_init_hms := end_hms;
    v_init_h := end_h;

    IF delta_secs = 1 THEN
      RETURN to_char(delta_secs) || ' sec';
    END IF;

    RETURN to_char(delta_secs) || ' secs';
  END;

  -- --------------------------------------------------------------------------
  -- INIT_TYPE2NAME:  Initialize the type#-to-name table.
  --
  PROCEDURE init_type2name
  IS
  BEGIN
    --
    -- Initialize the mapping of  object type# to object type (for the ones we 
    -- are interested in).  Need to do it this way for versions < 18c as initializing
    -- the table as part of its declaration using 0 => 'CURSOR', 1 => 'INDEX',..
    -- syntax started in 18c.
    --
    type2name( 0) := 'CURSOR';
    type2name( 1) := 'INDEX';
    type2name( 2) := 'TABLE';
    type2name( 3) := 'CLUSTER';
    type2name( 4) := 'VIEW';
    type2name( 5) := 'SYNONYM';
    type2name( 6) := 'SEQUENCE';
    type2name( 7) := 'PROCEDURE';
    type2name( 8) := 'FUNCTION';
    type2name( 9) := 'PACKAGE';
    type2name(10) := '10';
    type2name(11) := 'PACKAGE BODY';
    type2name(12) := 'TRIGGER';
    type2name(13) := 'TYPE';
    type2name(14) := 'TYPE BODY';
    type2name(15) := 'OBJECT';
    type2name(16) := 'USER';
    type2name(17) := 'LINK';
    type2name(18) := 'PIPE'; 
    type2name(19) := 'TABLE PART';
    type2name(20) := 'INDEX PART';
    type2name(21) := 'LOB';
    type2name(22) := 'LIBRARY';
    type2name(23) := 'DIRECTORY';
    type2name(24) := 'QUEUE';
  END;

  -- --------------------------------------------------------------------------
  -- CREATE_ADMIN_DIR: Create admin directory object so file existence checking 
  --   can be done using it.
  -- 
  -- Implicit:
  --   Sets v_admin_dir; Sets v_reason.
  --
  PROCEDURE create_admin_dir
  AS
    db_platform    VARCHAR2(1000);
    dirobj_created BOOLEAN := FALSE;
    homeDir        VARCHAR2(1000);
    stmt           VARCHAR2(1000);
    admin_dir_str  VARCHAR2(128) := 'KU$_DPLOAD_ADMIN_DIR';
  BEGIN
    --
    -- Nothing to do if already set up.
    --
    IF v_admin_dir IS NOT NULL THEN
      RETURN;
    END IF;

    -- 
    -- Create a directory object for rdbms/admin so we can look for
    -- a file there.  Use ORACLE_HOME as the base of the path.
    --
    DBMS_SYSTEM.GET_ENV('ORACLE_HOME', homeDir);
    stmt := 'create or replace directory ' || 
            admin_dir_str || ' as '''|| homeDir;
    
    --
    -- Rest of directory path is platform dependent.
    --
    EXECUTE IMMEDIATE 'SELECT UPPER(platform_name) FROM v$database'
    INTO db_platform;
    IF INSTR(db_platform, 'WINDOWS') = 0  THEN
      stmt := stmt || '/rdbms/admin''';
    ELSE
      stmt := stmt || '\rdbms\admin''';
    END IF;
 
    IF v_dbg_reason THEN
      v_reason := v_reason || C_NL || C_PFX || 'create_admin_dir: ';
      -- Only if really need it.
      -- dbg: v_reason := v_reason || '(stmt: ' || C_NL || stmt || ') ';
    END IF; 
 
    --
    -- Create the directory object
    --
    EXECUTE IMMEDIATE stmt;
    v_admin_dir := admin_dir_str;

    IF v_dbg_reason THEN
      v_reason := v_reason || 'succeeded ';
    END IF;
    RETURN;

  EXCEPTION
    WHEN OTHERS THEN
      RETURN;
  END;

 -- --------------------------------------------------------------------------
  -- DROP_ADMIN_DIR: Drop the admin directory object, if it exists
  -- 
  -- Implicit:
  --   Resets v_admin_dir; Set's v_reason.
  --
  PROCEDURE drop_admin_dir
  AS
  BEGIN
    IF v_admin_dir IS NULL THEN 
      RETURN;
    END IF;

    EXECUTE IMMEDIATE 'drop directory ' || v_admin_dir;

    IF v_dbg_reason THEN
      v_reason := v_reason || C_NL || C_PFX || 'drop_admin_dir: succeeded ';
    END IF;

    v_admin_dir := NULL;
  END;

  -- --------------------------------------------------------------------------
  -- RELEASE_SWLOCK:  Release the dpload software update lock. 
  --
  -- Implicit:
  --   Uses and sets v_swlock_handle, C_FLAGS_SWLOCK_ERROR bit and v_reason.
  --
  PROCEDURE release_swlock
  AS
    db_version VARCHAR2(10) := ku$_dplock.get_db_version;
  BEGIN
    IF db_version >= '12.2.0.2' THEN
      IF v_swlock_handle IS NOT NULL THEN
        v_flags := v_flags - BITAND(v_flags, C_FLAGS_SWLOCK_ERROR);
        ku$_dplock.end_sw_update(v_swlock_handle);
      END IF;
    END IF;
    RETURN;
  END release_swlock;

  -- --------------------------------------------------------------------------
  -- FILE_EXISTS: Does the file exist in the given directory object?  This
  --   handles symlink files but only within an internal ADE environment.
  --
  -- Implicit:
  --   Relies on v_admin_dir being set.  Uses v_dbg_reason to 
  --   update v_reason.
  --
  -- Returns:
  --   C_FILE_DOES_NOT_EXIST    - if file doesn't exist
  --   C_FILE_EXISTS            - if file exists
  --   C_FILE_EXISTS_AS_SYMLINK - if file is a symlink file in ADE environment  
  --
  FUNCTION file_exists(
    filename VARCHAR2)
  RETURN NUMBER
  AS
    ade_view       VARCHAR2(1000);
    err_stack      VARCHAR2(4000);
    fbsize         NUMBER;
    fexists        BOOLEAN := FALSE;
    flen           NUMBER;
    loc            BFILE;
  BEGIN
    --
    -- Need a directory object to look for a file.
    --
    IF v_admin_dir IS NULL THEN
      RETURN C_FILE_DOES_NOT_EXIST;
    END IF;

    --
    -- Now see if file exists.  NOTE: This API doesn't work for symlink files.
    -- Not a concern normally, only in an ADE environment.  Handle below.
    --
    UTL_FILE.FGETATTR(v_admin_dir, filename, fexists, flen, fbsize);
    IF fexists THEN
      IF v_dbg_reason THEN
        v_reason := v_reason || '(fgetattr - exists) ';
      END IF;
      RETURN C_FILE_EXISTS;
    END IF;

    --
    -- File doesn't exist or could be a symlink file.  If not in an ADE 
    -- environment, then don't worry about symlinks.
    -- 
    DBMS_SYSTEM.GET_ENV('ADE_VIEW_NAME', ade_view);
    IF ade_view IS NULL THEN
      IF v_dbg_reason THEN
        v_reason := v_reason || '(fgetattr - does not exist) ';
      END IF;
      RETURN C_FILE_DOES_NOT_EXIST;
    END IF;

    --
    -- OK, in an ADE environment.  The DBMS_LOB.FILEEXISTS API supports 
    -- symlinks, so try that. 
    --
    loc := BFILENAME(v_admin_dir, filename);
    IF DBMS_LOB.FILEEXISTS(loc) = 1 THEN
      IF v_dbg_reason THEN
        v_reason := v_reason || '(dbms_lob - symlink exists) ';
      END IF;
      RETURN C_FILE_EXISTS_AS_SYMLINK;
    END IF;

    --
    -- File doesn't exist in ADE environment.
    --
    IF v_dbg_reason THEN
      v_reason := v_reason || '(does not exist) ';
    END IF;
    RETURN C_FILE_DOES_NOT_EXIST;

  EXCEPTION
    WHEN OTHERS THEN                 -- Handle and display any unexpected error
      err_stack := DBMS_UTILITY.FORMAT_ERROR_STACK();
      IF v_dbg_reason THEN
        v_reason := v_reason || ' (file exists exception:' || C_NL || 
          SUBSTR(err_stack, 1, 400) || ') ';
      END IF;
      RETURN C_FILE_DOES_NOT_EXIST;
  END;

  -- --------------------------------------------------------------------------
  -- DBG_OBJ_NAME: Concatenate object's name and its object type in parentheses
  --
  -- Notes:
  --   Only used if debugging invalid objects is set
  --
  -- Returns: 
  --   string <object name> (<object type>)
  --
  FUNCTION dbg_obj_name(obj IN VARCHAR2)
  RETURN VARCHAR2
  AS
    cur_plus      NUMBER;
    typeN         NUMBER;
    type1         VARCHAR2(500);
    name1         VARCHAR2(500);
  BEGIN
    cur_plus := INSTR(obj, '+', 1, 1);
    type1 := SUBSTR(obj, cur_plus + 1);
    typeN := TO_NUMBER(type1);
    name1 := SUBSTR(obj, 1, (cur_plus - 1));
 
    IF typeN > 24 THEN
      RETURN name1 || ' (' || type1 || ')';
    ELSE
      RETURN name1 || ' (' || type2name(typeN) || ')';
    END IF;
  END; 

  -- --------------------------------------------------------------------------
  -- DBG_INVOBJS: Generate list of changes to the invalid objects.  For every 
  --   new invalid object, it is prefaced with '> ' and every object that is 
  --   no longer invalid, it is prefaced with '< ', like the output from the 
  --   diff tool.  A 'delta count', the difference in the number of invalid 
  --   objects before and after the operation.
  --
  PROCEDURE dbg_invobjs
  AS
    cur_invobjs  CLOB;
    cur_invobjs_cnt NUMBER  := 0;
    cur_invobjs_len NUMBER;
    cur_plus     NUMBER;
    cur_semi     NUMBER;
    i            NUMBER;
    invobj1      VARCHAR2(200);
    invobj1delim VARCHAR2(202);
    invobjhdrflg BOOLEAN := FALSE;
    name1        VARCHAR2(200);
    pos          NUMBER;
    prev_semi    NUMBER;
    type1        VARCHAR2(200);
    c1           cursor_t;

  BEGIN
    --
    --  Build string of invalid objects in form of semicolon delimited list of
    --  '<objname>+<objtype>' with leading and trailing semicolons
    --
    cur_invobjs := ';';
    OPEN c1 FOR C_INVOBJ_STMT;
    LOOP
      FETCH c1 INTO name1, type1;

      EXIT WHEN c1%NOTFOUND;

      cur_invobjs := cur_invobjs || name1 || '+' || type1 || ';';
      cur_invobjs_cnt := cur_invobjs_cnt + 1;
      
    END LOOP;
    CLOSE c1;

    IF cur_invobjs_cnt > 0 THEN
      cur_invobjs_len := LENGTH(cur_invobjs);
    ELSE
      cur_invobjs := '';
      cur_invobjs_len := 0;
    END IF;

    --
    -- Determine new invalid objects
    --
    IF cur_invobjs_len > 0 THEN
      prev_semi := INSTR(cur_invobjs, ';', 1, 1);
      i := 2;  
      LOOP
        cur_semi  := INSTR(cur_invobjs, ';', 1, i);     -- next delimiter
        EXIT WHEN cur_semi = 0;

        --
        -- Get one invalid object name at a time
        --
        invobj1 := 
          SUBSTR(cur_invobjs, prev_semi + 1, (cur_semi - prev_semi) - 1);

        cur_plus := INSTR(invobj1, '+', 1, 1);
        EXIT WHEN cur_plus = 0;

        --
        -- Advance our delimiter
        --
        prev_semi := cur_semi;

        --
        -- Add delimiters around invalid object name
        --
        invobj1delim := ';' || invobj1 || ';';

        --
        -- Search previous invalid objects list.  If not
        -- found, then this is a new one.  Output it.
        --
        IF v_prev_invobjs_len > 0 THEN     
          pos := INSTR(v_prev_invobjs, invobj1delim, 1, 1);
        ELSE
          pos := 0;
        END IF;
 
        IF pos = 0 THEN
          IF NOT invobjhdrflg THEN
            v_finish_str := v_finish_str || C_NL || C_PFX ||
              'delta invalid objs (' || 
              (cur_invobjs_cnt - v_prev_invobjs_cnt) || '):';
            invobjhdrflg := TRUE;
          END IF;
          v_finish_str := v_finish_str || C_NL || 
            '> ' || dbg_obj_name(invobj1);
        END IF;
        --
        -- Get next invalid object
        --
        i := i + 1;
      END LOOP;
    END IF;

    --
    -- Determine which objects are no longer invalid
    --
    IF v_prev_invobjs_len > 0 THEN
      prev_semi := INSTR(v_prev_invobjs, ';', 1, 1);
      i := 2;  
      LOOP
        cur_semi  := INSTR(v_prev_invobjs, ';', 1, i);        -- next delimiter
        EXIT WHEN cur_semi = 0;

        --
        -- Get one invalid object name at a time
        --
        invobj1 := 
          SUBSTR(v_prev_invobjs, prev_semi + 1, (cur_semi - prev_semi) - 1);

        --
        -- Advance our delimiter
        --
        prev_semi := cur_semi;

        --
        -- Add delimiters around invalid object name
        --
        invobj1delim := ';' || invobj1 || ';';

        --
        -- Search current list of invalid objects.  If not
        -- found, re-query to see if it is now valid.  If so,
        -- Output it.  Make sure to include object's type, too.
        --
        IF cur_invobjs_len > 0 THEN
          pos := INSTR(cur_invobjs, invobj1delim, 1, 1);  
        ELSE
          pos := 0;
        END IF;
  
        IF pos = 0 THEN
          cur_plus := INSTR(invobj1, '+', 1, 1);
          type1 := SUBSTR(invobj1, cur_plus + 1);
          name1 := SUBSTR(invobj1, 1, cur_plus - 1);

          BEGIN
            EXECUTE IMMEDIATE C_VALOBJ_STMT 
            INTO pos USING name1, type1;

            IF pos = 1 THEN
              IF NOT invobjhdrflg THEN
                v_finish_str := v_finish_str || C_NL || C_PFX ||
                  'delta invalid objs (' || 
                  (cur_invobjs_cnt - v_prev_invobjs_cnt) || '):';
                invobjhdrflg := TRUE;
              END IF;
              v_finish_str := v_finish_str || C_NL || 
                '< ' || dbg_obj_name(invobj1);
            END IF;
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
        END IF;
        --
        -- Get next invalid object
        --
        i := i + 1;
      END LOOP;
    END IF;
    --
    -- Remember list as previous list.
    -- 
    v_prev_invobjs := cur_invobjs;
    v_prev_invobjs_cnt := cur_invobjs_cnt;
    v_prev_invobjs_len := cur_invobjs_len;

    --
    -- If this is the first time through then save these, too,
    -- so we can reset the list back to what it was when we started.
    --
    IF BITAND(v_flags, C_FLAGS_SAVE_INVOBJS) = 0  THEN
      v_save_invobjs := cur_invobjs;
      v_save_invobjs_cnt := cur_invobjs_cnt;
      v_save_invobjs_len := cur_invobjs_len;
      v_flags := v_flags + C_FLAGS_SAVE_INVOBJS;
    END IF;

    IF invobjhdrflg THEN
      v_finish_str := v_finish_str || C_NL || '[end invalid objects]';
    END IF;
  END;


  -- --------------------------------------------------------------------------
  -- CHECK_FOR_TYPES_PATCH: Check to see if patch of MDAPI's move-of-TYPE 
  --   definitions out of dbmsmeta.sql into catmettypes.sql has been applied
  --    or not.
  --
  -- Implicit:
  --   Relies on v_admin_dir being set.
  --   Updates v_reason.  
  --   Sets C_FLAGS_HAS_TYPES_PATCH v_flags vit.
  --
  PROCEDURE check_for_types_patch
  IS
    db_version   VARCHAR2(10) := ku$_dplock.get_db_version;
    err_stack    VARCHAR2(4000);
    exists_val   NUMBER := C_FILE_DOES_NOT_EXIST;
    fileh        UTL_FILE.FILE_TYPE;
    line         VARCHAR2(1000);
  BEGIN
    v_reason := v_reason || 'types patch:'; 

    --
    -- Don't bother checking for MDAPI types-moved patch if db version
    -- contains the move.
    --
    IF db_version >= '12.2.0.2' THEN
      v_reason := v_reason || 'na';
      RETURN; 
    END IF;

    exists_val := file_exists('dbmsmeta.sql');

    --
    -- Cannot parse if file does not exist; always display reason.
    --
    IF exists_val = C_FILE_DOES_NOT_EXIST THEN
      v_reason := v_reason || 'N';
      RETURN;
    END IF;

    --
    -- Cannot parse if file is a symlink within an ADE environment;
    -- Always display reason.
    --
    IF exists_val = C_FILE_EXISTS_AS_SYMLINK THEN
      v_reason := v_reason || 'N';
      RETURN;
    END IF;

    --
    -- File exists that we can open and parse.  
    --
    fileh := UTL_FILE.FOPEN(v_admin_dir, 'dbmsmeta.sql', 'r');
    LOOP
      UTL_FILE.GET_LINE(fileh, line);
      --
      -- Stop as soon as we see a CREATE TYPE.  This indicates that
      -- the patch that moves the type definitions to catmettypes.sql
      -- does not exist here.
      --
      IF INSTR(line,'CREATE TYPE') != 0 THEN 
        EXIT; 
      END IF;

      --
      -- Stop parsing when we reach the beginning of the package spec.  If
      -- reached here, no type definitions were seen before it, indicating
      -- the patch has been applied.  Set the global flag to indicate this.
      -- Always display reason.
      --
      IF INSTR(line,'CREATE OR REPLACE PACKAGE dbms_metadata') != 0 THEN
        v_reason := v_reason || 'Y';
        v_flags := v_flags - BITAND(v_flags, C_FLAGS_HAS_TYPES_PATCH) + 
          C_FLAGS_HAS_TYPES_PATCH;
        EXIT;
      END IF;
    END LOOP;
    UTL_FILE.FCLOSE(fileh);

    IF BITAND(v_flags, C_FLAGS_HAS_TYPES_PATCH) = 0  THEN
      v_reason := v_reason || 'N';
    END IF;

  EXCEPTION
    WHEN OTHERS THEN                 -- Handle and display any unexpected error
      err_stack := DBMS_UTILITY.FORMAT_ERROR_STACK();

      IF UTL_FILE.IS_OPEN(fileh) THEN
        UTL_FILE.FCLOSE(fileh);
      END IF;

      v_reason := v_reason || 
        'parsing exception:' || C_NL || SUBSTR(err_stack, 1, 400) || ' ';
  END;


  -- --------------------------------------------------------------------------
  -- CHECK_FOR_PRVTKUPC_SPLIT:  Check to see if the patch that splits 
  --   prvtkupc into three files has been applied or not.
  --
  -- Implicit:
  --   Relies on v_admin_dir being set.
  --   Updates v_reason.  
  --   Sets C_FLAGS_PRVTKUPC_SPLIT bit.
  --
  PROCEDURE check_for_prvtkupc_split
  IS
    db_version   VARCHAR2(10) := ku$_dplock.get_db_version;
  BEGIN
    v_reason := v_reason || 'prvtkupc split:';

    --
    -- Don't bother checking for split of prvtkupc if version already has it.
    --
    IF db_version >= '21.0.0.0' THEN
      v_reason := v_reason || 'na';
      RETURN; 
    END IF;

    --
    -- Look for prvtkupc_typespec.plb.  If it doesn't exist, then patch that
    -- splits up prvtkupc.sql is not present.  Otherwise, it is.  Always
    -- display answer as the reason.
    --
    IF file_exists('prvtkupc_typespec.plb') = C_FILE_DOES_NOT_EXIST THEN
      v_reason := v_reason || 'N';
      RETURN;
    END IF;

    v_reason := v_reason || 'Y';

    --
    -- Set global flag; used by prepare
    --
    v_flags := v_flags - BITAND(v_flags, C_FLAGS_PRVTKUPC_SPLIT) +
      C_FLAGS_PRVTKUPC_SPLIT;
            
    RETURN;
  END;


  -- --------------------------------------------------------------------------
  -- CHECK_FOR_CATDPB_SPLIT:  Check to see if the patch that splits 
  --   catdbp.sql into two files has been applied or not.
  --
  -- Implicit:
  --   Relies on v_admin_dir being set.
  --   Updates v_reason.  
  --   Sets C_FLAGS_CATDPB_SPLIT bit.
  --
  PROCEDURE check_for_catdpb_split
  IS
    db_version   VARCHAR2(10) := ku$_dplock.get_db_version;
  BEGIN
    v_reason := v_reason || 'catdpb split:';

    --
    -- Don't bother checking for split of catdpb if version already has it.
    --
    IF db_version >= '23.0.0.0' THEN
      v_reason := v_reason || 'na';
      RETURN; 
    END IF;

    --
    -- Look for the new file, split off from catdbp.sql.  If it doesn't exist, 
    -- then patch that splits up catdpb.sql is not present.  Otherwise, it is.
    -- Always display answer as the reason.
    --
    IF file_exists('catdpbgi.sql') = C_FILE_DOES_NOT_EXIST THEN
      v_reason := v_reason || 'N';
      RETURN;
    END IF;

    v_reason := v_reason || 'Y';

    --
    -- Set global flag; used by prepare
    --
    v_flags := v_flags - BITAND(v_flags, C_FLAGS_CATDPB_SPLIT) +
      C_FLAGS_CATDPB_SPLIT;
            
    RETURN;
  END;

  -- ---------------------------------------
  -- PUBLIC KU$_DPLOAD FUNCTIONS/PROCEDURES
  -- ---------------------------------------

  -- --------------------------------------------------------------------------
  -- SAVE_VARS: Save critical ku$_dpload package variable values as an overly
  --   heavy bug fix in 2012 that added a DBMS_SESSION.RESET_PACKAGE call to
  --   catmetinsert.sql.  That call wipes out  all package body storage in use
  --   by that session, including dpload's package body.  So save the critical
  --   variables by passing them out to dpload and then passing them in to 
  --   reset_vars after catmetinsert has been run.
  --
  -- Parameters:
  --   outvars        - Caret ('^') delimited list of variables sent to dpload
  --
  PROCEDURE save_vars(outvars OUT CLOB)
  IS
    db_version VARCHAR2(10) := ku$_dplock.get_db_version;
  BEGIN
    --
    -- Now normal version checking.  Return immediately if db version
    -- falls outside the acceptible version boundaries.
    --
    IF (db_version < '12.1.0.1') OR (db_version >= '12.2.0.2') THEN
      IF v_dbg_reason THEN
        v_reason := v_reason || ' (save/reset vars not needed) ';
      END IF;
      outvars := NULL;
      RETURN;
    END IF;
 
    --
    -- Set up the output parameter with all the variables that need to be 
    -- reset.  This order must be consistent with the order in RESET_VARS.
    --    
    outvars :=
      v_filename         || '^' ||
      v_flags            || '^' ||
      v_init_h           || '^' ||
      v_init_hms         || '^' ||
      v_prev_invobjs     || '^' ||
      v_prev_invobjs_cnt || '^' ||
      v_prev_invobjs_len || '^' ||
      v_reason           || '^' ||
      v_save_h           || '^' ||
      v_save_hms         || '^' ||
      v_save_invobjs     || '^' ||
      v_save_invobjs_cnt || '^' ||
      v_save_invobjs_len || '^';
  END;

  -- --------------------------------------------------------------------------
  -- RESET_VARS: Reset the critical variables to values passed in.
  --
  -- Parameters:
  --   invars         - Caret ('^') delimited list of variables from dpload
  --
  PROCEDURE reset_vars(invars IN CLOB)
  IS
    pos  NUMBER;
    ppos NUMBER;
  BEGIN
    --
    -- Return immediately if nothing is passed in.
    --
    IF (invars IS NULL) OR (LENGTH(invars) = 0) THEN
      RETURN;
    END IF;
 
    --
    -- Set up the output parameter with all the variables that need to be 
    -- reset. This order must be consistent with the order in SAVE_VARS.
    -- Only reset if there is a value for it between the previous caret and
    -- the current one.
    -- 
    ppos := 1;
    pos := INSTR(invars, '^', ppos, 1);
    IF (pos > ppos) THEN
      v_filename := SUBSTR(invars, ppos, (pos - ppos));
    ELSE
      v_filename := NULL;
    END IF;
    ppos := pos + 1;

    pos := INSTR(invars, '^', ppos, 1);
    IF (pos > ppos) THEN
      v_flags := TO_NUMBER(SUBSTR(invars, ppos, (pos - ppos)));
    ELSE
      v_flags := 0;
    END IF;
    ppos := pos + 1;

    pos := INSTR(invars, '^', ppos, 1);
    IF (pos > ppos) THEN
      v_init_h := TO_NUMBER(SUBSTR(invars, ppos, (pos - ppos)));
    ELSE
      v_init_h := 0;
    END IF;
    ppos := pos + 1;

    pos := INSTR(invars, '^', ppos, 1);
    IF (pos > ppos) THEN
      v_init_hms := TO_NUMBER(SUBSTR(invars, ppos, (pos - ppos)));
    ELSE
      v_init_hms := 0;
    END IF;
    ppos := pos + 1;

    pos := INSTR(invars, '^', ppos, 1);
    IF (pos > ppos) THEN
      v_prev_invobjs := SUBSTR(invars, ppos, (pos - ppos));
    ELSE
      v_prev_invobjs := NULL;
    END IF;
    ppos := pos + 1;

    pos := INSTR(invars, '^', ppos, 1);
    IF (pos > ppos) THEN
      v_prev_invobjs_cnt := TO_NUMBER(SUBSTR(invars, ppos, (pos - ppos)));
    ELSE
      v_prev_invobjs_cnt := 0;
    END IF;
    ppos := pos + 1;

    pos := INSTR(invars, '^', ppos, 1);
    IF (pos > ppos) THEN
      v_prev_invobjs_len := TO_NUMBER(SUBSTR(invars, ppos, (pos - ppos)));
    ELSE
      v_prev_invobjs_len := 0;
    END IF;
    ppos := pos + 1;

    pos := INSTR(invars, '^', ppos, 1);
    IF (pos > ppos) THEN
      v_reason := SUBSTR(invars, ppos, (pos - ppos));
    ELSE
      v_reason := NULL;
    END IF;
    ppos := pos + 1;

    pos := INSTR(invars, '^', ppos, 1);
    IF (pos > ppos) THEN
      v_save_h := TO_NUMBER(SUBSTR(invars, ppos, (pos - ppos)));
    ELSE
      v_save_h := 0;
    END IF;
    ppos := pos + 1;

    pos := INSTR(invars, '^', ppos, 1);
    IF (pos > ppos) THEN
      v_save_hms := TO_NUMBER(SUBSTR(invars, ppos, (pos - ppos)));
    ELSE
      v_save_hms := 0;
    END IF;
    ppos := pos + 1;

    pos := INSTR(invars, '^', ppos, 1);
    IF (pos > ppos) THEN
      v_save_invobjs := SUBSTR(invars, ppos, (pos - ppos));
    ELSE
      v_save_invobjs := NULL;
    END IF;
    ppos := pos + 1;

    pos := INSTR(invars, '^', ppos, 1);
    IF (pos > ppos) THEN
      v_save_invobjs_cnt := TO_NUMBER(SUBSTR(invars, ppos, (pos - ppos)));
    ELSE
      v_save_invobjs_cnt := 0;
    END IF;
    ppos := pos + 1;

    pos := INSTR(invars, '^', ppos, 1);
    IF (pos > ppos) THEN
      v_save_invobjs_len := TO_NUMBER(SUBSTR(invars, ppos, (pos - ppos)));
    ELSE
      v_save_invobjs_len := 0;
    END IF;

    --
    --  Also have to reinitialize the type-to-name table.
    --
    init_type2name;

    IF v_dbg_reason THEN
      v_reason := v_reason || ' (save/reset vars done) ';
    END IF;
  END;

  -- --------------------------------------------------------------------------
  -- INITIAL_PHASE: Initial operation of dpload.
  --   
  PROCEDURE initial_phase
  IS
    db_version VARCHAR2(10) := ku$_dplock.get_db_version;
  BEGIN
    --
    --  If do not have the dplock (this started with 12.2.0.2), try to get it.
    --
    IF (db_version >= '12.2.0.2') AND v_swlock_handle IS NULL THEN             
      --   
      -- Attempt to get the lock.  Hold onto the lock handle until it
      -- get released at the end of dpload.
      --
      v_swlock_handle := ku$_dplock.start_sw_update(0);  -- Don't wait for lock
      IF v_swlock_handle IS NULL THEN                          -- Didn't get it
        v_flags := v_flags - BITAND(v_flags, C_FLAGS_SWLOCK_ERROR) +
          C_FLAGS_SWLOCK_ERROR;                       -- Remember we didn't get
        raise_application_error(-20000,                       -- Raise an error
          'Data Pump or Metadata API in use - ' ||
          'Please execute rdbms/admin/dpload.sql script at a later time');
      END IF;
    END IF;

    inittime;
    save_inittime;
    create_admin_dir;
    --
    -- Get output of all checks to fit within 50 or so characters so this
    -- plug the setup completion string will fit in default size of 80
    -- characters.
    --
    v_reason := v_reason || ' ';
    check_for_types_patch;
    v_reason := v_reason || ', ';
    check_for_catdpb_split;
    v_reason := v_reason || ', ';
    check_for_prvtkupc_split;
   
    drop_admin_dir;
    init_type2name;
  END;

  -- --------------------------------------------------------------------------
  -- FINAL_PHASE: Last opeation of dpload.
  --   
  PROCEDURE final_phase
  IS
  BEGIN
    drop_admin_dir;                         -- just in case not already dropped
    --
    -- Reset time and invalid object list to what they were at the
    -- start, so final phase can report the delta since the start.
    --
    v_init_h   := v_save_h;
    v_init_hms := v_save_hms;
    v_prev_invobjs := v_save_invobjs;
    v_prev_invobjs_cnt := v_save_invobjs_cnt;
    v_prev_invobjs_len := v_save_invobjs_len;

    release_swlock;
  END;

  -- --------------------------------------------------------------------------
  -- FINISH: With absense of DBMS_OUTPUT.PUT_LINE support, This is used to
  --   produce whatever output is wanted after an operation/file has been
  --   executed.
  --
  FUNCTION finish
  RETURN CLOB
  AS
  BEGIN
    --
    -- Build up the finish string, starting from scratch.
    -- 
    v_finish_str := '';

    IF v_filename IS NULL THEN                 -- Not much to do if no filename
      v_finish_str := v_finish_str || C_PFX || 'unknown file';
      inittime;
      RETURN v_finish_str;
    END IF;

    --
    -- Display the current filename/procedure's completion line
    -- NOTE: In calculating the elapsed time, the inittime
    -- for the next file is set to the ending time of this one.
    -- 
    v_finish_str := v_finish_str || C_PFX ||
      v_filename || ' done (' || elapsedtime || ')';

    --
    -- Reasons can be during prepare's decision making to document those 
    -- decisions.  If set, then output it now.
    -- 
    IF v_reason IS NOT NULL THEN
      v_finish_str := v_finish_str || v_reason;
      v_reason := NULL;
    END IF;

    --
    -- If invalid objects is requested, then include those in the output.
    --
    IF v_dbg_invobjs THEN
      dbg_invobjs;
    END IF;
  
    --
    -- If there is a finish suffix, add it to the very end.
    --
    IF v_finish_sfx IS NOT NULL THEN
      v_finish_str := v_finish_str || v_finish_sfx;
      v_finish_sfx := NULL;
    END IF;

    --
    -- Reset for the next operation.
    --
    v_filename := NULL;

    --
    -- Return what was generated. This will get displayed as the output.
    -- 
    RETURN v_finish_str;
  END;

  -- --------------------------------------------------------------------------
  -- PREPARE: This is the major entry point for each source file.  It 
  --   determines if this file should be invoked based on its input parameters.
  --   This is what allows for 'conditionalized' execution of our source files.
  --
  -- Parameters:
  --   filename       - The file (or procedure) being considered to execute
  --   initial_ver    - Run this file if the current db version is greater
  --                    than or equal to this version (or is null) AND
  --   before_ver     - Run this file if the current db version is 'before
  --                    this version', NOT 'up-to-and-including this version'
  --                    or this is null
  --   new_types      - Handles the conditional ordering of when the MDAPI's
  --                    catmettypes.sql file should be run (it has two 
  --                    entries in dpload), depending on whether a patch that
  --                    moved some type definitions out of dbmsmeta.sql into
  --                    catmettypes.sql has been applied or not. This is only
  --                    considered when db version is less than a non-null
  --                    initial_ver.
  --   prvtkupc_split - Handles the conditional ordering of when and if
  --                    the three files from the splitting up of prvtkupc.sql
  --                    should be executed. This depends on whether a patch
  --                    that split up prvtkupc.sql has been applied or not. 
  --                    This is only considered when the db version is less
  --                    than a non-null initial_ver.
  --   catdpb_split   - Handles the conditional ordering of when and if
  --                    the files from the splitting up of catdpb.sql
  --                    should be executed. This depends on whether a patch
  --                    that split up catdpb.sql has been applied or not. 
  --                    This is only considered when the db version is less
  --                    than a non-null initial_ver.
  --
  -- Notes:
  --   The current datbase version retrieve from 
  --   dbms_registry.version('CATPROC') may not have minor versions set.
  --   So make sure to use the correct version format on the initial_ver
  --   and before_ver parameters.   Empirically,  the following have been 
  --   seen,   version      dbms_registry.version('CATPROC')
  --           -------      --------------------------------
  --           11.2.0.4.0   11.2.0.4.0
  --           12.1.0.2.0   12.1.0.2.0
  --           12.2.0.1.0   12.2.0.1.0
  --           18.x.x.0.0   18.0.0.0.0   <===
  --           19.x.x.0.0   19.0.0.0.0   <===
  --           21.x.x.0.0   21.0.0.0.0   <===
  --
  -- Implicit:
  --   Sets v_filename (used by finish), and uses a lot of the v_* global
  --   variables.  Update v_reason
  --
  -- Returns:
  --   the filename if the file is to be executed, or
  --   "/rdbms/admin/nothing.sql" if the file is not to be executed.
  -- 
  FUNCTION prepare (
    filename    IN VARCHAR2,
    initial_ver IN VARCHAR2 DEFAULT NULL,
    before_ver  IN VARCHAR2 DEFAULT NULL,
    new_types   IN VARCHAR2 DEFAULT NULL,
    prvtkupc_split IN VARCHAR2 DEFAULT NULL,
    catdpb_split IN VARCHAR2 DEFAULT NULL)
  RETURN VARCHAR2
  AS
    db_version  VARCHAR2(10) := ku$_dplock.get_db_version;
  BEGIN
    --
    --  Can't proceed if needed the software lock and didn't get it.
    -- 
    IF BITAND(v_flags, C_FLAGS_SWLOCK_ERROR) > 0 THEN 
      v_reason := v_reason || ' skipped (Data Pump/MDAPI in use) ';
      RETURN C_NOOP_SCRIPT; 
    END IF;

    --
    -- Setup for finish output later. 
    -- 
    v_filename := filename;
    v_finish_str := NULL;
    v_reason := NULL;

    -- 
    -- Special case checking when database version is less than the file's
    -- initial version.  We are checking to see if several patches have
    -- been applied here that would require the file to be applied.
    --
    IF initial_ver IS NOT NULL and db_version < initial_ver THEN 
      -- 
      -- CASE 1:  MDAPI's TYPE-definitions-moved-into-different-source file 
      -- patch.  This is only for catmettypes.sql (only file that passes in 
      -- the new_types parameter) to determine which of its two invocations
      -- to execute and which to skip.  If patch has been applied then execute
      -- it now as indicated by the 'RUN' option.
      --
      IF new_types = 'RUN' THEN 
        --
        -- If patch has been applied, then apply the file now.  Tack on the 
        -- reason here to the filename so it gets displayed as we are going
        -- to invoke it (v_reason is for reasons for not invoking it).
        --
        IF BITAND(v_flags, C_FLAGS_HAS_TYPES_PATCH) > 0 THEN
          v_reason := v_reason || ' run (type patch present) ';
          RETURN filename;
        END IF;

        --
        -- No patch, so skip it for now.  Second invocation should load it.
        --
        v_reason := v_reason || ' skipped (type patch missing) ';
        RETURN C_NOOP_SCRIPT;
      END IF;

      --
      -- CASE 2: Check to see if the splitting of the prvtkupc module has
      -- been backported to a version earlier than it first appeared.  If so, 
      -- if we want to execute it, then do so.  If not, don't execute it even
      -- if split is present.
      --
      IF prvtkupc_split IS NOT NULL THEN
        IF UPPER(prvtkupc_split) = 'YES' THEN
          IF BITAND(v_flags, C_FLAGS_PRVTKUPC_SPLIT) > 0 THEN
            v_reason := v_reason || ' run (prvtkupc is split)';
            RETURN filename;
          END IF;
        
          v_reason := v_reason || ' skipped (prvtkupc is unsplit) ';
          RETURN C_NOOP_SCRIPT;
        END IF;
      END IF;

      --
      -- CASE 3: Check to see if the splitting of the catdpb module has
      -- been backported to a version earlier than it first appeared.  If so, 
      -- if we want to execute it, then do so.  If not, don't execute it even
      -- if split is present.
      --
      IF catdpb_split IS NOT NULL THEN
        IF UPPER(catdpb_split) = 'YES' THEN
          IF BITAND(v_flags, C_FLAGS_CATDPB_SPLIT) > 0 THEN
            v_reason := v_reason || ' run (catdpb is split)';
            RETURN filename;
          END IF;
        
          v_reason := v_reason || ' skipped (catdpb is unsplit) ';
          RETURN C_NOOP_SCRIPT;
        END IF;
      END IF;

    END IF;                                             -- End of special cases

    --
    -- Now normal version checking.  Only apply this file if it falls within 
    -- the acceptible version boundaries.  
    --
    IF (initial_ver IS NULL OR db_version >= initial_ver) AND
       (before_ver IS NULL OR db_version < before_ver) THEN
      --
      -- If prvkupc_split has been backported, then you don't want to be 
      -- running the original 'full' prvtkupc which still has its entry in 
      -- dpload, but that entry is marked with 'prvtkupc_split => 'NO', 
      -- meaning don't execute this if the prvtkupc_split has been detected.
      --
      IF prvtkupc_split IS NOT NULL AND UPPER(prvtkupc_split) = 'NO' AND 
         BITAND(v_flags, C_FLAGS_PRVTKUPC_SPLIT) > 0  THEN
        v_reason := v_reason || ' skipped (prvtkupc is split) ';
        RETURN C_NOOP_SCRIPT;
      END IF;

      --
      -- If catdpb_split has been backported, then you don't want to be running
      -- the original 'full' catdbp which still has its entry in dpload, but
      -- that entry is marked with 'catdpb_split => 'NO', meaning don't execute
      -- this if the catdpb_split has been detected.
      --
      IF catdpb_split IS NOT NULL AND UPPER(catdpb_split) = 'NO' AND 
         BITAND(v_flags, C_FLAGS_CATDPB_SPLIT) > 0  THEN
        v_reason := v_reason || ' skipped (catdpb is split) ';
        RETURN C_NOOP_SCRIPT;
      END IF;

      RETURN filename;
    END IF;
    
    v_reason := v_reason || ' skipped (outside version limits) ';
    RETURN C_NOOP_SCRIPT;
  END prepare;

END ku$_dpload;
/ 
show errors
--
-- ============================================================================
-- BEGINNING OF APPLY EXECUTION
-- ============================================================================
--
-- Initial phase sets up internal infrastructure for rest of dpload.
--
SELECT ku$_dpload.prepare('setup') AS fname FROM sys.dual;
EXECUTE ku$_dpload.initial_phase;
SELECT ku$_dpload.finish AS psummary FROM sys.dual;

--------------------------------------------------
--     Start by dropping Data Pump's AQ tables
--------------------------------------------------
SELECT ku$_dpload.prepare('catnodpaq.sql',
                          initial_ver => '12.2.0.2') AS fname FROM sys.dual;

@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

--------------------------------------------------
--     Dropping Data Pump and Metadata objects
--------------------------------------------------
-- Starting with 18c, don't drop any objects. Rely on the new
-- CREATE OR REPLACE FORCE syntax instead.
SELECT ku$_dpload.prepare('catnodpobs.sql', 
                          initial_ver => '12.2.0.2',
                          before_ver =>  '18.0.0.0') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;


SELECT ku$_dpload.prepare('catnodp.sql', 
                          before_ver => '12.2.0.2') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

--------------------------------------------------
--     Common stuff 
--------------------------------------------------
 
-- Run catdpb up until it was split up in v23. But don't run 
-- it if the split has been detected as being backported to an 
-- earlier version; run the split file instead (next).
SELECT ku$_dpload.prepare('catdpb.sql',
                          before_ver =>   '23.0.0.0',
                          catdpb_split => 'NO') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

-- Bug 32195077: Run catdpbgi starting with v23, or if it is detected in an 
-- earlier release meaning the split has been backported.
SELECT ku$_dpload.prepare('catdpbgi.sql',
                          initial_ver =>  '23.0.0.0',
                          catdpb_split => 'YES') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

-- Metadata Types - executed here for versions >= 12.2, or with types backport
SELECT ku$_dpload.prepare('catmettypes.sql',
                          initial_ver => '12.2.0.2',
                          new_types => 'RUN') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

--
-- Bug 31650569: load the post-split prvtkupc here so any of our package 
-- specs/bodies can use its common elements.  In keeping with catproc 
-- ordering, place this here.  This started with version 23 and is not
-- expected to be backported.
--
SELECT ku$_dpload.prepare('prvtkupc.plb',
                          initial_ver => '23.0.0.0') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

--------------------------------------------------
--     Public interfaces 
--------------------------------------------------
--
-- DBMS_PLUGTS (bug 32195313)
--
SELECT ku$_dpload.prepare('dbmsplts.sql') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

--
-- Metadata package definitions
--
SELECT ku$_dpload.prepare('dbmsmeta.sql') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

SELECT ku$_dpload.prepare('dbmsmetb.sql') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

SELECT ku$_dpload.prepare('dbmsmetd.sql') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

SELECT ku$_dpload.prepare('dbmsmeti.sql') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

SELECT ku$_dpload.prepare('dbmsmetu.sql') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

SELECT ku$_dpload.prepare('dbmsmet2.sql') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

SELECT ku$_dpload.prepare('utlcxml.sql') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- Other package definitions
--
SELECT ku$_dpload.prepare('dbmsxml.sql') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

SELECT ku$_dpload.prepare('dbmsdp.sql') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

--------------------------------------------------
--     Private interfaces
--------------------------------------------------
SELECT ku$_dpload.prepare('prvthpp.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

SELECT ku$_dpload.prepare('prvthpd.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

SELECT ku$_dpload.prepare('prvthpdi.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

SELECT ku$_dpload.prepare('prvthpvi.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

SELECT ku$_dpload.prepare('prvthpv.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

-- It has dependencies on types in dbmsdp.sql.
SELECT ku$_dpload.prepare('prvtkupc_typespec.plb',
                          initial_ver => '21.0.0.0',
                          prvtkupc_split => 'YES') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

-- Note: prvtkupc can be invoked in two places.   Above, it will be if
-- db version >= 23.0. Invoke it here for earlier versions.  This could
-- be the "lightweight" file if prvtkupc has been split up,  or the original
-- "heavyweight" one, pre-split.  In both cases, invoke it here.
-- It has dependencies in dbmsdp.sql.

SELECT ku$_dpload.prepare('prvtkupc.plb',
                          before_ver => '23.0.0.0') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

-- It has dependencies on types in kupcc in prvtkupc.sql.
SELECT ku$_dpload.prepare('prvtkupc_typebody.plb',
                          initial_ver => '21.0.0.0',
                          prvtkupc_split => 'YES') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

SELECT ku$_dpload.prepare('prvthpu.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

SELECT ku$_dpload.prepare('prvthpui.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

--
-- DBMS_DATAPUMP_UTL package body
--
SELECT ku$_dpload.prepare('prvthdpi.plb',
                          initial_ver => '12.2.0.0') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

--
-- Metadata Types (> v12.0 but prior to 12.2.0.2, without types backport)
--
SELECT ku$_dpload.prepare('catmettypes.sql',
                          initial_ver => '12.1.0.1',
                          before_ver => '12.2.0.2',
                          new_types => 'SKIP') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- Metadata Views
--
SELECT ku$_dpload.prepare('catmetviews.sql',
                          initial_ver => '12.1.0.1') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- Metadata Grants 1
--
SELECT ku$_dpload.prepare('catmetgrant1.sql',
                          initial_ver => '12.1.0.1') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- Metadata Grants 2
--
SELECT ku$_dpload.prepare('catmetgrant2.sql',
                          initial_ver => '12.1.0.1') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

--
-- Inserts on metadata dictionary tables.  Due to a bug introduced in 12.1.0.1
-- which was fixed in 12.2.0.2, we have to work at maintaining dpload's context
-- stored in its package body variables.  Save these before invoking 
-- catmetinsert and restore after it, so dpload can continue correctly.
--
SELECT ku$_dpload.prepare('catmetinsert.sql',
                          initial_ver => '12.1.0.1') AS fname FROM sys.dual;
EXECUTE ku$_dpload.save_vars(:saved_variables);
@@&file_name
EXECUTE ku$_dpload.reset_vars(:saved_variables);
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- Metadata Types, Views, Grants and Inserts (prior to in 12.1.0.1)
--
SELECT ku$_dpload.prepare('catmeta.sql', 
                          before_ver => '12.1.0.1') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

--
-- Privite package headers
--
SELECT ku$_dpload.prepare('prvthpc.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

SELECT ku$_dpload.prepare('prvthpci.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

SELECT ku$_dpload.prepare('prvthpw.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

SELECT ku$_dpload.prepare('prvthpm.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

SELECT ku$_dpload.prepare('prvthpfi.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

SELECT ku$_dpload.prepare('prvthpf.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

--
-- DBMS_METADATA_INT package body: Dependent on prvtpbui
--
SELECT ku$_dpload.prepare('prvtmeti.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- DBMS_METADATA_UTIL package body: dependent on prvthpdi
--
SELECT ku$_dpload.prepare('prvtmetu.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- DBMS_METADATA_BUILD package body
--
SELECT ku$_dpload.prepare('prvtmetb.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- DBMS_METADATA_DPBUILD package body
--
SELECT ku$_dpload.prepare('prvtmetd.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- DBMS_METADATA_DIFF package body
--
SELECT ku$_dpload.prepare('prvtmet2.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- UTL_XML: PL/SQL wrapper around CORE LPX facility: C-based XML/XSL parsing
--
SELECT ku$_dpload.prepare('prvtcxml.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

SELECT ku$_dpload.prepare('prvtbpu.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

SELECT ku$_dpload.prepare('prvtbpui.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- DBMS_DATAPUMP public package body
--
SELECT ku$_dpload.prepare('prvtdp.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- DBMS_DATAPUMP_UTL package body (note: pkg def was split out in 12.1)
--
SELECT ku$_dpload.prepare('prvtdputh.plb',
                          initial_ver => '12.1.0.1') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

SELECT ku$_dpload.prepare('prvtdput.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- DBMS_DATAPUMP_INT definers private package body
--
SELECT ku$_dpload.prepare('prvtbdpi.plb',
                          initial_ver => '12.2.0.0') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- KUPC$QUEUE invokers private package body
--
SELECT ku$_dpload.prepare('prvtbpc.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- KUPC$QUEUE_INT definers private package body
--
SELECT ku$_dpload.prepare('prvtbpci.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- KUPW$WORKER private package body
--
SELECT ku$_dpload.prepare('prvtbpw.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- KUPM$MCP private package body: Dependent on prvtbpui
--
SELECT ku$_dpload.prepare('prvtbpm.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- DBMS_METADATA package body: Dependent on dbmsxml.sql
--
SELECT ku$_dpload.prepare('prvtmeta.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- KUPF$FILE_INT private package body
--
SELECT ku$_dpload.prepare('prvtbpfi.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- KUPF$FILE private package body
--
SELECT ku$_dpload.prepare('prvtbpf.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- KUPP$PROC private package body
--
SELECT ku$_dpload.prepare('prvtbpp.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- KUPD$DATA invokers private package body
--
SELECT ku$_dpload.prepare('prvtbpd.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- KUPD$DATA_INT private package body
--
SELECT ku$_dpload.prepare('prvtbpdi.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- KUPV$FT private package body
--
SELECT ku$_dpload.prepare('prvtbpv.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- KUPV$FT_INT private package body
--
SELECT ku$_dpload.prepare('prvtbpvi.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- DBMS_PLUGTS package body (bug 32195313)
-- 
SELECT ku$_dpload.prepare('prvtplts.plb') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- Create temporary tables, default dirobj, and load catmet2.sql
--
SELECT ku$_dpload.prepare('catdph.sql',
                          before_ver => '18.0.0.0') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;
--
-- To cut down on contention issues for statically created objects in
-- catdph, only invoke catmet2.sql now, which is called by catdph.
-- NOTE: catdph still needs to maintain the catmet2 call, as it is 
-- needed when invoked during db catalog creation.
--
SELECT ku$_dpload.prepare('catmet2.sql',
                          initial_ver => '18.0.0.0') AS fname FROM sys.dual;
@@&file_name
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

--
-- Finish up, including displaying the elapsed time of the entire script
--
SELECT ku$_dpload.prepare('entire dpload') AS fname FROM sys.dual;
EXECUTE ku$_dpload.final_phase;
SELECT ku$_dpload.finish AS fsummary FROM sys.dual;

--
-- Cleanup
--
DROP PACKAGE ku$_dpload;
DROP PACKAGE ku$_dplock;

