Rem
Rem $Header: rdbms/admin/catmet2.sql sdavidso_blr_backport_32919937_19.12.0.0.210720dbru/2 2021/05/28 09:25:20 sdavidso Exp $
Rem
Rem catmet2.sql
Rem
Rem Copyright (c) 2004, 2021, Oracle and/or its affiliates.
Rem All rights reserved.
Rem
Rem    NAME
Rem      catmet2.sql - Creates heterogeneous types for Data Pump's mdapi
Rem
Rem    DESCRIPTION
Rem      Creates heterogeneous type definitions for
Rem        TABLE_EXPORT
Rem        SCHEMA_EXPORT
Rem        DATABASE_EXPORT
Rem        TRANSPORTABLE_EXPORT
Rem      Also loads xsl stylesheets
Rem      All this must be delayed until the packages have been built.
Rem
Rem    NOTES
Rem
Rem
Rem BEGIN SQL_FILE_METADATA
Rem SQL_SOURCE_FILE: rdbms/admin/catmet2.sql
Rem SQL_SHIPPED_FILE: rdbms/admin/catmet2.sql
Rem SQL_PHASE: CATMET2
Rem SQL_STARTUP_MODE: NORMAL
Rem SQL_IGNORABLE_ERRORS: NONE
Rem SQL_CALLING_FILE: rdbms/admin/catdph.sql
Rem END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    sdavidso    05/27/21 - Backport sdavidso_bug-32919937 from main
Rem    apfwkr      04/02/21 - Backport
Rem                           bwright_blr_backport_32551008_19.10.0.0.210119dbru
Rem                           from st_rdbms_19.10.0.0.0dbru
Rem    bwright     03/23/21 - Backport bwright_bug-32551008 from
Rem                           st_rdbms_19.10.0.0.0dbru
Rem    bwright     03/01/21 - Bug 32551008: backport 32195274, remove catmetx
Rem                           from being invoked in catmet2
Rem    apfwkr      08/14/19 - Backport
Rem                           apfwkr_blr_backport_29989845_19.3.0.0.190416dbru
Rem                           from st_rdbms_19.3.0.0.0dbru
Rem    apfwkr      07/31/19 - Backport sdavidso_bug-29989845 from main
Rem    sdavidso    07/01/19 - bug 29989845 check for XBD being VALID or UPGRADED
Rem    surman      01/23/14 - 13922626: Update SQL metadata
Rem    mjangir     09/21/12 - bug 14658090: run catmetx to enable diffing code
Rem    lbarton     06/22/04 - Bug 3695154: obsolete initmeta.sql 
Rem    lbarton     04/27/04 - lbarton_bug-3334702
Rem    lbarton     01/28/04 - Created
Rem

@@?/rdbms/admin/sqlsessstart.sql

VARIABLE v_summary VARCHAR2(300);
COLUMN   v_summary HEADING "CATMET2 COMPLETING MDAPI LOAD" FORMAT a79
--
-- Build the heterogeneous object types for standalone DB or CDB$ROOT.
-- Skip if running in a PDB.  
--
-- As a departure from earlier behavior where DMLs executed by hetero
-- object creation were never commited or rolled back, we will now
-- explicitly rollback with on any exception and commit if no errors. 
-- Previously, we implicitly assumed success in any customer release.
--
DECLARE 
  l_con_id  NUMBER := 0;
BEGIN
  -- 'CON_ID' is a new attribute of SYS_CONTEXT starting with 12.1.0.2.
  -- This code assumes running in 12.1 or later.
  -- con_id is 0 for standalone DB, 1 for CDB$ROOT, >1 for any PDB
  l_con_id := SYS_CONTEXT('USERENV','CON_ID');
  IF l_con_id > 1 THEN
    :v_summary := 'heterogeneous object creation skipped, running in PDB';
  ELSE
    -- turn off 'debug' in DBMS_METADATA_BUILD. This only matters if the
    -- source for DBMS_METADATA_BUILD is modified to set DO_DEBUG to TRUE.
    -- That is unlikely to ship, but confusing during development/debug as
    -- dmls on table are not executed with debug set. Why? Tradition!
    DBMS_METADATA_BUILD.SET_DEBUG(FALSE);
    -- Now, actually build the heterogeneous object types
    dbms_metadata_dpbuild.create_table_export;
    dbms_metadata_dpbuild.create_schema_export;
    dbms_metadata_dpbuild.create_database_export;
    dbms_metadata_dpbuild.create_transportable_export;
    COMMIT;
    :v_summary := 'heterogeneous object creation completed';
  END IF;
  EXCEPTION
    WHEN OTHERS THEN
      :v_summary := 'heterogeneous object create failed';
      ROLLBACK;
      RAISE;
END;
/
PRINT :v_summary
--
-- Load XSL stylesheets
--
exec SYS.DBMS_METADATA_UTIL.LOAD_STYLESHEETS;
--@?/catmetloadxsl.sql

@?/rdbms/admin/sqlsessend.sql
