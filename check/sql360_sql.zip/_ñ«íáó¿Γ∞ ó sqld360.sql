--Database restarts


--Top segments in SYSAUX
select * from 
(
select seg.tablespace_name, SEG.OWNER,SEG.SEGMENT_NAME, seg.PARTITION_NAME, SEG.SEGMENT_TYPE, lob.TABLE_NAME||'.'||lob.COLUMN_NAME "LOB column", BYTES/1024/1024 "Size, Mb" 
from dba_segments seg
left join DBA_LOBS lob on SEG.SEGMENT_NAME= lob.SEGMENT_NAME
where seg.tablespace_name='SYSAUX' 
order by bytes desc)
where rownum<101;


--List of tables which were decorated with dbms_stats.set_table_prefs custom stats gathering preference
select o.owner "Owner", o.object_name "Table name",p.pname "Prefernece",p.valchar "Value",p.chgtime "Change time" from SYS.OPTSTAT_USER_PREFS$ p  join dba_objects o on o.object_id=p.obj#
where o.owner not in ('SYSTEM','SYS')
order by owner,object_name,pname;


--Fixed objects stats - last collection
select trunc(last_analyzed), count(*) FROM dba_tab_statistics 
where object_type = 'FIXED TABLE' 
group by trunc(last_analyzed)
order by trunc(last_analyzed) nulls first;


select * from v$flash_recovery_area_usage;


---Largest indexes never used according to index usage tracking
--Works in 12.2 and above
select i.owner, i.index_name, i.table_name, (select RTRIM ( xmlagg (xmlelement (c, COLUMN_NAME || ',') order by column_position).extract ('//text()'), ',' ) from dba_ind_columns ic where ic.index_owner=i.owner and ic.index_name=i.index_name) "Indexed columns"
,u.last_used, s.bytes/1024/1024 "MB", i.tablespace_name, u.*
from dba_indexes i left join dba_index_usage u on i.index_name=u.name and i.owner=u.owner
left join dba_segments s on s.owner=i.owner and s.segment_name=i.index_name
where i.owner NOT IN ('SYSTEM','SYS') 
order by u.last_used nulls first, s.bytes desc nulls last;


--Missing stats
SELECT DECODE(OBJECT_TYPE,'PARTITION','TABLE PARTITION','SUBPARTITION','TABLE SUBPARTITION',OBJECT_TYPE) OBJECT_TYPE, owner, table_name object_name, PARTITION_NAME, SUBPARTITION_NAME, last_analyzed, stattype_locked, stale_stats,GLOBAL_STATS,USER_STATS
FROM dba_tab_statistics
WHERE (last_analyzed IS NULL OR stale_stats = 'YES') and stattype_locked IS NULL
and 
owner NOT IN ('ANONYMOUS', 'CTXSYS', 'DBSNMP', 'EXFSYS','LBACSYS','MDSYS','MGMT_VIEW','OLAPSYS','OWBSYS','ORDPLUGINS','ORDSYS','OUTLN','SI_INFORMTN_SCHEMA','SYS', 'SYSMAN','SYSTEM','TSMSYS','WK_TEST','WKSYS','WKPROXY','WMSYS','XDB' ) 
AND owner NOT LIKE 'FLOW%' 
UNION ALL
SELECT DECODE(OBJECT_TYPE,'PARTITION','INDEX PARTITION','SUBPARTITION','INDEX SUBPARTITION',OBJECT_TYPE) OBJECT_TYPE,owner, index_name object_name,  PARTITION_NAME, SUBPARTITION_NAME, last_analyzed, stattype_locked, stale_stats,GLOBAL_STATS,USER_STATS
FROM dba_ind_statistics ind_s
WHERE (last_analyzed IS NULL OR stale_stats = 'YES') and stattype_locked IS NULL
AND owner NOT IN ('ANONYMOUS', 'CTXSYS', 'DBSNMP', 'EXFSYS','LBACSYS','MDSYS','MGMT_VIEW','OLAPSYS','OWBSYS','ORDPLUGINS','ORDSYS','OUTLN','SI_INFORMTN_SCHEMA','SYS', 'SYSMAN','SYSTEM','TSMSYS','WK_TEST','WKSYS','WKPROXY','WMSYS','XDB' ) 
AND owner NOT LIKE 'FLOW%' 
--Excluding LOB indexes where missing stats is expected behavior (see Note 859779.1)
AND (select index_type from dba_indexes i where i.owner=ind_s.owner and i.index_name=ind_s.index_name and rownum=1)<>'LOB'
ORDER BY object_type desc, owner, object_name;


