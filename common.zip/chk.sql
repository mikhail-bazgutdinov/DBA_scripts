-- Healthcheck configuration overview for single-instance database
-- 2023-06-05 - added v$sysmetric_history query

clear screen
set feedback off  timing off pages 100 lines 200
alter session set nls_date_format='dd.mm.yyyy hh24:mi:ss';
col LOG_MODE for a15
col OPEN_MODE for a15
col DATABASE_ROLE for a20
select d.name "DB name",d.db_unique_name "Unique name", d.DATABASE_ROLE, d.LOG_MODE, d.OPEN_MODE,i.version_full from v$database d, v$instance i;

col instance_name for a15
col host_name for a35
select  instance_number "Inst num"
        ,host_name
        ,instance_name
        ,(select count(*) from v$session where username is not null and program not like 'oracle%(J%') "Total sess"
        ,(select count(case when status='ACTIVE' and wait_class<>'Idle' then 1 end) from v$session) "Active sess"
        ,startup_time
        ,(select min(logon_time) from v$session where username is not null and program not like 'oracle%(J%') "Users conn since"
        ,(select FIRST_TIME from v$log l where status='CURRENT' and l.thread#=i.thread#) "Last log switch"
        ,sysdate "Sysdate"
from v$instance i;

col STATUS for a15
col DESTINATION for a70
col ARCHIVER for a10
col ERROR for a80
select DEST_ID,STATUS,ARCHIVER,DESTINATION,error from v$archive_dest where status<>'INACTIVE' and log_sequence<>0 order by 1;

prompt 
prompt Sessions by username =============================
--Sessions by username
col "USER" for a30
select * from (
select * from
(
select nvl(username,'_'||type) "USER",count(*) "Sessions", count(case when status='ACTIVE' and wait_class<>'Idle' then 1 end) "Active sess"
from v$session
group by nvl(username,'_'||type)
)
order by decode("USER",'_BACKGROUND',1,'SYS',2,'DBSNMP',3,'SYSRAC',4,'_USER',5,6),"Sessions" desc nulls last
) where rownum<15;


prompt
prompt Active Session History - last 10 minutes ======================
COL Phase FOR A35
COL EVENT FOR A35
col "%Tot" for a5
with ash as 
(
  SELECT sample_Time
      , NVL(event,'ON CPU') event
      , CASE WHEN BITAND(time_model, POWER(2, 01)) = POWER(2, 01) THEN 'DBTIME '  END
           ||CASE WHEN BITAND(time_model, POWER(2, 02)) = POWER(2, 02) THEN 'background '  END
           ||CASE WHEN BITAND(time_model, POWER(2, 03)) = POWER(2, 03) THEN 'Conn_mgmt '  END
           ||CASE WHEN BITAND(time_model, POWER(2, 04)) = POWER(2, 04) THEN 'Parse '  END
           ||CASE WHEN BITAND(time_model, POWER(2, 05)) = POWER(2, 05) THEN 'Failed_Parse '  END
           ||CASE WHEN BITAND(time_model, POWER(2, 06)) = POWER(2, 06) THEN 'NOMEM_PARSE '  END
           ||CASE WHEN BITAND(time_model, POWER(2, 07)) = POWER(2, 07) THEN 'Hard parse '  END
           ||CASE WHEN BITAND(time_model, POWER(2, 08)) = POWER(2, 08) THEN 'NO_SHARERS_PARSE '  END
           ||CASE WHEN BITAND(time_model, POWER(2, 09)) = POWER(2, 09) THEN 'BIND_MISMATCH_PARSE '  END
           ||CASE WHEN BITAND(time_model, POWER(2, 10)) = POWER(2, 10) THEN 'SQL_Exec '  END
           ||CASE WHEN BITAND(time_model, POWER(2, 11)) = POWER(2, 11) THEN 'PLSQ_Exec '  END
           ||CASE WHEN BITAND(time_model, POWER(2, 12)) = POWER(2, 12) THEN 'PLSQL_RPC '  END
           ||CASE WHEN BITAND(time_model, POWER(2, 13)) = POWER(2, 13) THEN 'PLSQL_Compile '  END
           ||CASE WHEN BITAND(time_model, POWER(2, 14)) = POWER(2, 14) THEN 'Java_Exec '  END
           ||CASE WHEN BITAND(time_model, POWER(2, 15)) = POWER(2, 15) THEN 'BIND '  END
           ||CASE WHEN BITAND(time_model, POWER(2, 16)) = POWER(2, 16) THEN 'CURSOR_CLOSE '  END
           ||CASE WHEN BITAND(time_model, POWER(2, 17)) = POWER(2, 17) THEN 'SEQUENCE_Load '  END
           ||CASE WHEN BITAND(time_model, POWER(2, 18)) = POWER(2, 18) THEN 'INMEMORY_QUERY '  END
           ||CASE WHEN BITAND(time_model, POWER(2, 19)) = POWER(2, 19) THEN 'INMEMORY_POPULATE '  END
           ||CASE WHEN BITAND(time_model, POWER(2, 20)) = POWER(2, 20) THEN 'INMEMORY_PREPOPULATE '  END
           ||CASE WHEN BITAND(time_model, POWER(2, 21)) = POWER(2, 21) THEN 'INMEMORY_REPOPULATE '  END
           ||CASE WHEN BITAND(time_model, POWER(2, 22)) = POWER(2, 22) THEN 'INMEMORY_TREPOPULATE '  END
           ||CASE WHEN BITAND(time_model, POWER(2, 23)) = POWER(2, 23) THEN 'TABLESPACE_ENCRYPTION ' END Phase 
           --,  Round(case when program like '%(DBW%' then DELTA_WRITE_IO_BYTES end) "DBWR_write_bytes"
          -- ,  Round(case when program like '%(LG%' then DELTA_WRITE_IO_BYTES end) "LGWR_write_bytes"
    FROM
        v$active_session_history a
   WHERE 1=1
    AND sample_time>= systimestamp - 10/1440  
)
,
ash_t as 
(
    select  event, Phase 
       , count(*) "Secs/10 mins"
      , ROUND(RATIO_TO_REPORT(COUNT(*)) OVER () * 100) "%This"
      , count(case when sample_Time between systimestamp - 10/1440 and systimestamp - 9/1440 then 1 end ) "Now-9 mins"  
      , count(case when sample_Time between systimestamp - 9/1440 and systimestamp - 8/1440 then 1 end ) "Now-8 mins"  
      , count(case when sample_Time between systimestamp - 8/1440 and systimestamp - 7/1440 then 1 end ) "Now-7 mins"  
      , count(case when sample_Time between systimestamp - 7/1440 and systimestamp - 6/1440 then 1 end ) "Now-6 mins"  
      , count(case when sample_Time between systimestamp - 6/1440 and systimestamp - 5/1440 then 1 end ) "Now-5 mins"  
      , count(case when sample_Time between systimestamp - 5/1440 and systimestamp - 4/1440 then 1 end ) "Now-4 mins"  
      , count(case when sample_Time between systimestamp - 4/1440 and systimestamp - 3/1440 then 1 end ) "Now-3 mins"  
      , count(case when sample_Time between systimestamp - 3/1440 and systimestamp - 2/1440 then 1 end ) "Now-2 mins"  
      , count(case when sample_Time between systimestamp - 2/1440 and systimestamp - 1/1440 then 1 end ) "Now-1 mins"  
      , count(case when sample_Time between systimestamp - 1/1440 and systimestamp - 0/1440 then 1 end ) "Now-0 mins"
      --, Round(Sum("DBWR_write_bytes")/1024/1024,1) "DBWR wr MB"
      --, Round(Sum("LGWR_write_bytes")/1024/1024,1) "LGWR wr MB"
FROM ash      
GROUP BY event, Phase 
order by "Secs/10 mins" desc
)      
SELECT "Secs/10 mins", LPAD("%This" ||'%',5,' ') "%Tot",
event, Phase
,"Now-9 mins","Now-8 mins","Now-7 mins","Now-6 mins","Now-5 mins","Now-4 mins","Now-3 mins","Now-2 mins","Now-1 mins","Now-0 mins"
--,"DBWR wr MB"
--,"LGWR wr MB"
FROM ASH_t
WHERE 
"%This">2 
and  ROWNUM <= 8;

prompt
prompt Sysmetrics 1-minute average Now to 1-hour-back deltas ==========================
set line 400 pagesize 100;
set serveroutput on;
declare
now_value number;
hour_ago_value number;
diff number;
diff_pct number;
sql_now varchar2(500);
sql_hour_ago varchar2(500);
begin
dbms_output.put_line(rpad(' ',105,'-'));
dbms_output.put_line(rpad('METRIC NAME',50) ||' | '|| rpad('HOUR_AGO',10) ||' | '|| rpad('NOW',10)||' | '|| rpad('DIFF',10)||' | '|| rpad('DIFF_PCT',10)|| ' | ');
dbms_output.put_line(rpad(' ',105,'-'));
for i in(select distinct metric_id,metric_name from v$sysmetric_history where metric_name in('Average Active Sessions','Logons Per Sec','Redo Generated Per Sec','SQL Service Response Time','User Transaction Per Sec','Average Synchronous Single-Block Read Latency','Physical Reads Per Sec','Logical Reads Per Sec','I/O Megabytes per Second','Network Traffic Volume Per Sec','Hard Parse Count Per Sec') 
order by decode(metric_name,'Average Active Sessions',0,'User Transaction Per Sec',1,'Logons Per Sec',2,'Hard Parse Count Per Sec',3,100),metric_name
) loop
sql_now:='select round(value,3) from (select rownum rnum,value from v$sysmetric_history where metric_id='||i.metric_id||')  where rnum=1';
sql_hour_ago:='select round(value,3) from (select rownum rnum,value from v$sysmetric_history where metric_id='||i.metric_id||')  where rnum=60';
EXECUTE IMMEDIATE sql_now into now_value;
EXECUTE IMMEDIATE sql_hour_ago into hour_ago_value;
diff:=now_value-hour_ago_value;
if hour_ago_value=0 then hour_ago_value:=NULL ; end if;
diff_pct:=round((now_value-hour_ago_value)/hour_ago_value*100);
dbms_output.put_line(rpad(i.metric_name,50) ||' | '|| rpad(hour_ago_value,10) || ' | ' || rpad(now_value,10) || ' | ' || rpad(diff,10) || ' | ' || rpad(diff_pct,10) || ' | ');
end loop;
dbms_output.put_line(rpad(' ',105,'-'));
end;
/


set heading off
col Alert_log for a150
select 'Alert log:  ' || VALUE||'/alert_' || (select instance_name from v$instance) ||'.log'  Alert_log from v$diag_info where NAME='Diag Trace';

set heading on
set feedback on
