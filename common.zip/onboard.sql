--Total sessions
clear screen
@chk

set heading on
set feedback on
pause
set feedback off
col LOG_MODE for a15
col DATABASE_ROLE for a15
col OPEN_MODE for a15
col NETWORK_NAME for a25
col GLOBAL_NAME for a30
col ARCHIVER for a10
col DESTINATION for a40

show parameter name

select dbid from v$database;

select * from global_name;
select log_mode,database_role,open_mode,PRIMARY_DB_UNIQUE_NAME from v$database;

select NETWORK_NAME from dba_services where NETWORK_NAME is not null and NETWORK_NAME not like '%XDB%';

select VALUE||'/alert_' || (select instance_name from v$instance) ||'.log'  Alert_log from v$diag_info where NAME='Diag Trace';


select DEST_ID,STATUS,ARCHIVER,DESTINATION,error from v$archive_dest where status<>'INACTIVE' and log_sequence<>0;
pause

set echo on 
col name for a90
select name from v$datafile
union all
select name from v$tempfile;
pause 

show parameter control_file
show parameter create
show parameter recover
!df -h
pause
col name for a110
select name,first_time from v$archived_log where name is not null order by first_time;

pause
col Parameter for a30
col Display_value for a80
select name Parameter, display_value from v$system_parameter2 where isdefault='FALSE' order by name;
set echo off
@ts
pause
!/home/oracle/scripts/check/memory_usage2.sh
pause
!/home/oracle/scripts/check/lsoh.sh
pause
prompt  Count object in application schemas
set echo off
set feedback off
set linesize 800
set pagesize 1000
col "Application schema" for a30
col "Password profile" for a30
  SELECT   NVL(obj.owner,'Total') "Application schema",
           --u.account_status "Account status",
           u.profile "Password profile",
           Max(u.created) "user created",
           to_char(u.expiry_Date,'dd.mm.yyyy') "Password expiration date",
           SUM (DECODE (obj.object_type, 'TABLE', 1, NULL)) "Count tables",
           SUM (DECODE (obj.object_type, 'TABLE PARTITION', 1, NULL)) "Count tab partitions",
           SUM (DECODE (obj.object_type, 'TABLE SUBPARTITION', 1, NULL)) "Count tab subparts",
           SUM (DECODE (obj.object_type, 'VIEW', 1, NULL)) "Count views",
           SUM (DECODE (obj.object_type, 'TABLE', NULL,'TABLE PARTITION', NULL,'TABLE SUBPARTITION', NULL, 'VIEW', NULL, 1))  - NVL(SUM (DECODE(SUBSTR(obj.object_name,1,4),'BIN$',1,null)),0) "Count other objects",
           SUM (DECODE(SUBSTR(obj.object_name,1,4),'BIN$',1,null)) "Recycle bin objects",
           SUM (DECODE (obj.STATUS, 'INVALID', 1, NULL)) "Invalid objects",
           TO_CHAR(SUM (seg.bytes /1024/1024),'999G999G990D9') "Total size, Mb",
           TO_CHAR(SUM (case when seg.segment_type not like 'INDEX%' then seg.bytes /1024/1024 end) ,'999G999G990D9') "Excluding indexes size, Mb",
	   COUNT(distinct seg.tablespace_name) Tablespaces
           --count(distinct s.sid) "Num of opened connections"
    FROM    dba_objects obj 
            left join dba_segments seg on obj.owner=seg.owner and obj.object_name=seg.segment_name and NVL(obj.SUBOBJECT_NAME,'1')=NVL(seg.partition_name,'1')
            left join dba_users u on u.username=obj.owner
            --left join v$session s on s.username=u.username
   WHERE   obj.owner NOT IN
                 ('SYS',
                  'DBSNMP',
                  'SYSTEM',
                  'TSMSYS',
                  'OUTLN',
                  'PUBLIC',
                  'ORACLE_OCM',
                  'PERFSTAT',
                  'ORDSYS',
                  'MDSYS',
                  'CTXSYS',
                  'ORDPLUGINS',
                  'LBACSYS',
                  'XDB',
                  'SI_INFORMTN_SCHEMA',
                  'DIP',
                  'DBSNMP',
                  'EXFSYS',
                  'WMSYS',
                  'ORACLE_OCM',
                  'ANONYMOUS',
                  'XS$NULL',
                  'APPQOSSYS',
                  'APEX_030200',
                  'APEX_040200',
                  'DVF','DVSYS','OJVMSYS','GSMADMIN_INTERNAL','AUDSYS',
                  'OLAPSYS',
                  'ORDDATA',
                  'OWBSYS',
                  'FLOWS_FILES',
                  'OWBSYS_AUDIT',
                  'DBSFWUSER',
                  'REMOTE_SCHEDULER_AGENT')
GROUP BY ROLLUP (obj.owner,u.account_status,u.profile,to_char(u.expiry_Date,'dd.mm.yyyy'))
HAVING GROUPING (to_char(u.expiry_Date,'dd.mm.yyyy'))=0 OR GROUPING(obj.owner)=1
ORDER BY GROUPING(obj.owner), obj.owner;

pause
prompt ��� ������� ��������� ������������
col LAST_LOGIN for a15
col profile for a25
col account_status for a15

select username,created,profile,account_status,LOCK_DATE,EXPIRY_DATE ,to_char(LAST_LOGIN,'dd.mm.yyyy') LAST_LOGIN
from dba_users where username not in ('SYS', 'DBSNMP', 'SYSTEM', 'TSMSYS', 'OUTLN', 'PUBLIC', 'ORACLE_OCM', 'PERFSTAT', 'ORDSYS', 'MDSYS', 'CTXSYS', 'ORDPLUGINS', 'LBACSYS', 'XDB', 'SI_INFORMTN_SCHEMA', 'DIP', 'DBSNMP', 'EXFSYS', 'WMSYS', 'ORACLE_OCM', 'ANONYMOUS', 'XS$NULL', 'APPQOSSYS', 'APEX_030200', 'APEX_040200', 'DVF','DVSYS','OJVMSYS','GSMADMIN_INTERNAL','AUDSYS', 'OLAPSYS', 'ORDDATA', 'OWBSYS', 'FLOWS_FILES', 'OWBSYS_AUDIT', 'DBSFWUSER', 'REMOTE_SCHEDULER_AGENT','SYSRAC','SYS$UMF','GGSYS','GSMCATUSER','SYSBACKUP','SYSKM','SYSDG','GSMUSER','MDDATA','SPATIAL_CSW_ADMIN_USR','APEX_PUBLIC_USER','SCOTT') order by created;

pause
prompt SYSAUX
col OCCUPANT_NAME for a30
col OCCUPANT_DESC for a80
select * from (select occupant_name,Occupant_desc,space_usage_kbytes/1024/1024 "GB" from V$SYSAUX_OCCUPANTS order by "GB" desc) where rownum<5;

pause 
prompt Audit size
col segment_name for a30
col tablespace_name for a30
select segment_name,tablespace_name, sum(bytes)/1024/1024/1024 "GB", count(*) "Partitions" from dba_segments where segment_name in ('AUD$UNIFIED','AUD$') group by segment_name, tablespace_name;

pause
prompt Top Segments
set lines 200 pages 200
col tablespace_name for a30
col OWNER for a10
col SEGMENT_NAME for a35
col PARTITION_NAME for a20
col SEGMENT_TYPE for a20
col  "LOB column" for a30
col "Size, Mb"  for 999,999
select * from 
(
select seg.tablespace_name, SEG.OWNER,SEG.SEGMENT_NAME, seg.PARTITION_NAME, SEG.SEGMENT_TYPE, lob.TABLE_NAME||'.'||lob.COLUMN_NAME "LOB column", Round(BYTES/1024/1024) "Size, Mb" 
from dba_segments seg
left join DBA_LOBS lob on SEG.SEGMENT_NAME= lob.SEGMENT_NAME
where seg.tablespace_name IN ('SYSTEM')
--(seg.segment_name like '%CROC_DOCUMENT_COMMON_S%')-- or seg.segment_name like 'J$%')
--and seg.owner='GAL'
order by bytes desc)
where "Size, Mb">100
order by "Size, Mb" desc, tablespace_name,SEGMENT_TYPE,SEGMENT_NAME
fetch first 100 rows only;


pause
prompt Undo stats
prompt Undo configuration 
set linesize 200 pages 100
col TABLESPACE_NAME format a20 heading "Tablespace|name"
col "Tablespace status" format a10 heading "Tablespace|status"
col "Retention type" format a12 heading "Retention|type"
col "Autoextensible tablespace" format a15 heading "Autoextensible|tablespace"
col "undo_retention init parameter" format a15 heading "undo_retention|init|parameter"
col "undo_management init parameter" format a15 heading "undo_management|init|parameter"
col "Tuned undoretention v$undostat" format 999G999 heading "Tuned|undoretention|v$undostat"
COL "_undo_autotune init parameter" FORMAT A15 HEADING "_undo_autotune|init|parameter"
col "_rollback_segment_count param" format A15 heading "_rollback_segment_count|init|param"
col "Size,Mb" format 999G999G999 heading "Max size,Mb"

--Undo configuration
select 
  TBS.TABLESPACE_NAME, 
  TBS.STATUS "Tablespace status", 
  TBS.retention "Retention type", 
  case when AUTOEXT.AUTOEXTENSIBLE>0 then 'Yes' else 'No' end "Autoextensible tablespace",
  case when (select value from V$PARAMETER where name='undo_tablespace')=TBS.TABLESPACE_NAME then 'Yes' end "Currently active UNDO Tbs",
  case when (select value from V$PARAMETER where name='undo_tablespace')=TBS.TABLESPACE_NAME then 
    (select value from V$PARAMETER where name='undo_retention') end "undo_retention init parameter",
  case when (select value from V$PARAMETER where name='undo_tablespace')=TBS.TABLESPACE_NAME then 
  (select value from V$PARAMETER where name='undo_management') end "undo_management init parameter",
  case when (select value from V$PARAMETER where name='undo_tablespace')=TBS.TABLESPACE_NAME then 
  (select value from V$PARAMETER where name='_undo_autotune') end "_undo_autotune init parameter",
  case when (select value from V$PARAMETER where name='undo_tablespace')=TBS.TABLESPACE_NAME then 
  (select value from V$PARAMETER where name='_rollback_segment_count') end "_rollback_segment_count param",
  case when (select value from V$PARAMETER where name='undo_tablespace')=TBS.TABLESPACE_NAME then 
  (select TUNED_UNDORETENTION from V$UNDOSTAT where END_TIME=(select max(END_TIME) from V$UNDOSTAT)) end "Tuned undoretention v$undostat",
  case when (select value from V$PARAMETER where name='undo_tablespace')=TBS.TABLESPACE_NAME then 
  (select COUNT(*) from V$UNDOSTAT) end "Count of rows in v$undostat"
from DBA_TABLESPACES tbs
join
(
  select TABLESPACE_NAME, COUNT(case when AUTOEXTENSIBLE='YES' then 1 end) "AUTOEXTENSIBLE",
  COUNT(case when AUTOEXTENSIBLE='NO' then 1 end) "NOAUTOEXTENSIBLE"
  from DBA_DATA_FILES where TABLESPACE_NAME in (select TABLESPACE_NAME from DBA_TABLESPACES where contents='UNDO')
  group by TABLESPACE_NAME
) AUTOEXT on AUTOEXT.TABLESPACE_NAME=TBS.TABLESPACE_NAME
;

prompt UNDO space usage 
set linesize 200 pages 100
col TABLESPACE_NAME format a20 heading "Tablespace|name"
col "Allocated, Mb" format 999G999G999 heading "Allocated,| Mb"
col "Free (including expired) Mb" format 999G999G999 heading "Free|(including|expired), Mb"
col "Used,Mb" format 999G999G999
col "Active extents, Mb" format 999G999G999 heading "Active|extents,|Mb" 
col "Unexpired extents, Mb" format 999G999G999 heading "Unexpired|extents,|Mb" 
col "Expired extents, Mb" format 999G999G999 heading "Expired|extents,|Mb"
col "Free allocated, Mb" format 999G999G999 heading "Free|allocated,|Mb" 
col "Maxsize,|Mb" format 999G999G999
col AUTOEXTENSIBLE format A10 heading "Auto|extensible"
col "Free (+expired+autoext) MB" format 999G999G999 heading "Free (including|expired and auto-|extension), Mb"
select 
    df.tablespace_name,
    DF."Allocated, Mb",
	DF.AUTOEXTENSIBLE,
	DECODE(DF.AUTOEXTENSIBLE,'YES',DF."Maxsize, Mb") "Maxsize, Mb",
    UE.ACTIVE_MBYTES+UE.EXPIRED_MBYTES+UE.UNEXPIRED_MBYTES "Used,Mb",
    UE.ACTIVE_MBYTES "Active extents, Mb",
    UE.UNEXPIRED_MBYTES "Unexpired extents, Mb",
    UE.EXPIRED_MBYTES "Expired extents, Mb",
    DF."Allocated, Mb" - (UE.ACTIVE_MBYTES+UE.UNEXPIRED_MBYTES+UE.EXPIRED_MBYTES) "Free allocated, Mb",
    DF."Allocated, Mb" - (UE.ACTIVE_MBYTES+UE.UNEXPIRED_MBYTES) "Free (including expired) Mb",
	decode(DF.AUTOEXTENSIBLE,'YES',DF."Maxsize, Mb" - (UE.ACTIVE_MBYTES+UE.UNEXPIRED_MBYTES)) "Free (+expired+autoext) MB"
FROM
(select 
  TABLESPACE_NAME,
  ROUND (SUM (BYTES / (1024 * 1024))) "Allocated, Mb",
  ROUND (SUM (decode(AUTOEXTENSIBLE,'YES',GREATEST(MAXBYTES,BYTES),BYTES) / (1024 * 1024))) "Maxsize, Mb",
  MAX(AUTOEXTENSIBLE) AUTOEXTENSIBLE
from  DBA_DATA_FILES DF
where TABLESPACE_NAME IN (SELECT tablespace_name from dba_tablespaces where contents='UNDO')
group by TABLESPACE_NAME 
)df,
(select TABLESPACE_NAME,
        ROUND (NVL(SUM (case when STATUS='ACTIVE' then BYTES end)/ (1024 * 1024),0)) ACTIVE_MBYTES,
        ROUND (NVL(SUM (case when STATUS='EXPIRED' then BYTES end )/ (1024 * 1024),0)) EXPIRED_MBYTES,
        ROUND (NVL(SUM (case when STATUS='UNEXPIRED' then BYTES end)/ (1024 * 1024),0)) UNEXPIRED_MBYTES
from DBA_UNDO_EXTENTS 
group by TABLESPACE_NAME) UE
where UE.TABLESPACE_NAME=DF.TABLESPACE_NAME;


select vs.BEGIN_TIME, vs.SSOLDERRCNT,vs.NOSPACEERRCNT,vs.EXPSTEALCNT,vs.UNXPSTEALCNT 
from v$undostat vs where vs.SSOLDERRCNT+vs.NOSPACEERRCNT+vs.EXPSTEALCNT+vs.UNXPSTEALCNT>0 order by vs.BEGIN_TIME desc;

pause
@chk
